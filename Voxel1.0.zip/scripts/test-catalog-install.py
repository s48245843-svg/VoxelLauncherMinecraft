"""Real UI -> WebChannel -> native confirmation -> Python download -> checked JARs."""
import json
import os
import sys
import tempfile
from pathlib import Path
os.environ["VOXEL_DATA_DIR"]=tempfile.mkdtemp(prefix="voxel-click-install-")
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"desktop"))
from PySide6.QtCore import Qt,QCoreApplication,QTimer
from PySide6.QtGui import QFontDatabase
from PySide6.QtWidgets import QApplication,QMessageBox
from voxel.state import Store,RESOURCE_ROOT
from voxel.ui import Window
from voxel.network import verify
QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
app=QApplication([]);app.setStyle("Fusion");QFontDatabase.addApplicationFont(str(RESOURCE_ROOT/'assets/Inter.ttf'))
store=Store();p=store.add_profile('WebUI click test','1.21.1','fabric','0.16.14')
w=Window(store,online=False);w.show();w.open_catalog('Iris','modrinth','mod')
# The test accepts the real native confirmation automatically; production still asks the user.
QMessageBox.question=lambda *a,**k:QMessageBox.StandardButton.Yes
errors=[];stage={'value':0}; attempts=[0]
w.events.error.connect(lambda name,message:errors.append(name+': '+message))

def tick():
    attempts[0]+=1
    if attempts[0]>65:
        errors.append('Timed out at stage '+str(stage['value']));finish();return
    if stage['value']==0:
        js="JSON.stringify({ready:!!Array.from(document.querySelectorAll('.project')).find(x=>x.dataset.projectId==='YL57xq9U')})"
        def result(value):
            data=json.loads(value) if value else {}
            if data.get('ready'):
                stage['value']=1
                w.web.page().runJavaScript("Array.from(document.querySelectorAll('.project')).find(x=>x.dataset.projectId==='YL57xq9U').querySelector('button').click()")
        w.web.page().runJavaScript(js,result)
    elif stage['value']==1:
        def result(value):
            data=json.loads(value) if value else {}
            if data.get('ready'):
                stage['value']=2
                print('CLICKED_INSTALL',data,flush=True)
                w.web.page().runJavaScript("document.getElementById('install').click()")
        w.web.page().runJavaScript("JSON.stringify({ready:document.getElementById('detail').open&&!document.getElementById('install').disabled,version:document.getElementById('versions').value,target:document.getElementById('target').value})",result)
    elif stage['value']==2:
        current=store.profile(p['id'])
        if current['mods'] and not w.current_job:
            for rec in current['mods']:
                path=Path(current['directory'])/rec['path']
                good=verify(path,rec['hashes'],rec.get('size'))
                print('WEBUI_CREATED',path.name,path.stat().st_size,'VERIFIED',good,flush=True)
                if not good:errors.append('Hash failed')
            if len(current['mods'])<2:errors.append('Dependency not installed')
            print('JOB_LABEL',w.job_label.text(),flush=True)
            finish()
        elif errors:finish()

def finish():
    timer.stop()
    print('E2E_ERRORS',errors,flush=True)
    w.close();QTimer.singleShot(400,app.quit)

timer=QTimer();timer.setInterval(1200);timer.timeout.connect(tick);timer.start()
app.exec();sys.exit(bool(errors))
