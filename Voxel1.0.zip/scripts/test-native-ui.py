"""Headless Qt integration check; no runtime sandbox settings are changed by the app."""
import os
import json
import tempfile
import sys
from pathlib import Path
os.environ.setdefault("VOXEL_DATA_DIR", tempfile.mkdtemp(prefix="voxel-ui-tests-"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "desktop"))
from PySide6.QtCore import QTimer, Qt, QCoreApplication
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication
from voxel.state import RESOURCE_ROOT
from voxel.ui import Window

QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
app = QApplication([]); app.setStyle("Fusion")
QFontDatabase.addApplicationFont(str(RESOURCE_ROOT / "assets/Inter.ttf"))
font=QFont("Inter"); font.setPixelSize(12); app.setFont(font)
w=Window(online=False); w.resize(1280,920); w.show()
errors=[]; checks=[]

def inspect_home():
    try:
        w.grab().save("public/images/voxel-native.png")
        assert w.home_cards.count()==3
        w.open_catalog("Sodium", "modrinth", "mod")
        w.web.page().renderProcessTerminated.connect(lambda status,code: errors.append(f"renderer: {code}") if code else None)
        w.web.bridge.response.connect(lambda raw: checks.append(raw))
    except Exception as e: errors.append(str(e))

def capture_catalog():
    w.grab().save("public/images/voxel-catalog.png")
    def check_result(result):
        result=json.loads(result) if isinstance(result,str) and result else result
        print("CATALOG_JS", result, flush=True)
        if not result or result.get("count",0)<1:errors.append("No catalog results")
        # Test disabled access clearly, not fake CF cards.
        w.web.search("Better MC","curseforge","modpack")
    w.web.page().runJavaScript("JSON.stringify({count:document.querySelectorAll('.project').length, notice:document.getElementById('noticeText').textContent})",check_result)

def check_cf():
    def result(data):
        print("CURSEFORGE_UI",data,flush=True)
        if not data or "ключ" not in data.lower():errors.append("Missing CF setup message")
        w.navigate("versions",animate=False);w.version_data=[{'id':'1.20.1','type':'release'}];w.filter_versions();w.version_list.setCurrentRow(0);w.version_name.setText("UI integration");w.create_profile()
        w.navigate("accounts",animate=False);w.nick.setText("UiTester");w.add_offline()
        w.navigate("settings",animate=False);w.fields['width'].setText('1440');w.save_settings()
        print("SAVED",len(w.store.snapshot()['profiles']),len(w.store.snapshot()['accounts']),w.store.settings()['width'],flush=True)
        w.close();QTimer.singleShot(300,app.quit)
    w.web.page().runJavaScript("document.getElementById('noticeText').textContent",result)

QTimer.singleShot(800,inspect_home)
QTimer.singleShot(15000,capture_catalog)
QTimer.singleShot(22000,check_cf)
QTimer.singleShot(50000,lambda:(errors.append('timeout'),app.quit()))
app.exec()
print('BRIDGE_RESPONSES',len(checks), 'ERRORS',errors,flush=True)
sys.exit(bool(errors))
