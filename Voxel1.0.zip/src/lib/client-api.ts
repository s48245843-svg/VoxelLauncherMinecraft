export async function api<T = { ok: boolean; id?: string; jobId?: string }>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...options, headers: { ...(options?.body && !(options.body instanceof FormData) ? { "Content-Type": "application/json" } : {}), ...options?.headers } });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Не удалось выполнить запрос.");
  return data as T;
}
export const post = <T = { ok: boolean; id?: string; jobId?: string }>(url: string, body: unknown) => api<T>(url, { method: "POST", body: JSON.stringify(body) });
export function formatDownloads(value: number) { return new Intl.NumberFormat("ru-RU", { notation: "compact", maximumFractionDigits: 1 }).format(value); }
export function memoryLabel(value: number) { return (value / 1024).toLocaleString("ru-RU", { maximumFractionDigits: 1 }) + " ГБ"; }
