export type Loader = "vanilla" | "fabric" | "forge" | "neoforge" | "quilt" | "liteloader";
export type AccountType = "offline" | "microsoft" | "ely";
export type ModItem = { id: string; name: string; filename: string; projectId?: string; icon?: string; url?: string };
export type AccountCredentials = { accessToken: string; refreshToken?: string; expiresAt: number; userHash?: string; xuid?: string };
export type Profile = {
  id: string; name: string; description: string; gameVersion: string; loader: Loader;
  loaderVersion: string; icon: string; accent: string; memory: number; javaPath: string;
  jvmArgs: string; gameDirectory: string; installed: boolean; needsInstaller: boolean;
  mods: ModItem[]; createdAt?: string;
};
export type Account = { id: string; username: string; uuid: string; type: AccountType; avatar: string; active: boolean; expiresAt?: number };
export type Settings = {
  ram: number; gameDirectory: string; javaPath: string; jvmArgs: string;
  resolutionWidth: number; resolutionHeight: number; fullScreen: boolean;
  language: string; closeOnLaunch: boolean; showSnapshots: boolean;
};
export type InstallJob = { id: string; profileId: string; status: string; progress: number; message: string; error: string | null };
export type LauncherData = { profiles: Profile[]; accounts: Account[]; settings: Settings; jobs: InstallJob[] };
export type MinecraftVersion = { id: string; type: string; url?: string; releaseTime: string };
export type ModrinthProject = {
  project_id: string; project_type?: string; slug: string; title: string; description: string; downloads: number;
  follows: number; icon_url: string | null; categories: string[]; versions: string[]; game_versions?: string[];
  loaders: string[]; author: string; gallery: string[]; color?: number;
};
export type ModrinthFile = { url: string; filename: string; primary: boolean; size: number; hashes: { sha1: string; sha512: string } };
export type ModrinthVersion = {
  id: string; project_id: string; name: string; version_number: string; game_versions: string[];
  loaders: string[]; version_type: string; files: ModrinthFile[]; date_published: string;
  dependencies: { project_id?: string; version_id?: string; dependency_type: string }[];
};
export type ModpackIndex = {
  formatVersion: number; game: string; name: string; versionId?: string;
  dependencies: Record<string, string>;
  files: { path: string; downloads: string[]; hashes: Record<string, string>; env?: { client: string; server: string } }[];
};
export const loaderNames: Record<Loader, string> = { vanilla: "Vanilla", fabric: "Fabric", forge: "Forge", neoforge: "NeoForge", quilt: "Quilt", liteloader: "LiteLoader" };
export const defaultSettings: Settings = { ram: 4096, gameDirectory: ".minecraft", javaPath: "", jvmArgs: "", resolutionWidth: 1920, resolutionHeight: 1080, fullScreen: false, language: "ru_ru", closeOnLaunch: false, showSnapshots: false };
