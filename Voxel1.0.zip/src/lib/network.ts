import { lookup } from "node:dns/promises";
import { createHash } from "node:crypto";
import { mkdir, readFile, stat } from "node:fs/promises";
import { createWriteStream } from "node:fs";
import path from "node:path";
import { Readable, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";

export class UserFacingError extends Error {}
const downloadHosts = new Set(["cdn.modrinth.com", "piston-meta.mojang.com", "piston-data.mojang.com", "launchermeta.mojang.com", "launcher.mojang.com", "resources.download.minecraft.net", "libraries.minecraft.net", "maven.minecraftforge.net", "files.minecraftforge.net", "meta.fabricmc.net", "maven.fabricmc.net", "meta.quiltmc.org", "maven.quiltmc.org", "maven.neoforged.net", "dl.liteloader.com", "repo.mumfrey.com", "repo.spongepowered.org", "repo.maven.apache.org", "repo1.maven.org", "authlib-injector.yushi.moe", "authlib-injector.sk89q.wtf", "github.com"]);
export function isPrivateAddress(address: string): boolean {
  if (address.includes(":")) {
    const a = address.toLowerCase();
    return a === "::1" || a === "::" || a.startsWith("fc") || a.startsWith("fd") || a.startsWith("fe8") || a.startsWith("fe9") || a.startsWith("fea") || a.startsWith("feb") || a.startsWith("::ffff:");
  }
  const [a, b] = address.split(".").map(Number);
  return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
}
export function allowedDownloadUrl(url: string): boolean {
  try { const u = new URL(url); return u.protocol === "https:" || (u.protocol === "http:" && downloadHosts.has(u.hostname)); } catch { return false; }
}
export async function safeFetch(input: string, timeout = 45000): Promise<Response> {
  let url = new URL(input);
  if (!allowedDownloadUrl(url.href)) throw new UserFacingError("Этот адрес загрузки не разрешён. Используйте официальные источники или Modrinth.");
  for (let redirects = 0; redirects < 6; redirects++) {
    if (url.port && !["80", "443"].includes(url.port)) throw new UserFacingError("Нестандартный порт загрузки не разрешён.");
    const addresses = await lookup(url.hostname.replace(/^\[|\]$/g, ""), { all: true });
    if (!addresses.length || addresses.some((a) => isPrivateAddress(a.address))) throw new UserFacingError("Загрузка из локальной сети запрещена.");
    const response = await fetch(url, { redirect: "manual", signal: AbortSignal.timeout(timeout), headers: { "User-Agent": "VoxelLauncher/1.4.2 (Minecraft Java web launcher)", Accept: "*/*" } });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("location");
      if (!location) throw new UserFacingError("Сервер загрузки вернул некорректный редирект.");
      url = new URL(location, url);
      if (!allowedDownloadUrl(url.href)) throw new UserFacingError("Редирект ведёт на неподтверждённый источник.");
      continue;
    }
    return response;
  }
  throw new UserFacingError("Слишком много редиректов при загрузке.");
}
export async function fetchJson<T>(url: string, timeout = 30000): Promise<T> {
  const response = await safeFetch(url, timeout);
  if (!response.ok) throw new UserFacingError(`Сервис ${new URL(url).hostname} вернул ошибку ${response.status}. Попробуйте позже.`);
  return await response.json() as T;
}
const activeDownloads = new Map<string, Promise<void>>();
export async function downloadFile(url: string, destination: string, options: { sha1?: string; sha512?: string; required?: boolean; onProgress?: (bytes: number) => void } = {}): Promise<void> {
  destination = path.resolve(destination);
  const existing = activeDownloads.get(destination);
  if (existing) return existing;
  const task = (async () => {
    await mkdir(path.dirname(destination), { recursive: true });
    if (options.required !== false) {
      let valid = false;
      try {
        const info = await stat(destination);
        valid = info.size > 0;
        if (valid && (options.sha1 || options.sha512)) {
          const algo = options.sha512 ? "sha512" : "sha1";
          valid = createHash(algo).update(await readFile(destination)).digest("hex") === (options.sha512 || options.sha1);
        }
      } catch { /* Not cached yet. */ }
      if (valid) return;
    }
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const response = await safeFetch(url);
        if (!response.ok || !response.body) throw new UserFacingError(`Не удалось скачать файл (HTTP ${response.status}).`);
        if (Number(response.headers.get("content-length")) > 512 * 1024 * 1024) throw new UserFacingError("Файл превышает безопасный лимит 512 МБ.");
        const hash1 = options.sha1 ? createHash("sha1") : null;
        const hash512 = options.sha512 ? createHash("sha512") : null;
        let bytes = 0;
        const counter = new Transform({ transform(chunk: Buffer, _encoding, callback) {
          bytes += chunk.length;
          if (bytes > 512 * 1024 * 1024) return callback(new Error("Файл превышает 512 МБ."));
          hash1?.update(chunk); hash512?.update(chunk); options.onProgress?.(bytes); callback(null, chunk);
        } });
        const temp = destination + ".part";
        await pipeline(Readable.fromWeb(response.body as import("node:stream/web").ReadableStream), counter, createWriteStream(temp));
        if (hash1?.digest("hex") !== options.sha1 || hash512?.digest("hex") !== options.sha512) throw new UserFacingError("Контрольная сумма файла не совпадает. Загрузка не сохранена.");
        await (await import("node:fs/promises")).rename(temp, destination);
        return;
      } catch (error) {
        await (await import("node:fs/promises")).rm(destination + ".part", { force: true }).catch(() => undefined);
        if (attempt === 2) throw error;
        await new Promise((r) => setTimeout(r, 700 * (attempt + 1)));
      }
    }
  })();
  activeDownloads.set(destination, task);
  try { await task; } finally { activeDownloads.delete(destination); }
}
