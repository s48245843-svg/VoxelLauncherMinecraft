import path from "node:path";
import { db } from "@/db";
import { installationJobs, minecraftProfiles } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { prepareLoader, downloadVanilla, getLoaderVersions } from "./game";
import { UserFacingError } from "./network";
import type { ModpackIndex } from "./types";
import { downloadPackFiles } from "./modrinth";

export async function runInstall(profileId: string, jobId: string, pack?: { index: ModpackIndex; overridesRoot: string }) {
  const root = process.cwd() + "/data/instances/" + profileId;
  let lastWrite = 0;
  let progress = 0;
  try {
    const [job] = await db.update(installationJobs).set({ status: "processing", message: "Получение официальных метаданных…" }).where(and(eq(installationJobs.id, jobId), eq(installationJobs.status, "queued"))).returning();
    if (!job) return;
    const [profile] = await db.select().from(minecraftProfiles).where(eq(minecraftProfiles.id, profileId)).limit(1);
    if (!profile) throw new UserFacingError("Сборка не найдена.");
    const update = async (value: number, message: string, force = false) => {
      progress = Math.max(progress, Math.min(96, value));
      if (force || Date.now() - lastWrite > 1000) {
        await db.update(installationJobs).set({ progress, message }).where(eq(installationJobs.id, jobId)); lastWrite = Date.now();
      }
    };
    let loaderVersion = profile.loaderVersion;
    if (profile.loader !== "vanilla" && !loaderVersion) loaderVersion = (await getLoaderVersions(profile.gameVersion, profile.loader as import("./types").Loader))[0] || "";
    const loaderType = profile.loader as import("./types").Loader;
    const gameDir = path.join(root, profile.gameDirectory);
    const loader = await prepareLoader(root, gameDir, profile.gameVersion, loaderType, loaderVersion);
    await update(10, "Клиент и загрузчик подготовлены", true);
    await downloadVanilla(gameDir, loader.version, (message) => {
      const counts = message.match(/(\d+) из (\d+)/);
      const value = counts ? 35 + Math.round(Number(counts[1]) / Math.max(1, Number(counts[2])) * 48) : 25;
      void update(value, message);
    });
    await update(85, "Ресурсы и библиотеки загружены", true);
    if (pack) await downloadPackFiles(profile, pack.index, pack.overridesRoot, (message) => { void update(90, message); });
    await update(100, "Сборка готова к скачиванию", true);
    await db.update(minecraftProfiles).set({ installed: true, needsInstaller: loader.installer, loaderVersion, ...(pack ? { mods: pack.index.files.filter((f) => f.path.startsWith("mods/") && f.path.endsWith(".jar")).map((f) => ({ id: f.path, name: f.path.split("/").pop()!, filename: f.path })) } : {}) }).where(eq(minecraftProfiles.id, profileId));
    await db.update(installationJobs).set({ status: "completed", progress: 100, message: "Minecraft установлен. Нажмите «Играть» и запустите PLAY." }).where(eq(installationJobs.id, jobId));
  } catch (error) {
    console.error("[Voxel installation]", error);
    await db.update(installationJobs).set({ status: "error", error: error instanceof Error ? error.message : "Ошибка установки", message: "Установка прервана" }).where(eq(installationJobs.id, jobId));
    await db.update(minecraftProfiles).set({ installed: false }).where(eq(minecraftProfiles.id, profileId));
  }
}
