import path from "node:path";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import JSZip from "jszip";
import { downloadFile, fetchJson, safeFetch, UserFacingError } from "./network";
import type { Loader, Profile } from "./types";

export type Library = { name: string; downloads?: { artifact?: { path: string; url?: string; sha1?: string }; classifiers?: Record<string, { path: string; url?: string; sha1?: string }> }; rules?: { action: string; os?: { name?: string; arch?: string }; features?: Record<string, boolean> }[]; clientreq?: boolean; url?: string };
export type Argument = string | { value?: string | string[]; rules?: Library["rules"] };
export type MinecraftVersion = { id: string; jar?: string; inheritsFrom?: string; javaVersion?: { majorVersion: number }; mainClass: string; arguments?: { game: Argument[]; jvm: Argument[] }; minecraftArguments?: string; libraries: Library[]; assetIndex?: { id: string; sha1?: string; url?: string }; client?: { url: string; sha1?: string }; downloads?: { client?: { url: string; sha1?: string } }; logging?: { client?: { file?: { id: string; url: string; sha1?: string } } } };
export type OsName = "windows" | "osx" | "linux";
export type ArchName = "x64" | "arm64";
export type VersionManifest = { latest: { release: string; snapshot: string }; versions: { id: string; type: string; url: string; releaseTime: string }[] };
let manifestPromise: Promise<VersionManifest> | undefined;
export function getVersionManifest() { return manifestPromise ??= fetchJson<VersionManifest>("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"); }
export async function getMinecraftVersion(id: string): Promise<MinecraftVersion> {
  const entry = (await getVersionManifest()).versions.find((v) => v.id === id);
  if (!entry) throw new UserFacingError("Эта версия Minecraft не найдена в официальном каталоге.");
  return fetchJson<MinecraftVersion>(entry.url);
}
export function javaMajor(version: MinecraftVersion): number {
  if (version.javaVersion) return version.javaVersion.majorVersion;
  const p = version.id.split(".").map(Number);
  if (p[0] > 1) return 25;
  if (!p[1] || p[1] <= 16) return 8;
  if (p[1] === 17) return 16;
  if (p[1] <= 20) return 17;
  return 21;
}
export function libraryPath(name: string): string {
  const p = name.split(":");
  return `${p[0].replace(/\./g, "/")}/${p[1]}/${p[2]}/${p[1]}-${p[2]}${p[3] ? "-" + p[3] : ""}.jar`;
}
export function libraryUrl(lib: Library, classifier?: string) {
  const artifact = classifier ? lib.downloads?.classifiers?.[classifier] : lib.downloads?.artifact;
  const base = (artifact?.url || lib.url || "https://libraries.minecraft.net/").replace(/^http:/, "https:");
  return { url: base.endsWith(".jar") ? base : base + libraryPath(lib.name + (classifier ? ":" + classifier : "")), path: artifact?.path || libraryPath(lib.name + (classifier ? ":" + classifier : "")), sha1: artifact?.sha1 };
}
export function currentOs(): OsName { return process.platform === "win32" ? "windows" : process.platform === "darwin" ? "osx" : "linux"; }
function ruleMatches(rule: NonNullable<Library["rules"]>[number], os: OsName, arch?: ArchName): boolean {
  if (rule.os?.name && rule.os.name !== os) return false;
  if (rule.os?.arch && arch) {
    const wanted = rule.os.arch.toLowerCase();
    const arm = /arm|aarch/.test(wanted);
    const bits32 = wanted === "x86";
    if (bits32) return false;
    if (arm !== (arch === "arm64")) return false;
  }
  if (rule.features?.is_demo_user || rule.features?.has_quick_plays || rule.features?.is_quick_play_singleplayer || rule.features?.is_quick_play_multiplayer) return false;
  return true;
}
export function rulesAllow(rules?: Library["rules"], os: OsName = currentOs(), arch?: ArchName): boolean {
  if (!rules?.length) return true;
  let allowed = false;
  for (const rule of rules) if (ruleMatches(rule, os, arch)) allowed = rule.action === "allow";
  return allowed;
}
export function allowedOnAnyDesktop(lib: Library): boolean {
  return lib.clientreq !== false && (["windows", "osx", "linux"] as OsName[]).some((os) => rulesAllow(lib.rules, os));
}
export function mavenArtifact(lib: Library): { url: string; path: string; sha1?: string } | null {
  const artifact = lib.downloads?.artifact;
  if (artifact?.path || artifact?.url) {
    const rel = artifact.path || libraryPath(lib.name);
    return { url: (artifact.url || "https://libraries.minecraft.net/" + rel).replace(/^http:/, "https:"), path: rel, sha1: artifact.sha1 };
  }
  if (lib.downloads?.classifiers || /:natives-/.test(lib.name || "")) return null;
  if (!lib.name || lib.name.split(":").length < 3) return null;
  const rel = libraryPath(lib.name);
  const base = (lib.url || "https://libraries.minecraft.net/").replace(/^http:/, "https:").replace(/\/?$/, "/");
  return { url: base + rel, path: rel };
}
export function nativeFolder(classifier: string): string | null {
  const value = classifier.toLowerCase();
  if (!value.includes("native")) return null;
  const arm = /arm|aarch/.test(value);
  if (value.includes("windows")) {
    if (arm) return "windows-arm64";
    if (/32|x86/.test(value) && !value.includes("64")) return "windows-x86";
    return "windows";
  }
  if (value.includes("linux")) return arm ? "linux-arm64" : "linux";
  if (value.includes("mac") || value.includes("osx") || value.includes("darwin")) return arm ? "osx-arm64" : "osx";
  return null;
}
export function clientArtifact(game: MinecraftVersion): { url: string; sha1?: string } | null {
  return game.downloads?.client?.url ? game.downloads.client : game.client?.url ? game.client : null;
}
export function mergeLibraries(base: Library[], extra: Library[]): Library[] {
  const map = new Map<string, Library>();
  for (const lib of [...base, ...extra]) map.set(lib.name + JSON.stringify(lib.rules || []) + JSON.stringify(lib.downloads?.classifiers ? Object.keys(lib.downloads.classifiers) : []), lib);
  return [...map.values()];
}
export function mergeVersion(base: MinecraftVersion, extra: MinecraftVersion): MinecraftVersion {
  return { ...base, ...extra, id: base.id, jar: base.jar || base.id, libraries: mergeLibraries(base.libraries, extra.libraries), arguments: extra.arguments || base.arguments };
}
export async function progressMap<T>(items: T[], concurrency: number, fn: (item: T) => Promise<void>) {
  let index = 0;
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, async () => { while (index < items.length) await fn(items[index++]); }));
}
async function extractNativeJar(jarPath: string, dest: string) {
  const zip = await JSZip.loadAsync(await readFile(jarPath));
  for (const [name, entry] of Object.entries(zip.files)) if (!entry.dir && !name.startsWith("META-INF") && /\.(so|dll|dylib|jnilib)$/.test(name)) {
    await mkdir(dest, { recursive: true });
    await writeFile(path.join(dest, path.basename(name)), await entry.async("nodebuffer"));
  }
}
export async function downloadVanilla(gameDir: string, game: MinecraftVersion, onFile: (name: string) => void) {
  await mkdir(gameDir, { recursive: true });
  const client = clientArtifact(game);
  if (!client) throw new UserFacingError("В манифесте отсутствует клиент Minecraft.");
  const clientPath = path.join(gameDir, "versions", game.id, `${game.id}.jar`);
  await downloadFile(client.url, clientPath, { sha1: client.sha1 }); onFile("Клиент Minecraft");
  const librariesDir = path.join(gameDir, "libraries");
  const nativeJars: { file: string; folder: string }[] = [];
  for (const lib of game.libraries.filter(allowedOnAnyDesktop)) {
    const artifact = mavenArtifact(lib);
    if (artifact) await downloadFile(artifact.url, path.join(librariesDir, artifact.path), { sha1: artifact.sha1 });
    for (const [classifier, native] of Object.entries(lib.downloads?.classifiers || {})) {
      const folder = nativeFolder(classifier);
      if (!folder) continue;
      const rel = native.path || libraryPath(lib.name + ":" + classifier);
      const url = (native.url || "https://libraries.minecraft.net/" + rel).replace(/^http:/, "https:");
      const file = path.join(librariesDir, rel);
      try { await downloadFile(url, file, { sha1: native.sha1 }); nativeJars.push({ file, folder }); } catch { /* Необязательная нативная библиотека другой платформы. */ }
    }
    const mapped = (lib as Library & { natives?: Record<string, string> }).natives || {};
    for (const classifier of Object.values(mapped)) {
      const folder = nativeFolder(classifier);
      if (!folder) continue;
      const rel = libraryPath(lib.name + ":" + classifier);
      const base = (lib.url || "https://libraries.minecraft.net/").replace(/^http:/, "https:").replace(/\/?$/, "/");
      const file = path.join(librariesDir, rel);
      try { await downloadFile(base + rel, file); nativeJars.push({ file, folder }); } catch { /* Старый классификатор может отсутствовать. */ }
    }
    onFile(lib.name);
  }
  for (const native of nativeJars) await extractNativeJar(native.file, path.join(gameDir, "natives", native.folder));
  onFile("Нативные библиотеки");
  if (game.assetIndex) {
    const index = game.assetIndex;
    const indexPath = path.join(gameDir, "assets", "indexes", `${index.id}.json`);
    await downloadFile(index.url || `https://piston-meta.mojang.com/assets/${index.id}/${index.id}.json`, indexPath, { sha1: index.sha1 });
    const data = JSON.parse(await readFile(indexPath, "utf8")) as { objects: Record<string, { hash: string }>; virtual?: string };
    const entries = Object.entries(data.objects); let complete = 0;
    await progressMap(entries, 12, async ([name, object]) => {
      if (!/^[a-f0-9]{40}$/.test(object.hash)) throw new UserFacingError("Некорректный хеш ресурса.");
      const target = data.virtual ? path.join(gameDir, "assets", "virtual", data.virtual, name) : path.join(gameDir, "assets", "objects", object.hash.slice(0, 2), object.hash);
      await downloadFile(`https://resources.download.minecraft.net/${object.hash.slice(0, 2)}/${object.hash}`, target, { sha1: object.hash });
      if (++complete % 20 === 0) onFile(`Ресурсы: ${complete} из ${entries.length}`);
    });
    onFile(`Ресурсы: ${entries.length} из ${entries.length}`);
  } else {
    const zip = await JSZip.loadAsync(await readFile(clientPath));
    for (const [name, entry] of Object.entries(zip.files)) if (name.startsWith("resources/") && !entry.dir) {
      const target = path.join(gameDir, name); await mkdir(path.dirname(target), { recursive: true }); await writeFile(target, await entry.async("nodebuffer"));
    }
  }
  const versionDir = path.join(gameDir, "versions", game.id);
  await mkdir(versionDir, { recursive: true });
  const logging = game.logging?.client?.file;
  if (logging?.url) await downloadFile(logging.url, path.join(versionDir, logging.id), { sha1: logging.sha1 });
  await writeFile(path.join(versionDir, `${game.id}.json`), JSON.stringify(game));
}
function compareVersions(a: string, b: string) { return b.localeCompare(a, undefined, { numeric: true }); }
async function liteLoaderSnapshot(base: string, game: string) {
  const response = await safeFetch(`${base}/com/mumfrey/liteloader/${game}-SNAPSHOT/maven-metadata.xml`);
  if (!response.ok) return null;
  const xml = await response.text();
  const timestamp = xml.match(/<timestamp>([^<]+)<\/timestamp>/)?.[1];
  const build = xml.match(/<buildNumber>([^<]+)<\/buildNumber>/)?.[1];
  return timestamp && build ? { timestamp, buildNumber: build } : null;
}
type LiteData = Record<string, { repo: { url: string } }> | { versions: Record<string, { repo: { url: string } }> };
async function liteRepository(game: string) {
  const data = await fetchJson<LiteData>("https://dl.liteloader.com/versions/versions.json");
  const games = ("versions" in data ? data.versions : data) as Record<string, { repo: { url: string } }>;
  if (!games[game]) throw new UserFacingError("LiteLoader не поддерживает эту версию Minecraft.");
  return games[game].repo.url.replace(/^http:/, "https:");
}
export async function getLoaderVersions(game: string, loader: Loader): Promise<string[]> {
  if (loader === "vanilla") return [""];
  if (loader === "fabric" || loader === "quilt") {
    const base = loader === "fabric" ? "https://meta.fabricmc.net/v2/versions/loader/" : "https://meta.quiltmc.org/v3/versions/loader/";
    const data = await fetchJson<(string | { loader: { version: string } })[]>(base + game);
    return data.map((v) => typeof v === "string" ? v : v.loader.version).sort(compareVersions);
  }
  if (loader === "forge") {
    const meta = await fetchJson<Record<string, string[] | string>>("https://files.minecraftforge.net/net/minecraftforge/forge/maven-metadata.json");
    const versions = Array.isArray(meta[game]) ? meta[game] : typeof meta[game] === "string" ? [meta[game]] : [];
    return versions.filter((v) => v.startsWith(game + "-") && !v.includes("-beta")).map((v) => v.slice(game.length + 1)).sort(compareVersions);
  }
  if (loader === "neoforge") {
    const data = await fetchJson<{ versions: string[] }>("https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge");
    const prefix = game === "1.20.1" ? "47." : game.startsWith("1.") ? game.slice(2) + "." : game + ".";
    return data.versions.filter((v) => v.startsWith(prefix) && !/alpha|beta|snapshot/.test(v)).sort(compareVersions);
  }
  return await liteLoaderSnapshot(await liteRepository(game), game) ? [game + "-SNAPSHOT"] : [];
}
export async function prepareLoader(instanceRoot: string, gameDir: string, game: string, loader: Loader, version: string): Promise<{ version: MinecraftVersion; installer: boolean }> {
  if (loader === "vanilla") return { version: await getMinecraftVersion(game), installer: false };
  await mkdir(path.join(instanceRoot, "voxel"), { recursive: true });
  const librariesDir = path.join(gameDir, "libraries");
  let extra: MinecraftVersion;
  let installer = false;
  if (loader === "fabric") {
    extra = await fetchJson<MinecraftVersion>(`https://meta.fabricmc.net/v2/versions/loader/${game}/${version}/profile/json`);
    const meta = await fetchJson<{ version: string }[]>(`https://meta.fabricmc.net/v2/versions/intermediary/${game}`);
    if (meta[0]) extra = { ...extra, libraries: [...extra.libraries, { name: "net.fabricmc:intermediary:" + meta[0].version, url: "https://maven.fabricmc.net/" }] };
  } else if (loader === "quilt") {
    extra = await fetchJson<MinecraftVersion>(`https://meta.quiltmc.org/v3/versions/loader/${game}/${version}/profile/json`);
  } else if (loader === "liteloader") {
    const base = await liteRepository(game);
    const snapshot = await liteLoaderSnapshot(base, game);
    if (!snapshot) throw new UserFacingError("Для LiteLoader не найден доступный snapshot.");
    const filename = `liteloader-${game}-${snapshot.timestamp}-${snapshot.buildNumber}.jar`;
    await downloadFile(`${base}/com/mumfrey/liteloader/${game}-SNAPSHOT/${filename}`, path.join(librariesDir, "com/mumfrey/liteloader", game + "-SNAPSHOT", filename));
    const data = await fetchJson<LiteData>("https://dl.liteloader.com/versions/versions.json");
    const games = ("versions" in data ? data.versions : data) as Record<string, { repo: { url: string }; snapshots: { libraries: Library[] } }>;
    extra = { id: game + "-liteloader", inheritsFrom: game, mainClass: "net.minecraft.launchwrapper.Launch", minecraftArguments: '--username "${auth_player_name}" --version "${version_name}" --gameDir "${game_directory}" --assetsDir "${assets_root}" --assetIndex "${assets_index_name}" --uuid "${auth_uuid}" --accessToken "${auth_access_token}" --userType "${user_type}" --tweakClass com.mumfrey.liteloader.launch.LiteLoaderTweaker', libraries: games[game].snapshots.libraries.map((lib) => ({ ...lib, url: lib.url || base })) };
  } else {
    const group = loader === "forge" ? "net/minecraftforge/forge" : "net/neoforged/neoforge";
    const artifact = loader === "forge" ? `${game}-${version}` : version;
    const base = loader === "forge" ? "https://maven.minecraftforge.net/" : "https://maven.neoforged.net/releases/";
    const filename = `${loader}-${artifact}-installer.jar`;
    const zip = await JSZip.loadAsync(await (await safeFetch(`${base}${group}/${artifact}/${filename}`)).arrayBuffer());
    const metadata = Object.keys(zip.files).find((n) => n === "version.json" || n.endsWith("/version.json"));
    if (!metadata) throw new UserFacingError("В установщике отсутствуют метаданные версии.");
    extra = JSON.parse(await zip.file(metadata)!.async("string"));
    const profileFile = zip.file("install_profile.json");
    if (profileFile) {
      const profile = JSON.parse(await profileFile.async("string")) as { versionInfo?: MinecraftVersion; libraries?: Library[] };
      if (profile.versionInfo) extra = mergeVersion(extra, profile.versionInfo);
      for (const lib of profile.libraries || []) if (lib.name && rulesAllow(lib.rules)) {
        const artifact = lib.downloads?.artifact;
        if (artifact) await downloadFile(artifact.url || base + artifact.path, path.join(librariesDir, artifact.path), { sha1: artifact.sha1 });
      }
    }
    if (loader === "forge") {
      const universal = `net.minecraftforge:forge:${artifact}:universal`;
      const direct = `${base}${group}/${artifact}/forge-${artifact}-universal.jar`;
      try { await downloadFile(direct, path.join(librariesDir, libraryPath(universal))); }
      catch { const packed = zip.file(`forge-${artifact}-universal.jar`); if (packed) await writeFile(path.join(librariesDir, libraryPath(universal)), await packed.async("nodebuffer")); }
    }
    await writeFile(path.join(instanceRoot, "voxel", "loader-installer.jar"), await zip.file(filename)!.async("nodebuffer"));
    installer = true;
  }
  for (const lib of extra.libraries.filter(allowedOnAnyDesktop)) {
    const artifact = mavenArtifact(lib);
    if (artifact) await downloadFile(artifact.url, path.join(librariesDir, artifact.path), { sha1: artifact.sha1 });
  }
  const result = { version: mergeVersion(await getMinecraftVersion(game), extra), installer };
  await writeFile(path.join(instanceRoot, "voxel", "loader-version.json"), JSON.stringify(result));
  return result;
}
