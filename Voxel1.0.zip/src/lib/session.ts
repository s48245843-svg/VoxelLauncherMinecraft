import { cookies } from "next/headers";
import { randomBytes, randomUUID } from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { installationJobs, launcherSessions, launcherSettings, minecraftAccounts, minecraftProfiles } from "@/db/schema";
import { starterProfiles } from "./catalog";
import { defaultSettings, type AccountCredentials } from "./types";
import { decryptCredentials } from "./oauth";
import type { Account, LauncherData, Loader, Profile } from "./types";

export async function getSession(create = true): Promise<string> {
  const jar = await cookies();
  const existing = jar.get("voxel_session")?.value;
  if (existing && /^[a-f0-9]{64}$/.test(existing)) {
    const [session] = await db.select().from(launcherSessions).where(eq(launcherSessions.id, existing)).limit(1);
    if (session) return existing;
  }
  if (!create) throw new Error("Сессия не найдена. Обновите страницу.");
  const id = randomBytes(32).toString("hex");
  await db.transaction(async (tx) => {
    await tx.insert(launcherSessions).values({ id });
    await tx.insert(launcherSettings).values({ sessionId: id, ...defaultSettings });
    await tx.insert(minecraftProfiles).values(starterProfiles.map(({ createdAt: _date, ...p }) => { void _date; return { ...p, id: randomUUID(), sessionId: id }; }));
    await tx.insert(minecraftAccounts).values({ id: randomUUID(), sessionId: id, username: "Steve", uuid: "8667ba93bfa9447a99d26e2c6a2b1e4b", type: "offline", active: true });
  });
  jar.set("voxel_session", id, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 365 });
  return id;
}

export async function getLauncherData(sessionId: string): Promise<LauncherData> {
  const [profiles, accounts, settings, jobs] = await Promise.all([
    db.select().from(minecraftProfiles).where(eq(minecraftProfiles.sessionId, sessionId)).orderBy(minecraftProfiles.createdAt),
    db.select().from(minecraftAccounts).where(eq(minecraftAccounts.sessionId, sessionId)).orderBy(minecraftAccounts.createdAt),
    db.select().from(launcherSettings).where(eq(launcherSettings.sessionId, sessionId)).limit(1),
    db.select().from(installationJobs).where(eq(installationJobs.sessionId, sessionId)).orderBy(desc(installationJobs.createdAt)).limit(20),
  ]);
  const { sessionId: _session, ...publicSettings } = settings[0];
  void _session;
  return {
    profiles: profiles.map(({ sessionId: _owner, ...p }) => ({ ...p, loader: p.loader as Loader, createdAt: p.createdAt.toISOString() })) as Profile[],
    accounts: accounts.map(({ sessionId: _owner, credentials, createdAt: _date, ...a }) => ({ ...a, type: a.type as Account["type"], expiresAt: credentials ? decryptCredentials(credentials).expiresAt : undefined })) as Account[],
    settings: publicSettings,
    jobs: jobs.map(({ sessionId: _owner, createdAt: _date, ...j }) => j),
  };
}

export async function ownedProfile(id: string, sessionId: string) {
  const [profile] = await db.select().from(minecraftProfiles).where(and(eq(minecraftProfiles.id, id), eq(minecraftProfiles.sessionId, sessionId))).limit(1);
  return profile;
}

export function safeDirectory(input: string): string {
  const value = input.trim().replace(/\\/g, "/").replace(/^[a-zA-Z]:/, "").replace(/^\/+|\/+$/g, "");
  if (!value || value.split("/").includes("..") || /[\x00-\x1f<>:"|?*]/.test(value)) throw new Error("Укажите безопасное имя папки, например .minecraft или instances/main.");
  return value;
}
