export type LaunchAccount = { username: string; uuid: string; type: string };
export type LaunchConfig = { profileName: string };
export function launchScripts(): Record<string, string> { return {}; }
