import path from "node:path";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import JSZip from "jszip";
import { randomUUID } from "node:crypto";
import { fetchJson, UserFacingError } from "./network";
import type { ModpackIndex, ModrinthVersion, Profile } from "./types";

export async function downloadPackFiles(profile: Pick<Profile, "id" | "gameDirectory">, index: ModpackIndex, overridesRoot: string, onProgress: (message: string) => void = () => undefined): Promise<void> {
  if (index.game !== "minecraft" || index.formatVersion !== 1) throw new UserFacingError("Поддерживаются клиентские Minecraft-сборки в формате Modrinth MRPACK v1.");
  if (!Array.isArray(index.files) || index.files.length > 3000) throw new UserFacingError("В сборке слишком много файлов (максимум 3000).");
  const root = process.cwd() + "/data/instances/" + profile.id;
  const gameDir = path.join(root, profile.gameDirectory);
  let done = 0;
  for (const file of index.files) {
    onProgress(`Файлы сборки: ${++done} из ${index.files.length}`);
    if (!file.path || path.isAbsolute(file.path) || file.path.split(/[\\/]/).includes("..") || /[\x00-\x1f]/.test(file.path)) throw new UserFacingError("В сборке обнаружен небезопасный путь файла.");
    if (file.env?.client === "unsupported" || file.env?.server === "required") continue;
    if (!Array.isArray(file.downloads) || !file.downloads.length) throw new UserFacingError(`Для файла ${file.path} отсутствует источник загрузки.`);
    if (!file.hashes?.sha1 && !file.hashes?.sha512) throw new UserFacingError(`Для файла ${file.path} отсутствует контрольная сумма.`);
    const { downloadFile } = await import("./network");
    await downloadFile(file.downloads[0], path.join(gameDir, file.path), { sha1: file.hashes.sha1, sha512: file.hashes.sha512 });
  }
  for (const folder of ["overrides", "client-overrides"]) {
    const source = path.join(overridesRoot, folder);
    let entries;
    try { entries = await readdirSafe(source); } catch { continue; }
    for (const relative of entries) {
      if (relative.endsWith(".exe") || relative.endsWith(".dll") || relative.endsWith(".bat") || relative.endsWith(".cmd")) throw new UserFacingError("В overrides запрещены исполняемые файлы и системные библиотеки.");
      const target = path.join(gameDir, relative);
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, await readFile(path.join(source, relative)));
    }
  }
}
async function readdirSafe(root: string): Promise<string[]> {
  const { readdir } = await import("node:fs/promises");
  const result: string[] = [];
  for (const entry of await readdir(root, { withFileTypes: true })) {
    if (entry.isDirectory()) result.push(...(await readdirSafe(path.join(root, entry.name))).map((name) => entry.name + "/" + name));
    else if (entry.isFile()) result.push(entry.name);
  }
  return result;
}
export async function readModpack(file: File): Promise<{ index: ModpackIndex; overridesRoot: string }> {
  if (file.size > 50 * 1024 * 1024) throw new UserFacingError("Архив должен быть меньше 50 МБ.");
  const zip = await JSZip.loadAsync(await file.arrayBuffer());
  const manifest = zip.file("modrinth.index.json");
  if (!manifest) throw new UserFacingError("Файл не является MRPACK: отсутствует modrinth.index.json. Экспорт CurseForge пока не поддерживается.");
  let expandedSize = 0;
  let count = 0;
  for (const entry of Object.values(zip.files)) {
    if (entry.dir) continue;
    if (++count > 3500) throw new UserFacingError("Слишком много файлов в архиве.");
    if (path.isAbsolute(entry.name) || entry.name.split(/[\\/]/).includes("..") || /[\x00-\x1f]/.test(entry.name)) throw new UserFacingError("Опасный путь в архиве.");
    expandedSize += (entry as unknown as { _data?: { uncompressedSize?: number } })._data?.uncompressedSize || 0;
    if (expandedSize > 100 * 1024 * 1024) throw new UserFacingError("Распакованный архив превышает 100 МБ.");
  }
  const index = JSON.parse(await manifest.async("string")) as ModpackIndex;
  if (!index.dependencies || typeof index.dependencies.minecraft !== "string") throw new UserFacingError("В сборке не указана версия Minecraft.");
  const overridesRoot = path.join(process.cwd(), "data", "imports", randomUUID());
  await mkdir(overridesRoot, { recursive: true });
  for (const [name, entry] of Object.entries(zip.files)) {
    if (entry.dir || !/^(overrides|client-overrides)\//.test(name)) continue;
    const target = path.join(overridesRoot, name);
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(target, await entry.async("nodebuffer"));
  }
  return { index, overridesRoot };
}
function filenameSafe(input: string) { return input.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 80); }
export async function resolveModVersion(projectId: string, gameVersion: string, loader: string, versionId?: string): Promise<ModrinthVersion> {
  const query = new URLSearchParams({ game_versions: JSON.stringify([gameVersion]) });
  if (loader !== "vanilla") query.set("loaders", JSON.stringify([loader]));
  const versions = await fetchJson<ModrinthVersion[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(projectId)}/version?${query}`);
  const version = versionId ? versions.find((v) => v.id === versionId) : versions[0];
  if (!version) throw new UserFacingError(`Для ${gameVersion} / ${loader} нет совместимой версии проекта.`);
  const file = version.files.find((f) => f.primary) || version.files[0];
  if (!file) throw new UserFacingError("В версии проекта нет файлов для скачивания.");
  return version;
}
export function instanceRoot(profileId: string) { return path.join(process.cwd(), "data", "instances", profileId); }
