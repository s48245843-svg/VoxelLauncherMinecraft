export const DESKTOP_VERSION = "3.0.0";
export const DESKTOP_DESCRIPTION = "Voxel — нативный лаунчер Minecraft на Python и Qt: обложки, плавные анимации, версии игры, загрузчики, моды и сборки Modrinth/CurseForge. Файлы скачиваются и проверяются на компьютере. Веб-интерфейс используется только в каталоге.";
