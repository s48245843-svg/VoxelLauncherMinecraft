import "server-only";
import { createHash } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import JSZip from "jszip";
import { DESKTOP_VERSION, DESKTOP_DESCRIPTION } from "./index";

const root = path.join(process.cwd(), "desktop");
const excluded = new Set(["__pycache__", ".venv", "data", "build", "dist", ".git"]);
let archivePromise: Promise<{ buffer: ArrayBuffer; bytes: number; fileCount: number; sha256: string; sourceBytes: number }> | undefined;

async function makeArchive() {
  const zip = new JSZip();
  let fileCount = 0;
  let sourceBytes = 0;
  async function add(directory: string, prefix: string) {
    const entries = await readdir(directory, { withFileTypes: true });
    entries.sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      if (excluded.has(entry.name) || entry.name.endsWith(".pyc")) continue;
      const fullPath = path.join(directory, entry.name);
      const name = `${prefix}/${entry.name}`;
      if (entry.isDirectory()) await add(fullPath, name);
      else if (entry.isFile()) {
        const data = await readFile(fullPath);
        sourceBytes += data.byteLength;
        fileCount++;
        zip.file(name, data, { date: new Date("2026-01-01T00:00:00Z"), unixPermissions: /\.(sh|command)$/.test(entry.name) ? 0o755 : 0o644, compression: /\.(png|jpg)$/.test(entry.name) ? "STORE" : "DEFLATE" });
      }
    }
  }
  await add(root, "VoxelLauncher");
  const zipped = await zip.generateAsync({ type: "uint8array", compression: "DEFLATE", compressionOptions: { level: 6 }, platform: "UNIX" });
  return { buffer: zipped.buffer.slice(zipped.byteOffset, zipped.byteOffset + zipped.byteLength) as ArrayBuffer, bytes: zipped.byteLength, fileCount, sourceBytes, sha256: createHash("sha256").update(zipped).digest("hex") };
}

export function getDesktopArchive() {
  if (!archivePromise) archivePromise = makeArchive().catch((error) => { archivePromise = undefined; throw error; });
  return archivePromise;
}

export async function desktopInfo() {
  const { bytes, fileCount, sha256, sourceBytes } = await getDesktopArchive();
  return { version: DESKTOP_VERSION, description: DESKTOP_DESCRIPTION, bytes, files: fileCount, sourceBytes, sha256, requirement: "Python 3.10–3.13 · PySide6 / Qt 6.8", platforms: ["Windows x64", "macOS", "Linux"], nativeShell: true, webCatalogOnly: true, curseforgeRequiresApiKey: true, artworkIncluded: true, download: "/VoxelLauncher.zip", windowsExecutableIncluded: false };
}

export async function desktopResponse() {
  const archive = await getDesktopArchive();
  return new Response(archive.buffer, { headers: { "Content-Type": "application/zip", "Content-Length": String(archive.bytes), "Content-Disposition": `attachment; filename="VoxelLauncher-${DESKTOP_VERSION}.zip"`, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Archive-SHA256": archive.sha256 } });
}
