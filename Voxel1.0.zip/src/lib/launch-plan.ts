import type { ArchName, Argument, MinecraftVersion, OsName } from "./game";
import { mavenArtifact, rulesAllow } from "./game";
import type { Settings } from "./types";

export const launchTargets: { os: OsName; arch: ArchName }[] = [
  { os: "windows", arch: "x64" }, { os: "windows", arch: "arm64" },
  { os: "linux", arch: "x64" }, { os: "linux", arch: "arm64" },
  { os: "osx", arch: "x64" }, { os: "osx", arch: "arm64" },
];
export function dashedUuid(uuid: string): string {
  const hex = uuid.replace(/-/g, "").toLowerCase();
  return /^[a-f0-9]{32}$/.test(hex) ? `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}` : uuid;
}
function replaceTokens(value: string, values: Record<string, string>): string {
  return value.replace(/\$\{([^}]+)\}/g, (_match, key: string) => values[key] ?? "");
}
export function classpath(game: MinecraftVersion, os: OsName, arch: ArchName): string[] {
  const jars: string[] = [];
  for (const lib of game.libraries || []) {
    if (!rulesAllow(lib.rules, os, arch)) continue;
    const artifact = mavenArtifact(lib);
    if (!artifact || /natives-/.test(artifact.path)) continue;
    jars.push("libraries/" + artifact.path.replace(/\\/g, "/"));
  }
  jars.push(`versions/${game.id}/${game.id}.jar`);
  return [...new Set(jars)];
}
export function launchArguments(game: MinecraftVersion, os: OsName, arch: ArchName, account: { username: string; uuid: string; type: string; accessToken?: string }, settings: Settings, memory: number): { jvm: string[]; game: string[] } {
  const logging = game.logging?.client?.file;
  const values: Record<string, string> = {
    auth_player_name: account.username,
    auth_uuid: dashedUuid(account.uuid),
    auth_access_token: account.accessToken || "0",
    auth_xuid: "0",
    user_type: account.type === "microsoft" ? "msa" : "legacy",
    version_name: game.id,
    game_directory: ".",
    assets_root: "assets",
    assets_index_name: game.assetIndex?.id || "legacy",
    library_directory: "libraries",
    natives_directory: `natives/${os}${arch === "arm64" ? "-arm64" : ""}`,
    classpath_separator: os === "windows" ? ";" : ":",
    launcher_name: "Voxel",
    launcher_version: "1.5.0",
    version_type: "release",
    resolution_width: String(settings.resolutionWidth),
    resolution_height: String(settings.resolutionHeight),
    path: logging ? `versions/${game.id}/${logging.id}` : "",
    clientid: "",
    auth_session: account.accessToken || "0",
    user_properties: "{}",
  };
  const expand = (items: Argument[] | undefined) => (items || []).flatMap((item) => {
    if (typeof item === "string") return [replaceTokens(item, values)];
    if (!rulesAllow(item.rules, os, arch) || !item.value) return [];
    return (Array.isArray(item.value) ? item.value : [item.value]).map((value) => replaceTokens(value, values));
  });
  const jvm = expand(game.arguments?.jvm).filter((arg, index, all) => {
    if (arg === "-cp" || arg === "-classpath" || arg.startsWith("-Djava.library.path=") || arg.startsWith("-Xmx") || arg.startsWith("-Xms")) return false;
    if (all[index - 1] === "-cp" || all[index - 1] === "-classpath") return false;
    return arg !== "" && arg !== "${classpath}";
  });
  let gameArgs = game.arguments?.game ? expand(game.arguments.game) : (game.minecraftArguments || "").match(/"[^"]*"|[^\s]+/g)?.map((arg) => replaceTokens(arg.replace(/^"|"$/g, ""), values)) || [];
  gameArgs = gameArgs.map((arg) => arg.replace(/forgeserver/g, "forgeclient").replace(/neoforgeserver/g, "neoforgeclient"));
  if (!settings.fullScreen && !gameArgs.includes("--fullscreen") && !gameArgs.includes("--width")) gameArgs.push("--width", String(settings.resolutionWidth), "--height", String(settings.resolutionHeight));
  return { jvm, game: gameArgs.filter((arg) => arg !== "") };
}
export function argumentFile(args: string[], classpathJars: string[], separator: string): string {
  return [...args, "-cp", classpathJars.join(separator)].map((arg) => arg.includes(" ") ? `"${arg}"` : arg).join("\n") + "\n";
}
