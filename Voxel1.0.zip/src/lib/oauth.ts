import { cookies } from "next/headers";
import { createCipheriv, createDecipheriv, createHash, randomBytes, randomUUID } from "node:crypto";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { minecraftAccounts, oauthStates } from "@/db/schema";
import { UserFacingError } from "./network";
import type { AccountCredentials } from "./types";

function encryptionKey() { const secret = process.env.AUTH_SECRET || process.env.DATABASE_URL; if (!secret) throw new Error("AUTH_SECRET is required"); return createHash("sha256").update(secret).digest(); }
export function encryptCredentials(credentials: AccountCredentials): string {
  const iv = randomBytes(12); const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(credentials), "utf8"), cipher.final()]);
  return [iv.toString("hex"), cipher.getAuthTag().toString("hex"), encrypted.toString("hex")].join(":");
}
export function decryptCredentials(value: string): AccountCredentials {
  const [iv, tag, encrypted] = value.split(":");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(iv, "hex"));
  decipher.setAuthTag(Buffer.from(tag, "hex"));
  const plaintext = Buffer.concat([decipher.update(Buffer.from(encrypted, "hex")), decipher.final()]).toString("utf8");
  const credentials: unknown = JSON.parse(plaintext);
  return credentials as AccountCredentials;
}
export function oauthConfig(provider: string, origin: string) {
  const redirectUri = provider === "microsoft" ? process.env.MICROSOFT_REDIRECT_URI : process.env.ELYBY_REDIRECT_URI;
  const id = provider === "microsoft" ? process.env.MICROSOFT_CLIENT_ID : process.env.ELYBY_CLIENT_ID;
  const secret = provider === "microsoft" ? process.env.MICROSOFT_CLIENT_SECRET : process.env.ELYBY_CLIENT_SECRET;
  if (!id || (provider === "ely" && !secret)) throw new UserFacingError(`Вход ${provider === "microsoft" ? "Microsoft" : "Ely.by"} ещё не настроен администратором. Добавьте ${provider === "microsoft" ? "MICROSOFT_CLIENT_ID и MICROSOFT_CLIENT_SECRET" : "ELYBY_CLIENT_ID и ELYBY_CLIENT_SECRET"} в серверные переменные окружения. Офлайн-вход доступен уже сейчас.`);
  return { id, secret, redirect: redirectUri || `${origin}/api/auth/${provider}/callback`, tokenEndpoint: provider === "microsoft" ? "https://login.microsoftonline.com/consumers/oauth2/v2.0/token" : "https://account.ely.by/api/oauth2/v1/token", scope: provider === "microsoft" ? "XboxLive.signin offline_access" : "account_info account_email offline_access" };
}
async function postForm(url: string, values: Record<string, string>): Promise<Record<string, unknown>> {
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(values), signal: AbortSignal.timeout(30000) });
  const data = await response.json() as Record<string, unknown>;
  if (!response.ok || data.error) throw new UserFacingError(`Сервис авторизации отклонил запрос: ${String(data.error_description || data.error || response.status)}`);
  return data;
}
async function postJson<T>(url: string, body: object, headers: Record<string, string> = {}): Promise<T> {
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json", ...headers }, body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
  if (!response.ok) throw new UserFacingError(`Игровой сервис авторизации вернул ошибку ${response.status}. Проверьте, что приложение Minecraft одобрено Microsoft.`);
  return await response.json() as T;
}
export async function authenticateMicrosoft(verifier: string, config: ReturnType<typeof oauthConfig>): Promise<AccountCredentials> {
  const token = await postForm(config.tokenEndpoint, { client_id: config.id, client_secret: config.secret || "", grant_type: "authorization_code", code: verifier, redirect_uri: config.redirect, code_verifier: "" });
  return microsoftChain(String(token.access_token), String(token.refresh_token || ""));
}
async function microsoftChain(accessToken: string, refreshToken: string): Promise<AccountCredentials> {
  const xbl = await postJson<{ Token: string; DisplayClaims: { xui: { uhs: string }[] } }>("https://user.auth.xboxlive.com/user/authenticate", { Properties: { AuthMethod: "RPS", SiteName: "user.auth.xboxlive.com", RpsTicket: "d=" + accessToken }, RelyingParty: "http://auth.xboxlive.com", TokenType: "JWT" }, { "x-xbl-contract-version": "1" });
  const xsts = await postJson<{ Token: string; DisplayClaims: { xui: { uhs: string; xid: string }[] } }>("https://xsts.auth.xboxlive.com/xsts/authorize", { Properties: { SandboxId: "RETAIL", UserTokens: [xbl.Token] }, RelyingParty: "rp://api.minecraftservices.com/", TokenType: "JWT" }, { "x-xbl-contract-version": "2" });
  const claim = xsts.DisplayClaims.xui[0];
  const minecraft = await postJson<{ access_token: string; expires_in: number }>("https://api.minecraftservices.com/authentication/login_with_xbox", { identityToken: `XBL3.0 x=${claim.uhs};${xsts.Token}` });
  return { accessToken: minecraft.access_token, refreshToken, expiresAt: Date.now() + minecraft.expires_in * 1000, userHash: claim.uhs, xuid: claim.xid };
}
export async function refreshMicrosoft(refreshToken: string): Promise<AccountCredentials> {
  const clientId = process.env.MICROSOFT_CLIENT_ID;
  if (!clientId) throw new UserFacingError("Для обновления Microsoft сессии нужен MICROSOFT_CLIENT_ID.");
  const token = await postForm("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", { client_id: clientId, grant_type: "refresh_token", refresh_token: refreshToken, scope: "XboxLive.signin offline_access" });
  return microsoftChain(String(token.access_token), String(token.refresh_token || refreshToken));
}
export async function authenticateEly(verifier: string, config: ReturnType<typeof oauthConfig>): Promise<AccountCredentials> {
  const token = await postForm(config.tokenEndpoint, { client_id: config.id, client_secret: config.secret || "", grant_type: "authorization_code", code: verifier, redirect_uri: config.redirect });
  return { accessToken: String(token.access_token), refreshToken: String(token.refresh_token || ""), expiresAt: Date.now() + Number(token.expires_in || 86400) * 1000 };
}
export async function refreshEly(refreshToken: string): Promise<AccountCredentials> {
  const config = oauthConfig("ely", "http://localhost");
  const token = await postForm(config.tokenEndpoint, { client_id: config.id, client_secret: config.secret || "", grant_type: "refresh_token", refresh_token: refreshToken, scope: config.scope });
  return { accessToken: String(token.access_token), refreshToken: String(token.refresh_token || ""), expiresAt: Date.now() + Number(token.expires_in || 86400) * 1000 };
}
export async function beginOAuth(provider: string, origin: string, sessionId: string) {
  const config = oauthConfig(provider, origin);
  const state = randomBytes(32).toString("hex"); const verifier = randomBytes(48).toString("base64url");
  const cookie = state + "." + verifier;
  await db.insert(oauthStates).values({ state, sessionId, provider, verifier, expiresAt: new Date(Date.now() + 10 * 60 * 1000) });
  (await cookies()).set("voxel_oauth", cookie, { httpOnly: true, sameSite: "lax", path: "/api/auth", maxAge: 600, secure: origin.startsWith("https:") });
  const challenge = createHash("sha256").update(verifier).digest("base64url");
  const url = new URL(provider === "microsoft" ? "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize" : "https://account.ely.by/oauth2/v1");
  url.search = new URLSearchParams({ client_id: config.id, redirect_uri: config.redirect, response_type: "code", scope: config.scope, state, ...(provider === "microsoft" ? { code_challenge: challenge, code_challenge_method: "S256", prompt: "select_account" } : {}) }).toString();
  return url.toString();
}
export async function finishOAuth(provider: string, params: URLSearchParams, origin: string): Promise<string> {
  const cookie = (await cookies()).get("voxel_oauth")?.value;
  (await cookies()).set("voxel_oauth", "", { path: "/api/auth", maxAge: 0 });
  if (!cookie) throw new UserFacingError("Сессия авторизации не найдена. Начните вход заново.");
  const [state, verifier] = cookie.split(".");
  const [record] = await db.delete(oauthStates).where(and(eq(oauthStates.state, state), eq(oauthStates.provider, provider), gt(oauthStates.expiresAt, new Date()))).returning();
  if (!record || state !== params.get("state") || !params.get("code")) throw new UserFacingError("Сессия авторизации истекла или запрос не совпадает. Начните вход заново.");
  const config = oauthConfig(provider, origin);
  const credentials = provider === "microsoft" ? await authenticateMicrosoft(params.get("code")!, config) : await authenticateEly(params.get("code")!, config);
  let username: string; let uuid: string;
  if (provider === "microsoft") {
    const profile = await fetch("https://api.minecraftservices.com/minecraft/profile", { headers: { Authorization: "Bearer " + credentials.accessToken }, signal: AbortSignal.timeout(30000) });
    if (!profile.ok) throw new UserFacingError("Аккаунт не имеет профиля Minecraft Java или лицензия не найдена. Проверьте наличие игры на account.microsoft.com.");
    const info = await profile.json() as { name: string; id: string }; username = info.name; uuid = info.id;
  } else {
    const response = await fetch("https://account.ely.by/api/account/v1/info", { headers: { Authorization: "Bearer " + credentials.accessToken }, signal: AbortSignal.timeout(30000) });
    if (!response.ok) throw new UserFacingError("Не удалось получить профиль Ely.by.");
    const info = await response.json() as { id: number; username: string };
    username = info.username; uuid = createHash("md5").update("ely.by:" + info.id).digest("hex");
  }
  const id = randomUUID();
  await db.transaction(async (tx) => {
    await tx.update(minecraftAccounts).set({ active: false }).where(eq(minecraftAccounts.sessionId, record.sessionId));
    await tx.insert(minecraftAccounts).values({ id, sessionId: record.sessionId, username, uuid, type: provider, credentials: encryptCredentials(credentials), active: true });
  });
  return `/?auth=${provider}`;
}
