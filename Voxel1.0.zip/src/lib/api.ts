import { NextResponse } from "next/server";
import { UserFacingError } from "./network";
export function apiError(error: unknown) {
  if (error instanceof UserFacingError) return NextResponse.json({ error: error.message }, { status: 400 });
  console.error("[Voxel API]", error);
  const message = error instanceof Error ? error.message : "Неизвестная ошибка";
  if (/relation .* does not exist|ECONNREFUSED|connect ETIMEDOUT/.test(message)) return NextResponse.json({ error: "Сервис временно недоступен. Попробуйте ещё раз." }, { status: 503 });
  return NextResponse.json({ error: "Не удалось выполнить запрос. Попробуйте ещё раз." }, { status: 500 });
}
export function checkOrigin(request: Request) {
  const origin = request.headers.get("origin");
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host");
  if (origin && new URL(origin).host !== host) throw new UserFacingError("Запрос с другого сайта запрещён.");
}
export function textValue(value: unknown, max: number, fallback = ""): string {
  if (value === undefined) return fallback;
  if (typeof value !== "string" || value.length > max) throw new UserFacingError("Некорректная длина текстового поля.");
  return value.trim();
}
export function memoryValue(value: unknown): number {
  if (typeof value !== "number" || !Number.isInteger(value) || value < 1024 || value > 32768) throw new UserFacingError("Выделите от 1 до 32 ГБ оперативной памяти.");
  return value;
}
