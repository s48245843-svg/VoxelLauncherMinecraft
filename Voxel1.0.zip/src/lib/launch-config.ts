import path from "node:path";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { javaMajor, type MinecraftVersion } from "./game";
import { argumentFile, classpath, launchArguments, launchTargets } from "./launch-plan";
import { instanceRoot } from "./modrinth";
import { defaultSettings, type Account, type Profile, type Settings } from "./types";

export async function buildLaunchFiles(profile: Profile, account: Account, credentials: { accessToken?: string; userHash?: string; xuid?: string }, settings: Settings = defaultSettings): Promise<Record<string, Buffer>> {
  const root = instanceRoot(profile.id);
  const gameDir = path.join(root, profile.gameDirectory);
  const game = JSON.parse(await readFile(path.join(gameDir, "versions", profile.gameVersion, `${profile.gameVersion}.json`), "utf8")) as MinecraftVersion;
  const launchDir = path.join(gameDir, ".voxel");
  await mkdir(launchDir, { recursive: true });
  const major = javaMajor(game) === 16 ? 17 : javaMajor(game);
  await writeFile(path.join(launchDir, "java-major.txt"), String(major));
  await writeFile(path.join(launchDir, "mainclass.txt"), game.mainClass + "\n");
  await writeFile(path.join(launchDir, "memory.txt"), String(profile.memory || settings.ram));
  for (const target of launchTargets) {
    const jars = classpath(game, target.os, target.arch);
    const args = launchArguments(game, target.os, target.arch, { ...account, accessToken: credentials.accessToken }, settings, profile.memory || settings.ram);
    const separator = target.os === "windows" ? ";" : ":";
    await writeFile(path.join(launchDir, `jvm-${target.os}-${target.arch}.txt`), argumentFile([...args.jvm, ...(profile.jvmArgs.match(/"[^"]*"|\S+/g) || [])], jars, separator));
    await writeFile(path.join(launchDir, `game-${target.os}-${target.arch}.txt`), args.game.map((arg) => arg.includes(" ") ? `"${arg}"` : arg).join("\n") + "\n");
  }
  const installer = profile.needsInstaller;
  const scripts = playScripts(profile.gameDirectory, installer, account.type === "ely");
  return Object.fromEntries(Object.entries(scripts).map(([name, content]) => [name, Buffer.from(content)]));
}
function playScripts(gameDirectory: string, installer: boolean, ely: boolean): Record<string, string> {
  const ps = String.raw`param()
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$game = Join-Path $root "__GAME__"
Set-Location $game
$arch = if ($env:PROCESSOR_ARCHITECTURE -match "ARM") { "arm64" } else { "x64" }
$os = "windows"
$natives = Join-Path $game ("natives\" + $os + $(if ($arch -eq "arm64") { "-arm64" } else { "" }))
if (-not (Test-Path $natives)) { $natives = Join-Path $game "natives\windows" }
function Find-Java {
  foreach ($candidate in @($env:JAVA_PATH, $env:JAVA_HOME)) { if ($candidate -and (Test-Path (Join-Path $candidate "bin\java.exe"))) { return Join-Path $candidate "bin\java.exe" } }
  if ($env:JAVA_PATH -and (Test-Path $env:JAVA_PATH)) { return $env:JAVA_PATH }
  $cmd = Get-Command java -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  foreach ($rootJava in @("$env:ProgramFiles\Eclipse Adoptium", "$env:ProgramFiles\Java", "$env:ProgramFiles\Microsoft")) {
    $found = Get-ChildItem $rootJava -Recurse -Filter java.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { return $found.FullName }
  }
  $major = Get-Content (Join-Path $game ".voxel\java-major.txt")
  $adoptium = if ($arch -eq "arm64") { "aarch64" } else { "x64" }
  Write-Host "Java не найдена. Скачиваю Java $major с Adoptium…"
  $zip = Join-Path $root "java-runtime.zip"
  Invoke-WebRequest "https://api.adoptium.net/v3/binary/latest/$major/ga/windows/$adoptium/jre/hotspot/normal/eclipse?project=jdk" -OutFile $zip
  Expand-Archive $zip -DestinationPath (Join-Path $root "runtime") -Force
  return (Get-ChildItem (Join-Path $root "runtime") -Recurse -Filter java.exe | Select-Object -First 1).FullName
}
$java = Find-Java
if ("__INSTALLER__" -eq "true" -and -not (Test-Path (Join-Path $game ".voxel-loader-installed"))) {
  Write-Host "Устанавливаю загрузчик Minecraft…"
  & $java -jar (Join-Path $root "voxel\loader-installer.jar") --installClient $game
  if ($LASTEXITCODE -ne 0) { & $java -jar (Join-Path $root "voxel\loader-installer.jar") --install-client $game }
  New-Item -ItemType File -Force (Join-Path $game ".voxel-loader-installed") | Out-Null
}
$ram = Get-Content (Join-Path $game ".voxel\memory.txt")
$main = (Get-Content (Join-Path $game ".voxel\mainclass.txt") | Select-Object -First 1).Trim()
$agent = @()
if ("__ELY__" -eq "true") { $agent = @("-javaagent:" + (Join-Path $root "voxel\authlib-injector.jar") + "=https://authserver.ely.by/api/authlib-injector") }
& $java @agent -Xms512M ("-Xmx" + $ram + "M") "-Djava.library.path=$natives" "-Dorg.lwjgl.system.SharedLibraryExtractPath=$natives" "@.voxel/jvm-$os-$arch.txt" $main "@.voxel/game-$os-$arch.txt"
exit $LASTEXITCODE
`;
  const sh = `#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
GAME="$ROOT/__GAME__"
cd "$GAME"
ARCH="$(uname -m)"
ARCH_NAME="x64"
[ "$ARCH" = "aarch64" ] || [ "$ARCH" = "arm64" ] && ARCH_NAME="arm64"
OS_NAME="$(uname -s)"
case "$OS_NAME" in
  Darwin) OS_KEY="osx"; ADOPTIUM="mac" ;;
  *) OS_KEY="linux"; ADOPTIUM="linux" ;;
esac
NATIVES="$GAME/natives/$OS_KEY"
[ "$ARCH_NAME" = "arm64" ] && [ -d "$GAME/natives/$OS_KEY-arm64" ] && NATIVES="$GAME/natives/$OS_KEY-arm64"
find_java() {
  if [ -n "\${JAVA_PATH:-}" ] && [ -x "$JAVA_PATH" ]; then echo "$JAVA_PATH"; return; fi
  if [ -n "\${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then echo "$JAVA_HOME/bin/java"; return; fi
  if command -v java >/dev/null 2>&1; then command -v java; return; fi
  MAJOR="$(cat "$GAME/.voxel/java-major.txt")"
  ADOPT_ARCH="x64"; [ "$ARCH_NAME" = "arm64" ] && ADOPT_ARCH="aarch64"
  echo "Скачиваю Java $MAJOR…" >&2
  mkdir -p "$ROOT/runtime"
  curl -L "https://api.adoptium.net/v3/binary/latest/$MAJOR/ga/$ADOPTIUM/$ADOPT_ARCH/jre/hotspot/normal/eclipse?project=jdk" -o "$ROOT/java-runtime.tar.gz"
  tar -xzf "$ROOT/java-runtime.tar.gz" -C "$ROOT/runtime"
  find "$ROOT/runtime" -type f -name java | head -n 1
}
JAVA_BIN="$(find_java)"
if [ "__INSTALLER__" = "true" ] && [ ! -f "$GAME/.voxel-loader-installed" ]; then
  "$JAVA_BIN" -jar "$ROOT/voxel/loader-installer.jar" --installClient "$GAME" || "$JAVA_BIN" -jar "$ROOT/voxel/loader-installer.jar" --install-client "$GAME"
  touch "$GAME/.voxel-loader-installed"
fi
RAM="$(cat "$GAME/.voxel/memory.txt")"
MAIN="$(head -n 1 "$GAME/.voxel/mainclass.txt")"
AGENT=()
if [ "__ELY__" = "true" ]; then AGENT=(-javaagent:"$ROOT/voxel/authlib-injector.jar=https://authserver.ely.by/api/authlib-injector"); fi
exec "$JAVA_BIN" "\${AGENT[@]}" -Xms512M -Xmx"\${RAM}"M -Djava.library.path="$NATIVES" -Dorg.lwjgl.system.SharedLibraryExtractPath="$NATIVES" "@.voxel/jvm-$OS_KEY-$ARCH_NAME.txt" "$MAIN" "@.voxel/game-$OS_KEY-$ARCH_NAME.txt"
`;
  return {
    "PLAY.ps1": ps.replace("__GAME__", gameDirectory).replace("__INSTALLER__", String(installer)).replace("__ELY__", String(ely)),
    "PLAY.bat": "@echo off\r\ncd /d \"%~dp0\"\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File \"%~dp0PLAY.ps1\"\r\nif errorlevel 1 pause\r\n",
    "PLAY.sh": sh.replaceAll("__GAME__", gameDirectory).replace("__INSTALLER__", String(installer)).replace("__ELY__", String(ely)),
    "PLAY.command": sh.replaceAll("__GAME__", gameDirectory).replace("__INSTALLER__", String(installer)).replace("__ELY__", String(ely)),
    "README.txt": `VOXEL — настоящий Minecraft\n\n1. Распакуй ВЕСЬ архив в обычную папку. Не запускай игру из окна архива.\n2. Windows: дважды нажми PLAY.bat.\n   macOS: дважды нажми PLAY.command.\n   Linux: bash PLAY.sh.\n3. Если Java не установлена, скрипт скачает её с Adoptium и затем откроет Minecraft.\n\nОфлайн-профиль запускает одиночную игру, но не даёт лицензию и не подходит для серверов с online-mode.\nMicrosoft и Ely.by используют сессию, выбранную в лаунчере перед скачиванием.\n`,
  };
}
