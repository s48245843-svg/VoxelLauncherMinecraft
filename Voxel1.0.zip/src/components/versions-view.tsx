"use client";
import { useEffect, useMemo, useState } from "react";
import { Search, Package, ArrowRight, ChevronDown, ShieldCheck, Plus, X, CalendarDays } from "lucide-react";
import type { MinecraftVersion, Loader } from "@/lib/types";
import { loaderNames } from "@/lib/types";
import { api } from "@/lib/client-api";
import { Spinner } from "./ui";
import { LoaderIcon } from "./launcher";
export default function VersionsView({ initialVersion, onCreate, notify }: { initialVersion: string; onCreate: (version: string, loader?: Loader, loaderVersion?: string) => void; notify: (message: string, error?: boolean) => void }) {
  const [versions, setVersions] = useState<MinecraftVersion[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [channel, setChannel] = useState("release");
  const [limit, setLimit] = useState(40);
  const [selected, setSelected] = useState<string | null>(null);
  const [loader, setLoader] = useState<Loader>("fabric");
  const [loaders, setLoaders] = useState<string[]>([]);
  const [loaderLoading, setLoaderLoading] = useState(false);
  const load = () => { setLoading(true); setError(""); api<{ versions: MinecraftVersion[] }>("/api/loaders?action=versions").then((r) => setVersions(r.versions)).catch((e) => setError(e.message)).finally(() => setLoading(false)); };
  useEffect(() => { load(); }, []);
  useEffect(() => {
    if (!selected) return;
    let cancelled = false; setLoaderLoading(true); setLoaders([]);
    api<{ versions: string[] }>(`/api/loaders?game=${selected}&loader=${loader}`).then((r) => { if (!cancelled) setLoaders(r.versions); }).catch((e) => { if (!cancelled) notify(e.message, true); }).finally(() => { if (!cancelled) setLoaderLoading(false); });
    return () => { cancelled = true; };
  }, [selected, loader, notify]);
  const filtered = useMemo(() => versions.filter((v) => v.id.toLowerCase().includes(query.toLowerCase()) && (channel === "all" || v.type === channel)), [versions, query, channel]);
  return <div className="versions-view"><div className="catalog-note"><ShieldCheck size={19}/><span>Официальный каталог Mojang<span>Все доступные версии Minecraft Java</span></span><button className="text-link" onClick={load}>Обновить<ArrowRight size={14}/></button></div><div className="view-toolbar"><div className="filter-tabs"><button className={channel === "release" ? "active" : ""} onClick={() => { setChannel("release"); setLimit(40); }}>Релизы</button><button className={channel === "snapshot" ? "active" : ""} onClick={() => { setChannel("snapshot"); setLimit(40); }}>Снапшоты</button><button className={channel === "all" ? "active" : ""} onClick={() => { setChannel("all"); setLimit(40); }}>Все версии</button></div><div className="small-search"><Search size={15}/><input aria-label="Поиск версии Minecraft" placeholder="Например, 1.20.1" value={query} onChange={(e) => { setQuery(e.target.value); setLimit(40); }}/>{query && <button aria-label="Очистить" onClick={() => setQuery("")}><X size={13}/></button>}</div></div>{error ? <div className="empty-state"><Package size={32}/><h3>Каталог временно недоступен</h3><p>{error}</p><button className="button button-secondary" onClick={load}>Попробовать снова</button></div> : <div className="version-table"><div className="version-table-head"><span>Версия</span><span>Канал</span><span>Дата релиза</span><span/></div>{loading ? <div className="loading-row"><Spinner/>Загружаем официальный каталог…</div> : filtered.slice(0, limit).map((v) => <div className={`version-row ${selected === v.id ? "selected" : ""}`} key={v.id}><button className="version-name" onClick={() => setSelected(selected === v.id ? null : v.id)}><span className="version-icon"><Package size={18}/></span><strong>{v.id}</strong>{versions[0]?.id === v.id && <small>Последняя версия</small>}</button><span className={`channel-badge ${v.type}`}>{v.type === "release" ? "Релиз" : v.type === "snapshot" ? "Снапшот" : "Alpha / Beta"}</span><span className="version-date">{new Date(v.releaseTime).toLocaleDateString("ru-RU")}</span><button className="version-install" onClick={() => setSelected(selected === v.id ? null : v.id)}>Установить<Plus size={15}/></button></div>)}{!loading && filtered.length === 0 && <div className="empty-state"><Search size={30}/><h3>Версия не найдена</h3><p>Попробуй другой номер или канал «Все версии».</p></div>}{filtered.length > limit && <button className="load-more" onClick={() => setLimit(limit + 40)}>Показать ещё<ChevronDown size={16}/></button>}</div>}
  {selected && <div className="loader-selection-panel"><div><span className="eyebrow">ТВОЯ ВЕРСИЯ. ТВОЙ ЗАГРУЗЧИК.</span><h2>Minecraft {selected}</h2><p>Добавь возможности, которые меняют игру.</p></div><div className="loader-options">{(["vanilla", "fabric", "forge", "neoforge", "quilt", "liteloader"] as Loader[]).map((l) => <button className={loader === l ? "selected" : ""} key={l} onClick={() => setLoader(l)}><LoaderIcon loader={l} size={22}/>{loaderNames[l]}</button>)}</div><div className="loader-selection-footer">{loaderLoading ? <span><Spinner size={16}/>Получаем версии загрузчика…</span> : loader === "vanilla" ? <span>Оригинальный Minecraft без модов.</span> : <label>Версия {loaderNames[loader]}<select value={loaders[0] || ""} onChange={(e) => { const value = e.target.value; onCreate(selected, loader, value); }}>{loaders.map((v) => <option key={v}>{v}</option>)}{!loaders.length && <option value="">Нет совместимых версий</option>}</select></label>}<button className="button button-primary" onClick={() => onCreate(selected, loader, loaders[0])}><Plus size={16}/>Создать сборку</button></div><p className="loader-selection-note">Загрузчик и его версию можно выбрать в следующем окне. Один основной загрузчик на сборку.</p></div>}
  </div>;
}
