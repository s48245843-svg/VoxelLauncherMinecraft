"use client";

import { useEffect, useState } from "react";
import { ArrowDownToLine, Check, ChevronRight, FolderArchive, Layers3, Monitor, ShieldCheck, Sparkles, Puzzle, ExternalLink } from "lucide-react";
import { DESKTOP_VERSION } from "@/lib/desktop";
import { DownloadLink, DownloadUrlBox } from "./download-link";

type Info = { bytes: number; files: number; sha256: string };

export default function DesktopRelease() {
  const [info, setInfo] = useState<Info | null>(null);
  const [active, setActive] = useState<"native" | "catalog">("native");
  const [copied, setCopied] = useState(false);
  useEffect(() => { fetch("/api/desktop?info=1").then(r => r.ok ? r.json() : null).then(setInfo).catch(() => undefined); }, []);
  return <div className="native-release">
    <section className="native-release-intro">
      <div className="native-release-copy">
        <span className="native-release-tag"><span/> VOXEL {DESKTOP_VERSION} · NATIVE DESKTOP</span>
        <h2>Тот самый дизайн.<br/><em>Теперь в приложении.</em></h2>
        <p>Настоящее окно на Python и Qt. Панорамные обложки, чёткие иконки и плавные переходы. Веб-панель — только для каталога модов и сборок.</p>
        <div className="native-download-actions"><DownloadLink className="button button-primary"><ArrowDownToLine size={19}/>Скачать Voxel {DESKTOP_VERSION}</DownloadLink><a className="native-source-link" href="#native-instructions">Как запустить <ChevronRight size={15}/></a></div>
        <div className="native-download-meta"><span><FolderArchive size={13}/>{info ? `${(info.bytes / 1048576).toFixed(1)} МБ · ${info.files} файлов` : "ZIP с изображениями и исходниками"}</span><span>Windows · macOS · Linux</span></div>
        <p className="native-requirement">Python 3.10–3.13 · Qt 6.8. Скрипт запуска устанавливает зависимости в отдельную среду.</p>
      </div>
      <div className="native-architecture"><span className="native-arch-icon"><Monitor size={29}/></span><strong>Не сайт в обёртке</strong><p>Главная, сборки, настройки и запуск игры — нативные Qt Widgets.</p><div><span>PYTHON / QT</span><Layers3 size={18}/><span>JAVA / MINECRAFT</span></div><small><Check size={13}/>Без Node.js и локального веб-сервера</small></div>
    </section>
    <section className="native-preview">
      <div className="native-preview-toolbar"><span><i/><i/><i/></span><div><button className={active === "native" ? "active" : ""} onClick={() => setActive("native")}><Monitor size={14}/>Нативный лаунчер</button><button className={active === "catalog" ? "active" : ""} onClick={() => setActive("catalog")}><Puzzle size={14}/>Каталог внутри приложения</button></div><small>Скриншот работающей Qt-сборки</small></div>
      <img src={active === "native" ? "/images/voxel-native.png" : "/images/voxel-catalog.png"} alt={active === "native" ? "Нативное окно Voxel: панорамный баннер, обложки сборок и оранжевые кнопки" : "Встроенный каталог с реальными результатами Modrinth"}/>
    </section>
    <div className="native-proof"><span><ShieldCheck size={24}/></span><div><strong>Проверено не только на картинке</strong><p>Better MC [FABRIC] BMC2: скачаны 333 JAR-мода; проверены хеши 356 файлов. Minecraft 1.20.1, Fabric 0.19.3 и Java установлены.</p></div><b>356 / 356 <small>хешей совпали</small></b></div>
    <section className="native-feature-grid">
      <article><Sparkles/><h3>Без зелёных заглушек</h3><p>Четыре PNG-обложки и шрифт в архиве. Сглаженные SVG-иконки, плавное наведение и смена панорамы.</p></article>
      <article><Puzzle/><h3>Моды и целые сборки</h3><p>Modrinth и CurseForge, версии и зависимости. Импорт .mrpack / .zip с overrides, а не пустой профиль с названием.</p></article>
      <article><ArrowDownToLine/><h3>На твой компьютер</h3><p>Настоящий прогресс, скорость и проверка хешей. Отмена и повтор используют уже проверенные файлы.</p></article>
    </section>
    <section className="native-setup" id="native-instructions"><div className="section-heading"><h2>От архива до первого мира</h2><span className="native-small-tag">Один запуск для всех экранов</span></div><ol><li><span>01</span><div><strong>Распакуй весь архив</strong><p>Не теряй папки assets, catalog и voxel — изображения уже внутри. Старую версию заменять по одному файлу не нужно.</p></div></li><li><span>02</span><div><strong>Запусти приложение</strong><p>Windows: <code>START.bat</code> · Linux: <code>bash start.sh</code> · macOS: <code>bash START.command</code>. Нужен Python 3.10–3.13. При первом запуске скачаются Qt и библиотеки.</p></div></li><li><span>03</span><div><strong>Выбери сборку и установи</strong><p>В каталоге открой проект → выбери версию → подтверди загрузку. После проверки файлов нажми «Играть». Для онлайн-серверов нужна лицензия.</p></div></li></ol></section>
    <aside className="native-limitations"><ShieldCheck size={21}/><div><h3>Прозрачно о CurseForge</h3><p>Для API нужен свой ключ из <a href="https://console.curseforge.com/" target="_blank" rel="noreferrer">консоли CurseForge <ExternalLink size={11}/></a>. Если автор запрещает автоматическую загрузку, приложение покажет недостающие файлы и предложит выбрать их вручную. Без полного набора обязательных файлов сборка не станет «готовой».</p><p>Это архив Python-приложения, не заранее собранный EXE. <code>BUILD_EXE.bat</code> собирает Windows-версию с ресурсами на твоём компьютере.</p></div></aside>
    <DownloadUrlBox/>
    {info && <div className="native-checksum"><span>SHA-256</span><code title={info.sha256}>{info.sha256}</code><button onClick={async () => { try { await navigator.clipboard.writeText(info.sha256); setCopied(true); } catch { window.prompt("SHA-256", info.sha256); } }}>{copied ? "Скопировано" : "Копировать"}</button></div>}
  </div>;
}
