"use client";
import { useEffect, useRef, type ReactNode } from "react";
import { X, LoaderCircle, Check, AlertCircle } from "lucide-react";

export function VoxelLogo({ small = false }: { small?: boolean }) {
  return <svg width={small ? 26 : 38} height={small ? 30 : 42} viewBox="0 0 38 42" fill="none" aria-hidden="true"><path d="M19 1 37 11.5v20L19 42 1 31.5v-20L19 1Z" fill="#F58A3B"/><path d="m19 1 18 10.5L19 22 1 11.5 19 1Z" fill="#FFAA63"/><path d="M19 22v20L1 31.5v-20L19 22Z" fill="#E77329"/><path d="m19 22 18-10.5v20L19 42V22Z" fill="#C95A20"/><path d="m10 6.2 18 10.5M28 6.2 10 16.7M1 21.5 19 32l18-10.5M10 16.7v20M28 16.7v20M19 1v21" stroke="#161719" strokeWidth="1.5" strokeLinejoin="round"/></svg>;
}
export function PixelAvatar({ size = 36, variant = "steve" }: { size?: number; variant?: string }) {
  const pixels = variant === "ely" ? ["gggggggg", "gg....gg", "g.gggg.g", "g.g....g", "g.ggg..g", "g......g", "gg....gg", "gggggggg"] : ["hhhhhhhh", "hhhhhhhh", "hhsssshh", "hssssssh", "snbssbns", "sssrrsss", "sssmmsss", "ssmmmmSS"];
  const colors: Record<string, string> = { h: "#493329", s: "#B98767", n: "#F1EADB", b: "#536C9B", r: "#966347", m: "#6C4230", S: "#B07A5A", g: "#6DB67C" };
  return <svg className="pixel-avatar" width={size} height={size} viewBox="0 0 8 8" shapeRendering="crispEdges" aria-hidden="true">{pixels.flatMap((row, y) => row.split("").map((color, x) => <rect key={x + "-" + y} x={x} y={y} width="1" height="1" fill={colors[color] || "#B98767"}/>))}</svg>;
}
export function MicrosoftLogo({ size = 24 }: { size?: number }) { return <span className="microsoft-logo" style={{ width: size, height: size }} aria-hidden="true"><i/><i/><i/><i/></span>; }
export function Spinner({ size = 18 }: { size?: number }) { return <LoaderCircle size={size} className="spin"/>; }
export function Modal({ title, subtitle, children, onClose, wide = false }: { title: string; subtitle?: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const dialog = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusable = () => Array.from(dialog.current?.querySelectorAll<HTMLElement>('button, input, select, textarea, a[href], [tabindex="0"]') || []).filter((el) => !el.hasAttribute("disabled"));
    focusable()[0]?.focus();
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        const items = focusable(); const first = items[0]; const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener("keydown", key);
    return () => { document.body.style.overflow = oldOverflow; document.removeEventListener("keydown", key); previous?.focus(); };
  }, [onClose]);
  return <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><div ref={dialog} className={`modal ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title}><div className="modal-heading"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div><button className="icon-button" onClick={onClose} aria-label="Закрыть"><X size={20}/></button></div>{children}</div></div>;
}
export function Toast({ message, error = false, onClose }: { message: string; error?: boolean; onClose: () => void }) { return <div className={`toast ${error ? "toast-error" : ""}`} role={error ? "alert" : "status"}>{error ? <AlertCircle size={19}/> : <Check size={19}/>}<span>{message}</span><button onClick={onClose} aria-label="Закрыть уведомление"><X size={16}/></button></div>; }
export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (value: boolean) => void; label: string }) { return <button type="button" className={`toggle ${checked ? "on" : ""}`} role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)}><span/></button>; }
