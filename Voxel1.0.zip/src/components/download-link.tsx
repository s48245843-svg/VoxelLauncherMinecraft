"use client";
import { useEffect, useState } from "react";

export function DownloadLink({ className, children }: { className?: string; children: React.ReactNode }) {
  const [url, setUrl] = useState("/VoxelLauncher.zip");
  useEffect(() => { setUrl(window.location.origin + "/VoxelLauncher.zip"); }, []);
  return <a className={className} href={url} target="_blank" rel="noopener noreferrer">{children}</a>;
}

export function DownloadUrlBox() {
  const [url, setUrl] = useState("");
  const [copied, setCopied] = useState(false);
  useEffect(() => { setUrl(window.location.origin + "/VoxelLauncher.zip"); }, []);
  const copy = async () => {
    try { await navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 2000); }
    catch { window.prompt("Скопируй ссылку:", url); }
  };
  return (
    <div className="download-url-box">
      <p>Если кнопка не сработала (например, сайт открыт во встроенном окне), скопируй ссылку и вставь её в адресную строку новой вкладки браузера:</p>
      <div className="download-url-row">
        <input readOnly value={url} onFocus={(e) => e.currentTarget.select()} />
        <button type="button" className="button button-secondary" onClick={copy}>{copied ? "Скопировано ✓" : "Копировать"}</button>
      </div>
    </div>
  );
}
