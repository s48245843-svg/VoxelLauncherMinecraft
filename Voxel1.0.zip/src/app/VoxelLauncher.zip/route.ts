import { desktopResponse } from "@/lib/desktop/archive";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const GET = desktopResponse;
