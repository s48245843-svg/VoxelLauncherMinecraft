import { after, NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { installationJobs, minecraftProfiles } from "@/db/schema";
import { apiError, checkOrigin } from "@/lib/api";
import { getSession, ownedProfile } from "@/lib/session";
import { UserFacingError } from "@/lib/network";
import { runInstall } from "@/lib/install";

export const maxDuration = 300;
export async function POST(request: Request) {
  try {
    checkOrigin(request);
    const sessionId = await getSession();
    const { profileId } = await request.json();
    const profile = await ownedProfile(String(profileId), sessionId);
    if (!profile) throw new UserFacingError("Сборка не найдена.");
    const active = await db.select().from(installationJobs).where(and(eq(installationJobs.sessionId, sessionId), inArray(installationJobs.status, ["queued", "processing"])));
    if (active.some((j) => j.profileId === profileId)) throw new UserFacingError("Эта сборка уже устанавливается.");
    const id = randomUUID();
    await db.insert(installationJobs).values({ id, sessionId, profileId });
    after(() => runInstall(profileId, id));
    return NextResponse.json({ ok: true, jobId: id });
  } catch (error) { return apiError(error); }
}
export async function DELETE(request: Request) {
  try {
    checkOrigin(request); const sessionId = await getSession(); const { jobId } = await request.json();
    const [job] = await db.select().from(installationJobs).where(and(eq(installationJobs.id, String(jobId)), eq(installationJobs.sessionId, sessionId))).limit(1);
    if (!job) throw new UserFacingError("Задача не найдена.");
    if (!["queued", "processing"].includes(job.status)) throw new UserFacingError("Задача уже завершена.");
    if (job.status === "processing") throw new UserFacingError("Загрузка уже началась. Дождитесь её завершения.");
    await db.update(installationJobs).set({ status: "cancelled" }).where(eq(installationJobs.id, job.id));
    return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error); }
}
