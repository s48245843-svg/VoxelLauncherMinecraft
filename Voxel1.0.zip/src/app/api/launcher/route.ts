import { NextResponse } from "next/server";
import { randomBytes, randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { installationJobs, launcherSettings, minecraftAccounts, minecraftProfiles } from "@/db/schema";
import { apiError, checkOrigin, memoryValue, textValue } from "@/lib/api";
import { getLauncherData, getSession, ownedProfile, safeDirectory } from "@/lib/session";
import { UserFacingError } from "@/lib/network";
import { loaderNames, type AccountCredentials, type Loader } from "@/lib/types";
import { rm } from "node:fs/promises";
import path from "node:path";

export const dynamic = "force-dynamic";
export async function GET() {
  try { return NextResponse.json(await getLauncherData(await getSession())); } catch (error) { return apiError(error); }
}
export async function POST(request: Request) {
  try {
    checkOrigin(request);
    const sessionId = await getSession();
    const body = await request.json();
    const action = body.action;
    if (action === "create_profile" || action === "update_profile" || action === "duplicate_profile") {
      const source = body.id ? await ownedProfile(String(body.id), sessionId) : undefined;
      if (body.id && !source) throw new UserFacingError("Сборка не найдена.");
      const name = textValue(body.name, 40, source?.name).trim();
      if (!name) throw new UserFacingError("Введите название сборки.");
      const gameVersion = textValue(body.gameVersion, 40, source?.gameVersion || "1.21.1");
      if (!/^[a-zA-Z0-9._-]{1,40}$/.test(gameVersion)) throw new UserFacingError("Некорректная версия Minecraft.");
      const loader = textValue(body.loader, 20, source?.loader || "vanilla") as Loader;
      if (!(loader in loaderNames)) throw new UserFacingError("Неизвестный загрузчик.");
      const loaderVersion = textValue(body.loaderVersion, 100, source?.loaderVersion || "");
      if (!/^[a-zA-Z0-9.+_-]*$/.test(loaderVersion)) throw new UserFacingError("Некорректная версия загрузчика.");
      const values = { name, gameVersion, loader, loaderVersion, description: textValue(body.description, 180, source?.description), memory: memoryValue(body.memory ?? source?.memory ?? 4096), javaPath: textValue(body.javaPath, 500, source?.javaPath), jvmArgs: textValue(body.jvmArgs, 2000, source?.jvmArgs), gameDirectory: safeDirectory(textValue(body.gameDirectory, 200, source?.gameDirectory || ".minecraft")), icon: textValue(body.icon, 30, source?.icon || "grass"), accent: textValue(body.accent, 30, source?.accent || "orange") };
      if (!["grass", "create", "fabric", "vanilla"].includes(values.icon)) values.icon = "grass";
      if (action === "create_profile") {
        const id = randomUUID();
        await db.insert(minecraftProfiles).values({ ...values, id, sessionId });
        return NextResponse.json({ ok: true, id });
      }
      const changed = source!.gameVersion !== gameVersion || source!.loader !== loader || source!.loaderVersion !== loaderVersion;
      await db.update(minecraftProfiles).set({ ...values, ...(changed ? { installed: false, needsInstaller: false, mods: [] } : {}) }).where(and(eq(minecraftProfiles.id, source!.id), eq(minecraftProfiles.sessionId, sessionId)));
      return NextResponse.json({ ok: true, id: source!.id });
    }
    if (action === "delete_profile") {
      const profile = await ownedProfile(String(body.id), sessionId);
      if (!profile) throw new UserFacingError("Сборка не найдена.");
      const jobs = await db.select().from(installationJobs).where(and(eq(installationJobs.profileId, profile.id), eq(installationJobs.sessionId, sessionId)));
      if (jobs.some((j) => ["queued", "processing"].includes(j.status))) throw new UserFacingError("Сначала дождитесь завершения установки.");
      await db.delete(minecraftProfiles).where(and(eq(minecraftProfiles.id, profile.id), eq(minecraftProfiles.sessionId, sessionId)));
      await rm(path.join(process.cwd(), "data", "instances", profile.id), { recursive: true, force: true });
      return NextResponse.json({ ok: true });
    }
    if (action === "add_offline") {
      const username = textValue(body.username, 16);
      if (!/^[a-zA-Z0-9_]{3,16}$/.test(username)) throw new UserFacingError("Ник должен содержать 3–16 латинских букв, цифр или символов подчёркивания.");
      const id = randomUUID();
      await db.transaction(async (tx) => {
        await tx.update(minecraftAccounts).set({ active: false }).where(eq(minecraftAccounts.sessionId, sessionId));
        await tx.insert(minecraftAccounts).values({ id, sessionId, username, uuid: randomBytes(16).toString("hex"), type: "offline", active: true });
      });
      return NextResponse.json({ ok: true });
    }
    if (action === "select_account" || action === "delete_account" || action === "refresh_account") {
      const [account] = await db.select().from(minecraftAccounts).where(and(eq(minecraftAccounts.id, String(body.id)), eq(minecraftAccounts.sessionId, sessionId))).limit(1);
      if (!account) throw new UserFacingError("Аккаунт не найден.");
      if (action === "select_account") {
        await db.transaction(async (tx) => {
          await tx.update(minecraftAccounts).set({ active: false }).where(eq(minecraftAccounts.sessionId, sessionId));
          await tx.update(minecraftAccounts).set({ active: true }).where(eq(minecraftAccounts.id, account.id));
        });
      } else if (action === "delete_account") {
        const accounts = await db.select().from(minecraftAccounts).where(eq(minecraftAccounts.sessionId, sessionId));
        if (accounts.length < 2) throw new UserFacingError("Нельзя удалить единственный аккаунт.");
        await db.delete(minecraftAccounts).where(eq(minecraftAccounts.id, account.id));
        if (account.active) await db.update(minecraftAccounts).set({ active: true }).where(eq(minecraftAccounts.id, accounts.find((a) => a.id !== account.id)!.id));
      } else {
        const { decryptCredentials, encryptCredentials } = await import("@/lib/oauth");
        const stored = account.credentials ? decryptCredentials(account.credentials) : undefined;
        if (account.type === "offline" || !stored?.refreshToken) throw new UserFacingError("Для этого аккаунта не требуется обновление. Выполните вход заново.");
        const { refreshMicrosoft, refreshEly } = await import("@/lib/oauth");
        const credentials = account.type === "microsoft" ? await refreshMicrosoft(stored.refreshToken) : await refreshEly(stored.refreshToken);
        await db.update(minecraftAccounts).set({ credentials: encryptCredentials({ ...(stored as AccountCredentials), ...(credentials as AccountCredentials) }) }).where(eq(minecraftAccounts.id, account.id));
      }
      return NextResponse.json({ ok: true });
    }
    if (action === "save_settings") {
      const s = body.settings;
      if (!s || typeof s !== "object") throw new UserFacingError("Настройки не переданы.");
      const values = { ram: memoryValue(s.ram), gameDirectory: safeDirectory(textValue(s.gameDirectory, 200)), javaPath: textValue(s.javaPath, 500), jvmArgs: textValue(s.jvmArgs, 2000), resolutionWidth: Number(s.resolutionWidth), resolutionHeight: Number(s.resolutionHeight), fullScreen: s.fullScreen === true, language: ["ru_ru", "en_us"].includes(s.language) ? s.language : "ru_ru", closeOnLaunch: s.closeOnLaunch === true, showSnapshots: s.showSnapshots === true };
      if (![values.resolutionWidth, values.resolutionHeight].every((v) => Number.isInteger(v) && v >= 640 && v <= 7680)) throw new UserFacingError("Разрешение должно быть от 640 до 7680 пикселей.");
      await db.update(launcherSettings).set(values).where(eq(launcherSettings.sessionId, sessionId));
      return NextResponse.json({ ok: true });
    }
    throw new UserFacingError("Неизвестное действие.");
  } catch (error) { return apiError(error); }
}
