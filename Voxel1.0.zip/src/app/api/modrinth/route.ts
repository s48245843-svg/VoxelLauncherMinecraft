import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { after } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { installationJobs, minecraftProfiles } from "@/db/schema";
import { apiError, checkOrigin } from "@/lib/api";
import { getSession, ownedProfile, safeDirectory } from "@/lib/session";
import { downloadFile, fetchJson, UserFacingError } from "@/lib/network";
import { instanceRoot, readModpack, resolveModVersion } from "@/lib/modrinth";
import { runInstall } from "@/lib/install";
import type { ModpackIndex, ModrinthProject, ModrinthVersion } from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 300;
export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const project = params.get("project");
    if (project) {
      const [info, versions] = await Promise.all([
        fetchJson<ModrinthProject>(`https://api.modrinth.com/v2/project/${encodeURIComponent(project)}`),
        fetchJson<ModrinthVersion[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(project)}/version`),
      ]);
      return NextResponse.json({ project: info, versions });
    }
    const query = new URLSearchParams({ query: params.get("q") || "", index: params.get("sort") || "relevance", limit: "20" });
    const type = params.get("type") || "mod";
    if (["mod", "modpack"].includes(type)) query.set("facets", JSON.stringify([["project_type:" + type]]));
    const version = params.get("version");
    const loader = params.get("loader");
    if (version && version !== "any") query.set("facets", JSON.stringify([["project_type:" + type], ...(loader && loader !== "vanilla" ? [["categories:" + loader]] : []), ["versions:" + version]]));
    const result = await fetchJson<{ hits: ModrinthProject[]; total_hits: number }>(`https://api.modrinth.com/v2/search?${query}`);
    return NextResponse.json({ ...result, hits: result.hits.map((project) => ({ ...project, project_type: project.project_type || type, loaders: project.loaders || project.categories.filter((c) => ["fabric", "forge", "neoforge", "quilt", "liteloader"].includes(c)), game_versions: project.game_versions || project.versions })) });
  } catch (error) { return apiError(error); }
}
export async function POST(request: Request) {
  try {
    checkOrigin(request); const sessionId = await getSession();
    const body = await request.json();
    if (body.action === "import_modpack") {
      if (!body.file) throw new UserFacingError("Выберите .mrpack файл.");
      const file = await body.file;
      if (typeof file !== "object" || typeof file.arrayBuffer !== "function") throw new UserFacingError("Архив не передан.");
      const { index, overridesRoot } = await readModpack(file);
      const loader = ["fabric", "forge", "neoforge", "quilt", "liteloader"].find((l) => index.dependencies[l]) || "vanilla";
      const id = randomUUID();
      const name = String(index.name || "Импортированная сборка").slice(0, 40);
      await db.insert(minecraftProfiles).values({ id, sessionId, name, gameVersion: index.dependencies.minecraft, loader, loaderVersion: index.dependencies[loader] || "", icon: loader === "fabric" ? "fabric" : "grass", accent: loader === "fabric" ? "purple" : "orange", gameDirectory: safeDirectory(body.gameDirectory || ".minecraft") });
      const jobId = randomUUID();
      await db.insert(installationJobs).values({ id: jobId, sessionId, profileId: id });
      after(() => runInstall(id, jobId, { index, overridesRoot }));
      return NextResponse.json({ ok: true, id, jobId });
    }
    if (body.action === "install_modpack") {
      const projectId = String(body.projectId || "");
      const info = await fetchJson<ModrinthProject>(`https://api.modrinth.com/v2/project/${encodeURIComponent(projectId)}`);
      if (info.project_type !== "modpack") throw new UserFacingError("Этот проект не является сборкой.");
      const versions = await fetchJson<ModrinthVersion[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(projectId)}/version`);
      const version = versions.find((v) => v.game_versions.includes(String(body.gameVersion))) || versions[0];
      if (!version) throw new UserFacingError("Для этой версии нет сборки.");
      const file = version.files.find((f) => f.primary)!;
      const temp = path.join(process.cwd(), "data", "imports", randomUUID() + ".mrpack");
      await downloadFile(file.url, temp, { sha1: file.hashes.sha1, sha512: file.hashes.sha512 });
      const pack = await readModpack(new File([await (await import("node:fs/promises")).readFile(temp)], "pack.mrpack"));
      const loader = ["fabric", "forge", "neoforge", "quilt", "liteloader"].find((l) => pack.index.dependencies[l]) || "vanilla";
      const id = randomUUID(); const jobId = randomUUID();
      await db.insert(minecraftProfiles).values({ id, sessionId, name: info.title.slice(0, 40), gameVersion: pack.index.dependencies.minecraft, loader, loaderVersion: pack.index.dependencies[loader] || "", icon: loader === "fabric" ? "fabric" : "grass", accent: loader === "fabric" ? "purple" : "orange" });
      await db.insert(installationJobs).values({ id: jobId, sessionId, profileId: id });
      after(() => runInstall(id, jobId, pack));
      return NextResponse.json({ ok: true, id, jobId });
    }
    if (body.action !== "install_mod") throw new UserFacingError("Неизвестное действие.");
    const profile = await ownedProfile(String(body.profileId), sessionId);
    if (!profile) throw new UserFacingError("Сборка не найдена.");
    const version = await resolveModVersion(String(body.projectId), profile.gameVersion, profile.loader, body.versionId);
    const file = version.files.find((f) => f.primary) || version.files[0];
    const visited = new Set<string>();
    async function install(version: ModrinthVersion, depth = 0) {
      if (visited.has(version.id) || depth > 12) return;
      visited.add(version.id);
      const selected = version.files.find((f) => f.primary) || version.files[0];
      const folder = path.join(instanceRoot(profile.id), profile.gameDirectory, "mods");
      await mkdir(folder, { recursive: true });
      await downloadFile(selected.url, path.join(folder, selected.filename), { sha1: selected.hashes.sha1, sha512: selected.hashes.sha512 });
      for (const dep of version.dependencies) {
        if (dep.dependency_type !== "required" || !dep.version_id) continue;
        const dependency = await fetchJson<ModrinthVersion>(`https://api.modrinth.com/v2/version/${encodeURIComponent(dep.version_id)}`);
        if (dependency.game_versions.includes(profile.gameVersion) && (profile.loader === "vanilla" || dependency.loaders.includes(profile.loader))) await install(dependency, depth + 1);
      }
    }
    await install(version);
    const mods = [...profile.mods.filter((m) => m.projectId !== version.project_id), { id: version.id, projectId: version.project_id, name: version.name, filename: file.filename, url: file.url }];
    await db.update(minecraftProfiles).set({ mods }).where(eq(minecraftProfiles.id, profile.id));
    return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error); }
}
