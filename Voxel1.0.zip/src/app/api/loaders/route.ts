import { NextResponse } from "next/server";
import { apiError } from "@/lib/api";
import { getLoaderVersions, getVersionManifest } from "@/lib/game";
import type { Loader } from "@/lib/types";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    if (params.get("action") === "versions") {
      const manifest = await getVersionManifest();
      const query = (params.get("q") || "").toLowerCase();
      const channel = params.get("channel") || "release";
      const versions = manifest.versions.filter((v) => (channel === "all" || v.type === channel || (channel === "snapshot" && v.type === "snapshot")) && v.id.toLowerCase().includes(query));
      return NextResponse.json({ versions, latest: manifest.latest });
    }
    const game = params.get("game") || "1.21.1";
    const loader = (params.get("loader") || "fabric") as Loader;
    return NextResponse.json({ versions: await getLoaderVersions(game, loader) });
  } catch (error) { return apiError(error); }
}
