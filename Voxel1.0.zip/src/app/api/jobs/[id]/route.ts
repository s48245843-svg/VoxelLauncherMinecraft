import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { installationJobs } from "@/db/schema";
import { apiError } from "@/lib/api";
import { getSession } from "@/lib/session";
export const dynamic = "force-dynamic";
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params; const sessionId = await getSession();
    const [job] = await db.select().from(installationJobs).where(and(eq(installationJobs.id, id), eq(installationJobs.sessionId, sessionId))).limit(1);
    if (!job) return NextResponse.json({ error: "Задача не найдена." }, { status: 404 });
    const { sessionId: _owner, createdAt: _date, ...publicJob } = job; void _owner; void _date;
    return NextResponse.json(publicJob);
  } catch (error) { return apiError(error); }
}
