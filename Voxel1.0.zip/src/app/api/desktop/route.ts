import { desktopInfo, desktopResponse } from "@/lib/desktop/archive";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (new URL(request.url).searchParams.get("info") === "1") return Response.json(await desktopInfo(), { headers: { "Cache-Control": "no-store" } });
  return desktopResponse();
}
