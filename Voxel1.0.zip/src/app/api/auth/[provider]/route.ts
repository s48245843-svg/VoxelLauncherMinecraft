import { NextResponse } from "next/server";
import { apiError } from "@/lib/api";
import { beginOAuth, oauthConfig } from "@/lib/oauth";
import { getSession } from "@/lib/session";
export const dynamic = "force-dynamic";
export async function GET(request: Request, { params }: { params: Promise<{ provider: string }> }) {
  try {
    const { provider } = await params;
    if (provider === "config") {
      const origin = new URL(request.url).origin;
      let microsoft = false; let ely = false;
      try { oauthConfig("microsoft", origin); microsoft = true; } catch { /* Not configured. */ }
      try { oauthConfig("ely", origin); ely = true; } catch { /* Not configured. */ }
      return NextResponse.json({ microsoft, ely });
    }
    if (provider !== "microsoft" && provider !== "ely") return NextResponse.json({ error: "Неизвестный провайдер." }, { status: 404 });
    return NextResponse.redirect(await beginOAuth(provider, process.env.APP_URL || new URL(request.url).origin, await getSession()));
  } catch (error) { return NextResponse.redirect(new URL("/?auth_error=" + encodeURIComponent(error instanceof Error ? error.message : "Ошибка авторизации"), process.env.APP_URL || new URL(request.url).origin)); }
}
