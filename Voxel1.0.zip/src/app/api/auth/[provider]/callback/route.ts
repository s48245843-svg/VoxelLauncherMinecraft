import { NextResponse } from "next/server";
import { finishOAuth } from "@/lib/oauth";
export const dynamic = "force-dynamic";
export async function GET(request: Request, { params }: { params: Promise<{ provider: string }> }) {
  const origin = process.env.APP_URL || new URL(request.url).origin;
  try {
    const { provider } = await params;
    if (provider !== "microsoft" && provider !== "ely") throw new Error("Неизвестный провайдер авторизации.");
    return NextResponse.redirect(await finishOAuth(provider, new URL(request.url).searchParams, origin));
  } catch (error) { return NextResponse.redirect(new URL("/?auth_error=" + encodeURIComponent(error instanceof Error ? error.message : "Не удалось войти"), origin)); }
}
