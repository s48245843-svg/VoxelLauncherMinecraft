import { NextResponse } from "next/server";
import { createHash } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import JSZip from "jszip";
import { getSession, ownedProfile } from "@/lib/session";
import { instanceRoot } from "@/lib/modrinth";
import { apiError } from "@/lib/api";
import { UserFacingError } from "@/lib/network";
import type { ModpackIndex } from "@/lib/types";
export const dynamic = "force-dynamic";
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params; const profile = await ownedProfile(id, await getSession());
    if (!profile) throw new UserFacingError("Сборка не найдена.");
    const root = instanceRoot(id); const gameDir = path.join(root, profile.gameDirectory);
    const index: ModpackIndex = { formatVersion: 1, game: "minecraft", name: profile.name, versionId: "1.0.0", dependencies: { minecraft: profile.gameVersion, ...(profile.loader !== "vanilla" ? { [profile.loader + "-loader"]: profile.loaderVersion } : {}) }, files: [] };
    for (const mod of profile.mods) {
      if (!mod.url || !mod.filename) continue;
      const data = await readFile(path.join(gameDir, "mods", mod.filename));
      index.files.push({ path: "mods/" + mod.filename, downloads: [mod.url], hashes: { sha1: createHash("sha1").update(data).digest("hex"), sha512: createHash("sha512").update(data).digest("hex") } });
    }
    const zip = new JSZip(); zip.file("modrinth.index.json", JSON.stringify(index, null, 2));
    for (const name of ["config", "resourcepacks", "shaderpacks", "options.txt"]) {
      const source = path.join(gameDir, name);
      try {
        for (const file of await readdir(source, { recursive: true })) {
          const full = path.join(source, String(file));
          const { stat } = await import("node:fs/promises");
          if (!(await stat(full)).isFile()) continue;
          const data = await readFile(full); if (data.length > 20 * 1024 * 1024) continue;
          zip.file("overrides/" + name + "/" + String(file).replace(/\\/g, "/"), data);
        }
      } catch { /* Optional directory. */ }
    }
    try { zip.file("overrides/options.txt", await readFile(path.join(gameDir, "options.txt"))); } catch { /* Default options. */ }
    const buffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
    return new Response(new Uint8Array(buffer), { headers: { "Content-Type": "application/octet-stream", "Content-Disposition": "attachment; filename=\"voxel-export.mrpack\"", "Cache-Control": "private, no-store" } });
  } catch (error) { return apiError(error); }
}
