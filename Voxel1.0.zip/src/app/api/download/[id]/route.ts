import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { createReadStream } from "node:fs";
import { readdir } from "node:fs/promises";
import path from "node:path";
import { PassThrough, Readable } from "node:stream";
import { ZipArchive } from "archiver";
import { db } from "@/db";
import { launcherSettings, minecraftAccounts } from "@/db/schema";
import { getSession, ownedProfile } from "@/lib/session";
import { decryptCredentials } from "@/lib/oauth";
import { buildLaunchFiles } from "@/lib/launch-config";
import { apiError } from "@/lib/api";
import { UserFacingError } from "@/lib/network";
import { instanceRoot } from "@/lib/modrinth";
import type { AccountCredentials, AccountType, Loader } from "@/lib/types";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const sessionId = await getSession();
    const profile = await ownedProfile(id, sessionId);
    if (!profile || !profile.installed) throw new UserFacingError("Сначала установите сборку.");
    const accountId = new URL(request.url).searchParams.get("accountId") || undefined;
    const [account] = await db.select().from(minecraftAccounts).where(accountId ? and(eq(minecraftAccounts.sessionId, sessionId), eq(minecraftAccounts.id, accountId)) : eq(minecraftAccounts.active, true)).limit(1);
    if (!account) throw new UserFacingError("Выберите активный аккаунт.");
    const credentials: Partial<AccountCredentials> = account.credentials ? decryptCredentials(account.credentials) as AccountCredentials : {};
    if (account.type !== "offline" && (!credentials.accessToken || (credentials.expiresAt || 0) < Date.now())) throw new UserFacingError("Сессия аккаунта истекла. Обновите её в разделе «Аккаунты».");
    const [settings] = await db.select().from(launcherSettings).where(eq(launcherSettings.sessionId, sessionId)).limit(1);
    if (account.type === "ely") {
      const { downloadFile } = await import("@/lib/network");
      await downloadFile("https://authlib-injector.yushi.moe/artifact/45/authlib-injector-1.1.45.jar", instanceRoot(profile.id) + "/voxel/authlib-injector.jar");
    }
    const scripts = await buildLaunchFiles({ ...profile, loader: profile.loader as Loader, createdAt: profile.createdAt.toISOString() }, { ...account, type: account.type as AccountType }, credentials, settings);
    const root = instanceRoot(id);
    const output = new PassThrough();
    const zip = new ZipArchive({ store: true });
    const addDirectory = async (directory: string, prefix: string) => {
      const entries = await readdir(directory, { withFileTypes: true });
      for (const entry of entries) {
        const name = prefix + "/" + entry.name;
        if (entry.isDirectory()) await addDirectory(path.join(directory, entry.name), name);
        else if (entry.isFile()) zip.append(createReadStream(path.join(directory, entry.name)), { name });
      }
    };
    const packing = (async () => {
      await addDirectory(root + "/" + profile.gameDirectory, profile.gameDirectory);
      try { await addDirectory(root + "/voxel", "voxel"); } catch { /* Ванильная сборка не требует установщика. */ }
      for (const [name, data] of Object.entries(scripts)) zip.append(Buffer.from(data), { name, mode: name.endsWith(".sh") || name.endsWith(".command") ? 0o755 : undefined });
      await zip.finalize();
    })();
    packing.catch((error) => output.destroy(error));
    zip.on("error", (error) => output.destroy(error));
    zip.pipe(output);
    return new Response(Readable.toWeb(output) as ReadableStream, { headers: { "Content-Type": "application/zip", "Content-Disposition": "attachment; filename=\"Voxel-Minecraft.zip\"", "Cache-Control": "private, no-store" } });
  } catch (error) { return apiError(error); }
}
