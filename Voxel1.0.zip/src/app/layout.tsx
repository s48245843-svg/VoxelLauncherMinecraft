import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
export const metadata: Metadata = { title: "Voxel — твой Minecraft-лаунчер", description: "Все версии Minecraft, Forge, Fabric и NeoForge, моды Modrinth и твои идеальные сборки в одном лаунчере.", icons: { icon: "/icon.svg" } };
export default function RootLayout({ children }: { children: ReactNode }) { return <html lang="ru"><head><link rel="stylesheet" href="/fonts/fonts.css"/></head><body>{children}</body></html>; }
