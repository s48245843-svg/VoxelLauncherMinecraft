import Link from "next/link";
import DesktopRelease from "@/components/desktop-release";

export const metadata = { title: "Voxel 3.0 — скачать нативный лаунчер Minecraft", description: "Python и Qt: PNG-обложки, анимации, реальные моды и сборки Modrinth/CurseForge. WebUI только в каталоге." };

export default function DownloadPage() {
  return <main className="native-download-page"><header className="native-download-header"><Link href="/" className="native-wordmark">voxel<span>.</span></Link><span>MINECRAFT LAUNCHER</span><Link href="/">← Назад в лаунчер</Link></header><DesktopRelease/></main>;
}
