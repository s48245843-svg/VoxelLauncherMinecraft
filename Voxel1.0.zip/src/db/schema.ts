import { boolean, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import type { ModItem } from "@/lib/types";

export const launcherSessions = pgTable("launcher_sessions", {
  id: text("id").primaryKey(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const launcherSettings = pgTable("launcher_settings", {
  sessionId: text("session_id").primaryKey().references(() => launcherSessions.id, { onDelete: "cascade" }),
  ram: integer("ram").default(4096).notNull(),
  gameDirectory: text("game_directory").default(".minecraft").notNull(),
  javaPath: text("java_path").default("").notNull(),
  jvmArgs: text("jvm_args").default("").notNull(),
  resolutionWidth: integer("resolution_width").default(1920).notNull(),
  resolutionHeight: integer("resolution_height").default(1080).notNull(),
  fullScreen: boolean("full_screen").default(false).notNull(),
  language: text("language").default("ru_ru").notNull(),
  closeOnLaunch: boolean("close_on_launch").default(false).notNull(),
  showSnapshots: boolean("show_snapshots").default(false).notNull(),
});

export const minecraftProfiles = pgTable("minecraft_profiles", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull().references(() => launcherSessions.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description").default("Твоя новая история").notNull(),
  gameVersion: text("game_version").notNull(),
  loader: text("loader").default("vanilla").notNull(),
  loaderVersion: text("loader_version").default("").notNull(),
  icon: text("icon").default("grass").notNull(),
  accent: text("accent").default("orange").notNull(),
  memory: integer("memory").default(4096).notNull(),
  javaPath: text("java_path").default("").notNull(),
  jvmArgs: text("jvm_args").default("").notNull(),
  gameDirectory: text("game_directory").default("").notNull(),
  installed: boolean("installed").default(false).notNull(),
  needsInstaller: boolean("needs_installer").default(false).notNull(),
  mods: jsonb("mods").$type<ModItem[]>().default([]).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const minecraftAccounts = pgTable("minecraft_accounts", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull().references(() => launcherSessions.id, { onDelete: "cascade" }),
  username: text("username").notNull(),
  uuid: text("uuid").notNull(),
  type: text("type").notNull(),
  avatar: text("avatar").default("grass").notNull(),
  active: boolean("active").default(false).notNull(),
  credentials: text("credentials"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const installationJobs = pgTable("installation_jobs", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull().references(() => launcherSessions.id, { onDelete: "cascade" }),
  profileId: text("profile_id").notNull(),
  status: text("status").default("queued").notNull(),
  progress: integer("progress").default(0).notNull(),
  message: text("message").default("Подготовка установки…").notNull(),
  error: text("error"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const oauthStates = pgTable("oauth_states", {
  state: text("state").primaryKey(),
  sessionId: text("session_id").notNull().references(() => launcherSessions.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(),
  verifier: text("verifier").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
});
