#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! command -v python3 >/dev/null; then
  echo 'Python 3.10+ is required. Install it from your package manager or python.org.'
  exit 1
fi
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv || { echo 'Ubuntu/Debian: sudo apt install python3-venv'; exit 1; }
fi
.venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
exec .venv/bin/python main.py
