'use strict';
const $ = id => document.getElementById(id);
const state = {source:'modrinth',kind:'modpack',offset:0,total:0,profiles:[],activeProfile:'',project:null,versions:[],searchSerial:0};
let bridge = null, serial=0, pendingSearch=null;
const requests=new Map();
const rpc=(action,data={})=>new Promise((resolve,reject)=>{
  if(!bridge){reject(new Error('Каталог ещё подключается к Python.'));return;}
  const requestId=String(++serial);const timer=setTimeout(()=>{requests.delete(requestId);reject(new Error('Сервис не ответил вовремя. Попробуйте ещё раз.'));},90000);
  requests.set(requestId,{resolve,reject,timer});bridge.request(JSON.stringify({requestId,action,...data}));
});
const el=(tag,cls,value)=>{const node=document.createElement(tag);if(cls)node.className=cls;if(value!==undefined)node.textContent=value;return node;};
const imageUrl=url=>{try{const u=new URL(url);return u.protocol==='https:'&&(u.hostname==='cdn.modrinth.com'||u.hostname.endsWith('.forgecdn.net'))?url:'';}catch{return '';}};
const count=n=>new Intl.NumberFormat('ru',{notation:'compact',maximumFractionDigits:1}).format(n);
const selected=()=>state.profiles.find(p=>p.id===$('target').value);
function updateProfiles(data){
  state.profiles=data.profiles||[];state.activeProfile=data.activeProfile||'';const old=$('target').value;
  $('target').replaceChildren(new Option('Выбери сборку',''),...state.profiles.map(p=>new Option(`${p.name} · ${p.mc} / ${p.loader}`,p.id)));
  $('target').value=state.profiles.some(p=>p.id===old)?old:state.activeProfile;
}
function notice(title,body){$('noticeTitle').textContent=title;$('noticeText').textContent=body;$('notice').hidden=false;$('configure').hidden=state.source!=='curseforge';}
async function search(reset=true){
  if(!bridge)return;
  if(reset)state.offset=0;
  const token=++state.searchSerial;
  $('notice').hidden=true;$('resultsLabel').textContent='Загрузка…';$('results').replaceChildren(...Array.from({length:6},()=>el('div','skeleton')));
  const target=selected();const mc=state.kind==='mod'&&target?target.mc:$('mc').value.trim();
  const loader=state.kind==='mod'&&target?target.loader:$('loader').value;
  try{
    const result=await rpc('search',{source:state.source,kind:state.kind,query:$('query').value,mc,loader,offset:state.offset});
    if(token!==state.searchSerial)return;
    state.total=result.total;$('resultsLabel').textContent=`${state.total.toLocaleString('ru')} проектов · ${state.source==='modrinth'?'Modrinth':'CurseForge'}`;
    renderHits(result.hits);
  }catch(error){if(token!==state.searchSerial)return;$('results').replaceChildren();notice('Каталог недоступен',error.message);$('resultsLabel').textContent='Не удалось загрузить';state.total=0;}
  $('prev').disabled=state.offset===0;$('next').disabled=state.offset+20>=state.total;
  $('pageLabel').textContent=`Страница ${Math.floor(state.offset/20)+1}`;
}
function renderHits(hits){
  $('results').replaceChildren();if(!hits.length){$('results').append(el('div','empty','Ничего не найдено. Измени запрос, версию Minecraft или загрузчик.'));return;}
  for(const hit of hits){
    const card=el('article','project'),img=el('img');card.dataset.projectId=hit.id;card.dataset.source=hit.source;const src=imageUrl(hit.icon);if(src)img.src=src;img.alt='';img.loading='lazy';
    const content=el('div','content');content.append(el('h3','',hit.title),el('span','author',hit.author?`от ${hit.author}`:''),el('p','description',hit.description));
    const bottom=el('div','bottom');bottom.append(el('span','downloads',`${count(hit.downloads)} загрузок`));
    const action=el('button','secondary','Версии и установка');action.addEventListener('click',()=>openProject(hit));bottom.append(action);content.append(bottom);card.append(img,content);$('results').append(card);
  }
}
async function openProject(hit){
  state.project=hit;state.versions=[];$('detailTitle').textContent=hit.title;$('detailSource').textContent=hit.source.toUpperCase();$('detailText').textContent=hit.description;
  const src=imageUrl(hit.icon);if(src)$('detailIcon').src=src;else $('detailIcon').removeAttribute('src');
  $('versions').replaceChildren(new Option('Получаем список версий…',''));$('compatibility').replaceChildren();$('detailError').textContent='';$('install').disabled=true;
  $('detail').showModal();
  const target=selected();
  try{
    const result=await rpc('versions',{source:hit.source,projectId:hit.id,mc:hit.type!=='modpack'&&target?target.mc:$('mc').value.trim(),loader:hit.type==='mod'&&target?target.loader:$('loader').value});
    if(state.project!==hit)return;
    state.project={...hit,...result.project};state.versions=result.versions;
    $('versions').replaceChildren(...result.versions.map(v=>new Option(`${v.name} · ${v.date} · ${v.channel}`,v.id)));
    if(!result.versions.length){$('detailError').textContent='Нет совместимой клиентской версии. Измени фильтры или целевую сборку.';}else{$('install').disabled=false;showCompatibility();}
    $('install').textContent=hit.type==='modpack'?'Установить сборку':'Установить в сборку';
  }catch(error){$('detailError').textContent=error.message;}
}
function showCompatibility(){
  const v=state.versions.find(v=>v.id===$('versions').value);$('compatibility').replaceChildren();
  if(v)for(const value of [...v.mc,...v.loaders].slice(0,12))$('compatibility').append(el('span','',value));
}
$('versions').addEventListener('change',showCompatibility);
$('install').addEventListener('click',()=>{
  const p=state.project;if(!p||!$('versions').value)return;
  if(p.type!=='modpack'&&!selected()){$('detailError').textContent='Сначала выбери целевую сборку над результатами поиска.';return;}
  bridge.install(JSON.stringify({source:p.source,projectId:p.id,versionId:$('versions').value,profileId:$('target').value,kind:p.type,title:p.title}));
  $('detail').close();
});
$('projectPage').addEventListener('click',()=>state.project&&bridge.openExternal(state.project.url));
$('searchForm').addEventListener('submit',e=>{e.preventDefault();search();});
$('retry').addEventListener('click',()=>search());$('configure').addEventListener('click',()=>bridge.configure());
$('import').addEventListener('click',()=>bridge&&bridge.importArchive());$('cancel').addEventListener('click',()=>bridge.cancel());
$('website').addEventListener('click',()=>bridge.openExternal(state.source==='modrinth'?'https://modrinth.com/modpacks':'https://www.curseforge.com/minecraft/search?class=modpacks'));
$('prev').addEventListener('click',()=>{state.offset=Math.max(0,state.offset-20);search(false);});
$('next').addEventListener('click',()=>{state.offset+=20;search(false);});
$('target').addEventListener('change',()=>state.kind!=='modpack'&&search());
function selectFilters(){
 document.querySelectorAll('[data-source]').forEach(b=>b.classList.toggle('selected',b.dataset.source===state.source));
 document.querySelectorAll('[data-kind]').forEach(b=>b.classList.toggle('active',b.dataset.kind===state.kind));
}
document.querySelectorAll('[data-source]').forEach(b=>b.addEventListener('click',()=>{state.source=b.dataset.source;selectFilters();search();}));
document.querySelectorAll('[data-kind]').forEach(b=>b.addEventListener('click',()=>{state.kind=b.dataset.kind;selectFilters();search();}));
window.voxelSearch=data=>{if(!bridge){pendingSearch=data;return;}state.source=data.source||'modrinth';state.kind=data.kind||'modpack';$('query').value=data.query||'';selectFilters();search();};
function progress(event){
 $('job').hidden=false;$('jobTitle').textContent=event.phase==='completed'?'Готово':event.phase==='error'?'Установка прервана':'Загрузка на этот компьютер';
 $('jobText').textContent=event.message||'';
 if(event.total){$('jobProgress').value=Math.min(100,event.done/event.total*100);}else{$('jobProgress').removeAttribute('value');}
 $('jobBytes').textContent=event.received?`${(event.received/1048576).toFixed(1)} МБ получено · ${(event.speed/1048576).toFixed(1)} МБ/с`:'';
 $('cancel').hidden=['completed','error','blocked'].includes(event.phase);
}
if(typeof QWebChannel==='undefined'||!window.qt){
 notice('Открой каталог в Voxel','Это локальная панель приложения. Запусти START.bat / start.sh — только Python-приложение может устанавливать файлы.');$('configure').hidden=true;$('resultsLabel').textContent='Нет связи с приложением';
}else{
 new QWebChannel(qt.webChannelTransport,async channel=>{
  bridge=channel.objects.voxel;
  bridge.response.connect(raw=>{const data=JSON.parse(raw),request=requests.get(data.requestId);if(!request)return;clearTimeout(request.timer);requests.delete(data.requestId);data.error?request.reject(new Error(data.error)):request.resolve(data.data);});
  bridge.progress.connect(raw=>progress(JSON.parse(raw)));bridge.changed.connect(raw=>updateProfiles(JSON.parse(raw)));
  try{updateProfiles(await rpc('status'));}catch(error){notice('Ошибка подключения',error.message);}
  if(pendingSearch){const value=pendingSearch;pendingSearch=null;window.voxelSearch(value);}else search();
 });
}
