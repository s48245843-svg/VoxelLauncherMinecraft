"""Offline safety/behavior regressions. Run: python -m unittest discover -s tests."""
import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from voxel.network import safe_path, verify, UserError, Job, Cancelled
from voxel.packages import inspect_archive, apply_overrides, Installer
from voxel.state import Store, Secrets
from voxel.providers import Catalog
from voxel.accounts import offline


class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()
    def pack(self, entries):
        filename = self.root / "test.mrpack"
        with zipfile.ZipFile(filename, "w") as z:
            for name, value in entries.items(): z.writestr(name, value)
        return filename
    def test_traversal(self):
        for value in ("../pwn.jar", "/tmp/pwn", "C:/x", "mods\\..\\x", "../"):
            with self.assertRaises(UserError): safe_path(self.root, value)
    def test_zip_traversal(self):
        filename = self.pack({"../pwn": "x"})
        with self.assertRaises(UserError): inspect_archive(filename)
    def test_hash(self):
        path = self.root / "a.jar"; path.write_bytes(b"hello")
        self.assertTrue(verify(path, {"sha1":hashlib.sha1(b"hello").hexdigest()},5))
        self.assertFalse(verify(path, {"sha1":"0"*40},5))
    def test_offline_uuid(self):
        account, _ = offline("Steve")
        self.assertEqual(account["uuid"],"5627dd98e6be3c21b8a8e92344183641")
    def test_cancel(self):
        job=Job(); job.cancelled.set()
        with self.assertRaises(Cancelled): job.check()
    def test_client_env_and_overrides(self):
        def item(path,env):return {"path":path,"hashes":{"sha1":"a"*40,"sha512":"a"*128},"fileSize":1,"downloads":["https://cdn.modrinth.com/test"],"env":{"client":env}}
        manifest={"game":"minecraft","formatVersion":1,"name":"Test","dependencies":{"minecraft":"1.20.1","fabric-loader":"0.16.14"},"files":[item("mods/a.jar","required"),item("mods/server.jar","unsupported"),item("mods/optional.jar","optional")]}
        filename=self.pack({"modrinth.index.json":json.dumps(manifest),"overrides/config/test.txt":"common","client-overrides/config/test.txt":"client","server-overrides/config/test.txt":"server"})
        plan=inspect_archive(filename,False); self.assertEqual([r['path'] for r in plan['files']],["mods/a.jar"])
        dest=self.root/'instance';apply_overrides(filename,dest,plan['overrides'],Job());self.assertEqual((dest/'config/test.txt').read_text(),'client')
    def test_failing_game_never_ready(self):
        store=Store(self.root/'store');store.configure({'game_root':str(self.root/'instances')});p=store.add_profile('Broken','1.20.1')
        def fail(*a):raise UserError('Broken Java')
        service=Installer(store,Catalog(Secrets(self.root)),game_install=fail)
        with self.assertRaises(UserError):service.resume(p['id'],Job())
        result=store.profile(p['id']);self.assertFalse(result['installed']);self.assertEqual(result['state'],'error')
    def test_curseforge_requires_key(self):
        class Empty:
            def get(self,key):return None
        c=Catalog(Empty())
        with self.assertRaises(UserError): c.cf('/mods/search')
    def test_curseforge_null_url_is_manual_not_guessed(self):
        class C(Catalog):
            def project(self,*args):return {'url':'https://www.curseforge.com/minecraft/mc-mods/example'}
        c=C(None)
        rec=c.cf_file({'id':2,'modId':1,'fileName':'x.jar','hashes':[{'algo':1,'value':'a'*40}], 'downloadUrl':None,'fileLength':42})
        self.assertEqual(rec['urls'],[]); self.assertIn('/example/download/2',rec['manual_url'])

    def test_manual_curseforge_files_block_until_verified(self):
        blob = b'test-required-jar-content'
        record = {'path':'mods/example.jar','urls':[],'hashes':{'sha1':hashlib.sha1(blob).hexdigest()},'size':len(blob),'source':'curseforge','project_id':'1','version_id':'2','manual_url':'https://www.curseforge.com/minecraft/mc-mods/example/download/2'}
        class Restricted:
            def bulk_cf(self,refs):return [dict(record)]
        store=Store(self.root/'store');store.configure({'game_root':str(self.root/'instances')})
        service=Installer(store,Restricted(),game_install=lambda *args:{'launch_version':'test-only','java':'test-only'})
        manifest={'manifestType':'minecraftModpack','name':'Restricted','minecraft':{'version':'1.20.1','modLoaders':[{'id':'forge-47.3.0','primary':True}]},'files':[{'projectID':1,'fileID':2,'required':True}],'overrides':'overrides'}
        archive=self.pack({'manifest.json':json.dumps(manifest)})
        result=service.import_pack(archive,Job());self.assertFalse(result['installed']);self.assertEqual(result['state'],'blocked');self.assertEqual(len(result['pending']),1)
        wrong=self.root/'wrong.jar';wrong.write_bytes(b'wrong')
        with self.assertRaises(UserError):service.supply_manual(result['id'],0,wrong)
        right=self.root/'right.jar';right.write_bytes(blob)
        service.supply_manual(result['id'],0,right)
        completed=service.resume(result['id'],Job());self.assertTrue(completed['installed']);self.assertEqual(completed['pending'],[])
        self.assertEqual((Path(completed['directory'])/'mods/example.jar').read_bytes(),blob)

    def test_stale_size_with_correct_hashes_normalized(self):
        store=Store(self.root/'store');store.configure({'game_root':str(self.root/'instances')})
        profile=store.add_profile('Stale metadata','1.20.1');target=Path(profile['directory'])/'mods/a.jar';target.parent.mkdir(parents=True);target.write_bytes(b'checked')
        record={'path':'mods/a.jar','urls':[], 'declared_size':1, 'size':None, 'hashes':{'sha1':hashlib.sha1(b'checked').hexdigest(),'sha512':hashlib.sha512(b'checked').hexdigest()}}
        installer=Installer(store,None)
        self.assertEqual(installer.fetch_records(profile,[record],Job()),[])
        self.assertEqual(record['size'],7)

    def test_standalone_restricted_mod_resumes_from_staging(self):
        payload=b'closed-mod'; rec={'path':'mods/closed.jar','urls':[], 'hashes':{'sha1':hashlib.sha1(payload).hexdigest()},'size':len(payload),'source':'curseforge','project_id':'4','version_id':'9'}
        class Restricted:
            def resolve_mod(self,*args):return [dict(rec)]
        store=Store(self.root/'store');store.configure({'game_root':str(self.root/'instances')});p=store.add_profile('Manual mod','1.20.1','forge','47.3.0')
        service=Installer(store,Restricted(),game_install=lambda *a:{'launch_version':'test-only','java':'test-only'})
        result=service.install_mod('curseforge','4','9',p['id'],Job())
        self.assertEqual(result['state'],'blocked');self.assertFalse(result['installed'])
        manual=self.root/'manual.jar';manual.write_bytes(payload);service.supply_manual(p['id'],0,manual)
        self.assertTrue((Path(p['directory'])/'.voxel/staging/mods/closed.jar').exists())
        final=service.resume(p['id'],Job());self.assertEqual(final['state'],'ready');self.assertEqual(final['pending_mods'],[])
        self.assertEqual((Path(p['directory'])/'mods/closed.jar').read_bytes(),payload)

    def test_mod_update_replaces_same_fabric_id_not_unrelated_jars(self):
        store=Store(self.root/'store');store.configure({'game_root':str(self.root/'instances')});p=store.add_profile('Update','1.20.1','fabric','0.16.14')
        directory=Path(p['directory']);(directory/'mods').mkdir(parents=True)
        def jar(path,ident):
            path.parent.mkdir(parents=True,exist_ok=True)
            with zipfile.ZipFile(path,'w') as z:z.writestr('fabric.mod.json',json.dumps({'id':ident,'version':'1'}))
        jar(directory/'mods/old.jar','same_mod');jar(directory/'mods/other.jar','other_mod')
        old=[{'path':'mods/old.jar','source':'overrides'},{'path':'mods/other.jar','source':'overrides'}]
        store.patch(p['id'],mods=old);p=store.profile(p['id'])
        stage=dict(p,directory=str(directory/'.voxel/staging'));jar(Path(stage['directory'])/'mods/new.jar','same_mod')
        record={'path':'mods/new.jar','source':'modrinth','project_id':'abc','version_id':'v1','hashes':{}}
        Installer(store,None).commit_records(p,[record],stage)
        self.assertFalse((directory/'mods/old.jar').exists());self.assertTrue((directory/'mods/other.jar').exists());self.assertTrue((directory/'mods/new.jar').exists())
        self.assertEqual(len(store.profile(p['id'])['mods']),2)


if __name__=='__main__':unittest.main()
