"""Start the native launcher, or run a real headless installation for diagnostics."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path


def cli():
    parser = argparse.ArgumentParser(description="Voxel native launcher")
    parser.add_argument("--import-pack", metavar="PATH", help="Install a complete MRPACK/CurseForge archive without GUI")
    parser.add_argument("--content-only", action="store_true", help="Diagnostic: verify pack files without installing the game (NOT marked playable)")
    args = parser.parse_args()
    if args.import_pack:
        from voxel.state import Store, Secrets
        from voxel.providers import Catalog
        from voxel.packages import Installer
        from voxel.network import Job
        store = Store()
        service = Installer(store, Catalog(Secrets(store.root)))
        if args.content_only:
            # Explicit diagnostic state, never pretend the game is installed.
            def stop_before_game(profile, settings, job):
                store.patch(profile["id"], content_ready=True)
                raise RuntimeError("CONTENT_ONLY: файлы проверены; Minecraft и загрузчик не установлены")
            service.game_install = stop_before_game
        profile = service.import_pack(Path(args.import_pack).resolve(), Job(lambda event: print(json.dumps(event, ensure_ascii=False), flush=True)))
        print(json.dumps({"profile": profile["id"], "state": profile["state"], "directory": profile["directory"]}, ensure_ascii=False))
        return 0 if profile.get("installed") else 2
    from voxel.ui import main
    return main()


if __name__ == "__main__":
    try:
        raise SystemExit(cli())
    except Exception as error:
        import traceback
        traceback.print_exc()
        try:
            if "--import-pack" in sys.argv:
                raise SystemExit(1)
            from PySide6.QtWidgets import QApplication, QMessageBox
            app = QApplication.instance() or QApplication(sys.argv)
            QMessageBox.critical(None, "Voxel — ошибка запуска", str(error) + "\n\nЗапустите START.bat / start.sh из распакованной папки. Подробности — в консоли.")
        except Exception:
            pass
        raise SystemExit(1)
