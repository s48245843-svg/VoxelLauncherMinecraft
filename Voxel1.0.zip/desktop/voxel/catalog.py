"""A web view ONLY for the catalog. Local QWebChannel bridge has no secrets or shell API."""
from __future__ import annotations
import json
import threading
from urllib.parse import urlparse
from PySide6.QtCore import QObject, Signal, Slot, QUrl
from PySide6.QtGui import QDesktopServices, QColor
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineSettings, QWebEngineUrlRequestInterceptor
from PySide6.QtWebEngineWidgets import QWebEngineView
from .state import RESOURCE_ROOT

TRUSTED = (RESOURCE_ROOT / "catalog" / "index.html").resolve()
EXTERNAL_HOSTS = {"modrinth.com", "www.modrinth.com", "curseforge.com", "www.curseforge.com", "console.curseforge.com"}


class Bridge(QObject):
    response = Signal(str)
    progress = Signal(str)
    changed = Signal(str)
    installRequested = Signal(dict)
    importRequested = Signal()
    settingsRequested = Signal()
    cancelRequested = Signal()

    def __init__(self, catalog, store, parent=None):
        super().__init__(parent)
        self.catalog, self.store = catalog, store

    @Slot(str)
    def request(self, payload):
        try:
            if len(payload) > 10000:
                raise ValueError("Слишком большой запрос.")
            data = json.loads(payload)
            rid = str(data["requestId"])[:80]
            action = data.get("action")
            if action not in ("search", "versions", "status"):
                raise ValueError("Неизвестное действие.")
        except Exception as error:
            self.response.emit(json.dumps({"requestId": "invalid", "error": str(error)})); return
        def work():
            try:
                if action == "status":
                    result = {**self.store.public(), "curseforgeConfigured": bool(self.catalog.key())}
                elif action == "search":
                    result = self.catalog.search(data.get("source", "modrinth"), data.get("kind", "modpack"), data.get("query", ""), data.get("mc", ""), data.get("loader", ""), data.get("offset", 0))
                else:
                    project = self.catalog.project(data["source"], data["projectId"])
                    result = {"project": project, "versions": self.catalog.versions(data["source"], project["id"], data.get("mc", ""), data.get("loader", ""), project["type"])}
                self.response.emit(json.dumps({"requestId": rid, "data": result}))
            except Exception as error:
                self.response.emit(json.dumps({"requestId": rid, "error": str(error)}))
        threading.Thread(target=work, daemon=True).start()

    @Slot(str)
    def install(self, payload):
        try:
            if len(payload) > 4096:
                return
            data = json.loads(payload)
            self.installRequested.emit({k: data.get(k, "") for k in ("source", "projectId", "versionId", "profileId", "kind", "title")})
        except Exception:
            pass

    @Slot()
    def importArchive(self): self.importRequested.emit()
    @Slot()
    def configure(self): self.settingsRequested.emit()
    @Slot()
    def cancel(self): self.cancelRequested.emit()
    @Slot(str)
    def openExternal(self, url):
        parsed = urlparse(url)
        if parsed.scheme == "https" and parsed.hostname in EXTERNAL_HOSTS:
            QDesktopServices.openUrl(QUrl(url))


class RequestFilter(QWebEngineUrlRequestInterceptor):
    def interceptRequest(self, info):
        url = info.requestUrl()
        if url.scheme() in ("qrc", "data"):
            return
        if url.isLocalFile():
            candidate = __import__("pathlib").Path(url.toLocalFile()).resolve()
            if candidate.is_relative_to(RESOURCE_ROOT / "catalog") or candidate.is_relative_to(RESOURCE_ROOT / "assets"):
                return
        # Catalog images may be remote; scripts and privileged documents may not.
        if url.scheme() == "https" and info.resourceType().name in ("ResourceTypeImage", "ResourceTypeFavicon"):
            host = url.host()
            if host == "cdn.modrinth.com" or host.endswith(".forgecdn.net"):
                return
        info.block(True)


class LocalPage(QWebEnginePage):
    def acceptNavigationRequest(self, url, navigation_type, main_frame):
        if main_frame:
            return url.isLocalFile() and __import__("pathlib").Path(url.toLocalFile()).resolve() == TRUSTED
        return False


class CatalogView(QWebEngineView):
    def __init__(self, catalog, store, parent=None):
        super().__init__(parent)
        self.web_profile = QWebEngineProfile()
        self.web_profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies)
        self.interceptor = RequestFilter(self)
        self.web_profile.setUrlRequestInterceptor(self.interceptor)
        self.local_page = LocalPage(self.web_profile, self)
        self.local_page.setBackgroundColor(QColor("#121517")); self.setPage(self.local_page)
        self.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
        self.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, False)
        self.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, False)
        self.channel = QWebChannel(self.page()); self.bridge = Bridge(catalog, store, self.channel)
        self.channel.registerObject("voxel", self.bridge); self.page().setWebChannel(self.channel)
        self.ready = False; self.pending_search = None
        self.loadFinished.connect(self.loaded)
        self.load(QUrl.fromLocalFile(str(TRUSTED)))

    def loaded(self, ok):
        self.ready = ok
        if ok and self.pending_search:
            self.search(*self.pending_search)

    def search(self, query="", source="modrinth", kind="modpack"):
        self.pending_search = (query, source, kind)
        if self.ready:
            payload = json.dumps({"query": query, "source": source, "kind": kind})
            self.page().runJavaScript("window.voxelSearch && window.voxelSearch(" + payload + ")")

    def sync(self):
        self.bridge.changed.emit(json.dumps(self.bridge.store.public()))

    def shutdown(self):
        if getattr(self, "_shutdown", False):
            return
        self._shutdown = True
        self.stop()
        page = self.local_page
        page.setWebChannel(None)
        page.destroyed.connect(self.web_profile.deleteLater)
        self.setPage(QWebEnginePage(self))
        page.deleteLater()
