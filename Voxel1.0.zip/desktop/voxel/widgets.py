"""Native Qt rendering: high-DPI PNGs, SVG icons, smooth hover and slide animations."""
from __future__ import annotations
from functools import lru_cache
from PySide6.QtCore import Qt, QRectF, QSize, Property, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPixmap, QLinearGradient, QFont
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QFrame, QLabel, QPushButton, QVBoxLayout, QWidget, QStyleOption, QStyle
from .state import RESOURCE_ROOT

PATHS = {
 "home": '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 "layers": '<path d="m12 3 10 5-10 5L2 8Zm-10 9 10 5 10-5M2 17l10 5 10-5"/>',
 "box": '<path d="m12 3 9 5v9l-9 5-9-5V8ZM3 8l9 5 9-5M12 13v9M7.5 5.5l9 5"/>',
 "puzzle": '<path d="M8 3H3v5a3 3 0 1 1 0 6v7h7a3 3 0 1 1 6 0h5v-7a3 3 0 1 1 0-6V3h-7a3 3 0 1 1-6 0Z"/>',
 "import": '<path d="M12 16V3m-5 5 5-5 5 5M4 15v6h16v-6"/>',
 "download": '<path d="M12 3v13m-5-5 5 5 5-5M4 16v5h16v-5"/>',
 "user": '<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
 "settings": '<path d="M3 6h18M3 12h18M3 18h18"/><rect x="6" y="3" width="3" height="6" rx="1"/><rect x="15" y="9" width="3" height="6" rx="1"/><rect x="7" y="15" width="3" height="6" rx="1"/>',
 "search": '<circle cx="10.5" cy="10.5" r="7"/><path d="m16 16 5 5"/>',
 "arrow": '<path d="M4 12h16m-6-6 6 6-6 6"/>',
 "chevron": '<path d="m9 5 7 7-7 7"/>',
 "play": '<path d="m7 3 14 9-14 9Z" fill="currentColor" stroke-linejoin="round"/>',
 "folder": '<path d="M3 5h6l3 3h9v13H3Z"/>',
 "memory": '<rect x="2" y="5" width="20" height="12" rx="2"/><path d="M5 9v4m4-4v4m6-4v4m4-4v4M5 17v4m5-4v4m4-4v4m5-4v4"/>',
 "more": '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
 "check": '<path d="m4 12 5 5L20 6"/>',
 "close": '<path d="m6 6 12 12M6 18 18 6"/>',
 "refresh": '<path d="M20 11a8 8 0 0 0-14-6L3 8m0-5v5h5M4 13a8 8 0 0 0 14 6l3-3m-5 0h5v5"/>',
 "sparkles": '<path d="m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3Zm-8 0v4M2 4h4"/>',
 "external": '<path d="M13 3h8v8M21 3 10 14M10 3H3v18h18v-7"/>',
 "bell": '<path d="M18 8a6 6 0 0 0-12 0c0 8-3 8-3 10h18c0-2-3-2-3-10M10 22h4"/>',
 "forge": '<path d="M2 6h20l-4 5h-4v5l4 3H6l4-3v-5H7L2 8Z"/>',
 "log": '<rect x="2" y="3" width="20" height="18" rx="3"/><path d="m6 8 4 4-4 4m7 0h5"/>',
 "stop": '<rect x="5" y="5" width="14" height="14" rx="2"/>',
 "plus": '<path d="M12 4v16M4 12h16"/>'
}


@lru_cache(maxsize=100)
def icon(name, color="#9499a3", size=20):
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{color}" color="{color}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">{PATHS.get(name, PATHS["box"])}</svg>'
    pix = QPixmap(size * 2, size * 2); pix.fill(Qt.GlobalColor.transparent); pix.setDevicePixelRatio(2)
    painter = QPainter(pix); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    QSvgRenderer(svg.encode()).render(painter, QRectF(0, 0, size, size)); painter.end()
    return QIcon(pix)


def logo(size=42):
    svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><g stroke="#26190f" stroke-width="1.3" stroke-linejoin="round"><path fill="#ffb566" d="m24 2 21 12-21 12L3 14Z"/><path fill="#f28b45" d="m3 14 21 12v22L3 36Z"/><path fill="#e46a2a" d="m24 26 21-12v22L24 48Z"/><path fill="none" d="m10 10 21 12v22m-14-38 21 12v22M3 22l21 12 21-12M3 29l21 12 21-12M17 6v16m14-16L10 18v22m7-18v22m21-26L17 6"/></g></svg>'
    pix = QPixmap(size * 2, size * 2); pix.fill(Qt.GlobalColor.transparent); pix.setDevicePixelRatio(2)
    painter = QPainter(pix); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    QSvgRenderer(svg.encode()).render(painter, QRectF(0, 0, size, size)); painter.end()
    w = QLabel(); w.setPixmap(pix); w.setFixedSize(size, size); return w


def text(value, role="body", wrap=False):
    widget = QLabel(str(value)); widget.setObjectName(role)
    widget.setTextFormat(Qt.TextFormat.PlainText); widget.setWordWrap(wrap)
    if role in ("section", "cardTitle", "title", "heroTitle", "brand"):
        font = widget.font(); font.setWeight(QFont.Weight.Bold if role in ("title", "heroTitle", "brand") else QFont.Weight.DemiBold); widget.setFont(font)
    return widget


class Button(QPushButton):
    def __init__(self, title="", kind="secondary", symbol=None, action=None, parent=None):
        super().__init__(title, parent)
        self.kind = kind; self.setObjectName(kind); self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(36); self.setIconSize(QSize(16, 16))
        if symbol:
            self.setIcon(icon(symbol, "#23170e" if kind == "primary" else "#f3a067" if kind in ("link", "outline") else "#a1a6b0", 18))
        if action:
            self.clicked.connect(lambda checked=False: action())
        self._hover = 0.0
        self.anim = QPropertyAnimation(self, b"hover", self); self.anim.setDuration(160); self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    def get_hover(self): return self._hover
    def set_hover(self, value):
        self._hover = value
        if self.kind == "primary":
            start, end = QColor("#f28b45"), QColor("#ffa466")
            col = QColor(*[int(start.getRgb()[i] + (end.getRgb()[i] - start.getRgb()[i]) * value) for i in range(3)])
            self.setStyleSheet("QPushButton#primary {background:" + col.name() + ";}")
    hover = Property(float, get_hover, set_hover)
    def enterEvent(self, event):
        self.anim.stop(); self.anim.setStartValue(self._hover); self.anim.setEndValue(1.0); self.anim.start(); super().enterEvent(event)
    def leaveEvent(self, event):
        self.anim.stop(); self.anim.setStartValue(self._hover); self.anim.setEndValue(0.0); self.anim.start(); super().leaveEvent(event)


@lru_cache(maxsize=24)
def image(name):
    return QPixmap(str(RESOURCE_ROOT / "assets" / name))


class Picture(QFrame):
    def __init__(self, filename, height=128, radius=10, hero=False):
        super().__init__()
        self.filename = filename; self.previous = filename; self.radius = radius; self.hero = hero
        self._zoom = 0.0; self._mix = 1.0
        self.setFixedHeight(height); self.setMinimumWidth(0)
        self.zoom_animation = QPropertyAnimation(self, b"zoom", self); self.zoom_animation.setDuration(450); self.zoom_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.slide_animation = QPropertyAnimation(self, b"mix", self); self.slide_animation.setDuration(700); self.slide_animation.setEasingCurve(QEasingCurve.Type.InOutCubic)

    def get_zoom(self): return self._zoom
    def set_zoom(self, value): self._zoom = value; self.update()
    zoom = Property(float, get_zoom, set_zoom)
    def get_mix(self): return self._mix
    def set_mix(self, value): self._mix = value; self.update()
    mix = Property(float, get_mix, set_mix)

    def set_picture(self, filename):
        self.previous = self.filename; self.filename = filename
        self.slide_animation.stop(); self.slide_animation.setStartValue(0.0); self.slide_animation.setEndValue(1.0); self.slide_animation.start()

    def enterEvent(self, event):
        self.zoom_animation.stop(); self.zoom_animation.setStartValue(self._zoom); self.zoom_animation.setEndValue(1.0); self.zoom_animation.start(); super().enterEvent(event)
    def leaveEvent(self, event):
        self.zoom_animation.stop(); self.zoom_animation.setStartValue(self._zoom); self.zoom_animation.setEndValue(0.0); self.zoom_animation.start(); super().leaveEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform | QPainter.RenderHint.TextAntialiasing)
        rect = QRectF(self.rect()); clip = QPainterPath(); clip.addRoundedRect(rect, self.radius, self.radius)
        painter.setClipPath(clip); painter.fillRect(rect, QColor("#202a25"))
        for filename, opacity in [(self.previous, 1.0), (self.filename, self._mix)]:
            pixmap = image(filename)
            if pixmap.isNull():
                continue
            scale = max(rect.width() / pixmap.width(), rect.height() / pixmap.height()) * (1 + self._zoom * .025)
            w, h = pixmap.width() * scale, pixmap.height() * scale
            painter.setOpacity(opacity); painter.drawPixmap(QRectF((rect.width()-w)/2, (rect.height()-h)/2, w, h), pixmap, QRectF(pixmap.rect()))
        painter.setOpacity(1)
        if self.hero:
            gradient = QLinearGradient(0, 0, self.width(), 0)
            gradient.setColorAt(0, QColor(5, 17, 14, 232)); gradient.setColorAt(.46, QColor(5, 17, 14, 135)); gradient.setColorAt(1, QColor(5, 17, 14, 0))
            painter.fillRect(rect, gradient)
        painter.setClipping(False); painter.setPen(QColor("#3a433b") if self.hero else QColor("#34383c")); painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(rect.adjusted(.5,.5,-.5,-.5), self.radius, self.radius)


def panel():
    frame = QFrame(); frame.setObjectName("panel")
    layout = QVBoxLayout(frame); layout.setContentsMargins(20, 18, 20, 18); layout.setSpacing(12)
    return frame


def dispose(layout):
    while layout.count():
        item = layout.takeAt(0)
        if item.widget():
            item.widget().deleteLater()
        elif item.layout():
            dispose(item.layout())
