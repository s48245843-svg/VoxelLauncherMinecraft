"""Verified, cancellable downloads with atomic commit and safe archive paths."""
from __future__ import annotations
import hashlib
import ipaddress
import os
import re
import socket
import threading
import time
import uuid
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse
import requests

UA = "VoxelLauncher/3.0 (desktop Minecraft launcher)"


class UserError(Exception):
    pass


class Cancelled(UserError):
    pass


class Job:
    def __init__(self, emit=lambda event: None):
        self.cancelled = threading.Event()
        self.emit = emit
        self.lock = threading.Lock()
        self.last = 0.0
        self.received = 0
        self.started = time.monotonic()

    def check(self):
        if self.cancelled.is_set():
            raise Cancelled("Установка отменена. Проверенные файлы сохранены для повтора.")

    def update(self, message, done=0, total=0, phase="download", force=False, **extra):
        self.check()
        with self.lock:
            now = time.monotonic()
            if force or now - self.last > .12:
                self.last = now
                self.emit({"message": str(message), "done": done, "total": total, "phase": phase, **extra})

    def bytes(self, count, name, done, total):
        self.check()
        with self.lock:
            self.received += count
        self.update(name, done, total, "file", received=self.received, speed=int(self.received / max(.1, time.monotonic() - self.started)))


def json_request(url, *, params=None, headers=None, body=None, form=None, method="GET"):
    for attempt in range(3):
        try:
            response = requests.request(method, url, params=params, json=body, data=form, headers={"User-Agent": UA, "Accept": "application/json", **(headers or {})}, timeout=(15, 60))
            if response.status_code in (429, 500, 502, 503, 504) and attempt < 2:
                time.sleep(min(10, int(response.headers.get("Retry-After", "2"))))
                continue
            if not response.ok:
                if response.status_code == 401:
                    raise UserError("Сервис отклонил ключ или сессию (401). Проверьте настройки аккаунта / API.")
                if response.status_code == 403:
                    raise UserError("Сервис запретил доступ (403). Проверьте API-ключ и разрешения приложения.")
                raise UserError(f"{urlparse(url).hostname}: HTTP {response.status_code}")
            return response.json()
        except requests.RequestException as error:
            if attempt == 2:
                raise UserError("Не удалось подключиться к " + str(urlparse(url).hostname)) from error
            time.sleep(attempt + 1)
    raise UserError("Сервис временно недоступен.")


def safe_path(root, relative):
    value = str(relative)
    if not value or "\\" in value or "\0" in value or ":" in value:
        raise UserError("Небезопасный путь в сборке: " + value[:100])
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise UserError("Выход за пределы папки сборки запрещён.")
    root = Path(root).resolve()
    result = (root / Path(*path.parts)).resolve()
    if result == root or not result.is_relative_to(root):
        raise UserError("Небезопасный путь в архиве.")
    return result


def verify(path, hashes, size=None):
    path = Path(path)
    if not path.is_file() or (size is not None and path.stat().st_size != int(size)):
        return False
    algorithms = {k: hashlib.new(k) for k in (hashes or {}) if k in ("sha512", "sha256", "sha1", "md5")}
    if not algorithms:
        return False
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            for digest in algorithms.values():
                digest.update(block)
    return all(h.hexdigest().lower() == str(hashes[k]).lower() for k, h in algorithms.items())


def public_https(url):
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise UserError("Для загрузок разрешены только публичные HTTPS-адреса.")
    try:
        addresses = socket.getaddrinfo(parsed.hostname, 443, type=socket.SOCK_STREAM)
        if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
            raise UserError("Локальный сетевой адрес в манифесте запрещён.")
    except OSError as error:
        raise UserError("Не удалось определить адрес сервера загрузки.") from error


def download(url, destination, hashes=None, size=None, job=None, max_size=1024 * 1024 * 1024):
    job = job or Job()
    destination = Path(destination)
    job.check()
    if verify(destination, hashes, size):
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + "." + uuid.uuid4().hex[:8] + ".part")
    for attempt in range(3):
        response = None
        try:
            current = url
            for _ in range(8):
                public_https(current)
                response = requests.get(current, headers={"User-Agent": UA}, timeout=(15, 60), stream=True, allow_redirects=False)
                if response.is_redirect:
                    from urllib.parse import urljoin
                    current = urljoin(current, response.headers["Location"])
                    response.close()
                    continue
                break
            if response is None or not response.ok or response.is_redirect:
                raise UserError("Файл недоступен: " + destination.name)
            total = int(response.headers.get("Content-Length") or size or 0)
            if total > max_size:
                raise UserError("Файл превышает допустимый размер.")
            done = 0
            with temp.open("wb") as output:
                for block in response.iter_content(262144):
                    job.check()
                    done += len(block)
                    if done > max_size:
                        raise UserError("Файл превышает допустимый размер.")
                    output.write(block)
                    job.bytes(len(block), destination.name, done, total)
            if hashes and not verify(temp, hashes, size):
                raise UserError("Контрольная сумма не совпала: " + destination.name)
            if size is not None and done != int(size):
                raise UserError("Размер файла не совпал: " + destination.name)
            os.replace(temp, destination)
            return destination
        except Cancelled:
            raise
        except (requests.RequestException, OSError, UserError) as error:
            if attempt == 2:
                raise UserError("Не удалось скачать " + destination.name + ": " + str(error)) from error
            time.sleep(attempt + 1)
        finally:
            if response is not None:
                response.close()
            temp.unlink(missing_ok=True)
    raise UserError("Не удалось скачать файл.")
