"""Official Modrinth v2 / CurseForge v1 APIs. No scraping or URL guessing."""
from __future__ import annotations
import json
import re
from urllib.parse import quote
from .network import UserError, json_request

MR = "https://api.modrinth.com/v2"
CF = "https://api.curseforge.com/v1"
CF_CLASSES = {"mod": 6, "modpack": 4471, "resourcepack": 12, "shader": 6552}
CF_LOADERS = {"forge": 1, "fabric": 4, "quilt": 5, "neoforge": 6}


def identifier(value):
    text = str(value)
    if not re.fullmatch(r"[A-Za-z0-9_.+\-]{1,160}", text):
        raise UserError("Некорректный ID проекта или версии.")
    return quote(text, safe="")


class Catalog:
    def __init__(self, secrets):
        self.secrets = secrets

    def key(self):
        import os
        return os.environ.get("CURSEFORGE_API_KEY") or self.secrets.get("curseforge-api-key") or ""

    def cf(self, route, params=None, body=None):
        key = self.key()
        if not key:
            raise UserError("CurseForge требует API-ключ. Добавьте его в Настройки → CurseForge (console.curseforge.com). Можно открыть сайт и импортировать ZIP; для разрешения файлов из manifest.json ключ также необходим.")
        return json_request(CF + route, params=params, body=body, method="POST" if body is not None else "GET", headers={"x-api-key": key})

    def search(self, provider="modrinth", kind="modpack", query="", mc="", loader="", offset=0):
        if kind not in CF_CLASSES or provider not in ("modrinth", "curseforge"):
            raise UserError("Неизвестный каталог.")
        offset = min(9900, max(0, int(offset)))
        if provider == "modrinth":
            facets = [["project_type:" + kind]]
            if mc:
                facets.append(["versions:" + mc])
            if loader and loader != "vanilla" and kind in ("mod", "modpack"):
                facets.append(["categories:" + loader])
            data = json_request(MR + "/search", params={"query": str(query)[:160], "facets": json.dumps(facets), "limit": 20, "offset": offset, "index": "relevance" if query else "downloads"})
            hits = [{"id": h["project_id"], "title": h["title"], "description": h.get("description", ""), "icon": h.get("icon_url", ""), "author": h.get("author", ""), "downloads": h.get("downloads", 0), "type": h["project_type"], "source": provider, "url": f"https://modrinth.com/{h['project_type']}/{h['slug']}"} for h in data["hits"]]
            return {"hits": hits, "total": data["total_hits"], "offset": offset}
        params = {"gameId": 432, "classId": CF_CLASSES[kind], "searchFilter": str(query)[:160], "pageSize": 20, "index": offset, "sortField": 6, "sortOrder": "desc"}
        if mc:
            params["gameVersion"] = mc
        if loader in CF_LOADERS:
            params["modLoaderType"] = CF_LOADERS[loader]
        data = self.cf("/mods/search", params=params)
        return {"hits": [self.normalize_cf(h) for h in data["data"]], "total": data.get("pagination", {}).get("totalCount", 0), "offset": offset}

    def normalize_cf(self, project):
        return {"id": str(project["id"]), "title": project["name"], "description": project.get("summary", ""), "icon": (project.get("logo") or {}).get("thumbnailUrl", ""), "author": ", ".join(a["name"] for a in project.get("authors", [])), "downloads": project.get("downloadCount", 0), "type": next((k for k, v in CF_CLASSES.items() if v == project.get("classId")), "mod"), "source": "curseforge", "url": project.get("links", {}).get("websiteUrl", "")}

    def project(self, provider, project_id):
        ident = identifier(project_id)
        if provider == "modrinth":
            p = json_request(MR + "/project/" + ident)
            return {"id": p["id"], "title": p["title"], "description": p.get("description", ""), "icon": p.get("icon_url", ""), "type": p["project_type"], "source": provider, "url": f"https://modrinth.com/{p['project_type']}/{p['slug']}"}
        if provider == "curseforge" and ident.isdigit():
            return self.normalize_cf(self.cf("/mods/" + ident)["data"])
        raise UserError("Неизвестный источник проекта.")

    def versions(self, provider, project_id, mc="", loader="", kind="modpack"):
        ident = identifier(project_id)
        if provider == "modrinth":
            params = {"include_changelog": "false"}
            if mc:
                params["game_versions"] = json.dumps([mc])
            if loader and loader != "vanilla" and kind in ("mod", "modpack"):
                params["loaders"] = json.dumps([loader])
            items = json_request(MR + "/project/" + ident + "/version", params=params)
            return [{"id": v["id"], "name": v["name"], "mc": v.get("game_versions", []), "loaders": v.get("loaders", []), "channel": v.get("version_type", "release"), "date": v["date_published"][:10]} for v in items if v.get("environment") not in ("server_only", "dedicated_server_only")]
        if provider == "curseforge" and ident.isdigit():
            params = {"pageSize": 50}
            if mc:
                params["gameVersion"] = mc
            if loader in CF_LOADERS:
                params["modLoaderType"] = CF_LOADERS[loader]
            items = self.cf("/mods/" + ident + "/files", params=params)["data"]
            return [{"id": str(v["id"]), "name": v["displayName"], "mc": [x for x in v.get("gameVersions", []) if x[:1].isdigit()], "loaders": [x.lower() for x in v.get("gameVersions", []) if x.lower() in CF_LOADERS], "channel": {1: "release", 2: "beta", 3: "alpha"}.get(v.get("releaseType"), "release"), "date": v.get("fileDate", "")[:10]} for v in items if not v.get("isServerPack") and v.get("isAvailable", True)]
        raise UserError("Некорректный источник или ID.")

    def raw_version(self, provider, project_id, version_id):
        ident, version = identifier(project_id), identifier(version_id)
        if provider == "modrinth":
            data = json_request(MR + "/version/" + version)
            # Resolve a slug to its real project ID before checking ownership.
            pid = self.project(provider, ident)["id"] if data["project_id"] != ident else ident
            if data["project_id"] != pid:
                raise UserError("Версия относится к другому проекту.")
            return data
        if provider == "curseforge" and ident.isdigit() and version.isdigit():
            return self.cf(f"/mods/{ident}/files/{version}")["data"]
        raise UserError("Неизвестный источник версии.")

    def cf_file(self, data):
        if not data.get("isAvailable", True) or data.get("isServerPack"):
            raise UserError("Этот файл не предназначен для установки клиента.")
        url = data.get("downloadUrl")
        # A null URL is an author's distribution restriction, never synthesize CDN URLs.
        hashes = {({1: "sha1", 2: "md5"}.get(h["algo"])): h["value"] for h in data.get("hashes", []) if h["algo"] in (1, 2)}
        return {"path": "mods/" + data["fileName"], "urls": [url] if url else [], "hashes": hashes, "size": data.get("fileLength"), "project_id": str(data["modId"]), "version_id": str(data["id"]), "source": "curseforge", "manual_url": (self.project("curseforge", str(data["modId"]))["url"].rstrip("/") + "/download/" + str(data["id"])) if not url else "", "name": data["fileName"]}

    def bulk_cf(self, references):
        resolved = {}
        for start in range(0, len(references), 50):
            ids = [int(r["fileID"]) for r in references[start:start + 50]]
            for data in self.cf("/mods/files", body={"fileIds": ids})["data"]:
                resolved[int(data["id"])] = data
        records = []
        for ref in references:
            if ref.get("required", True) is False:
                continue
            data = resolved.get(int(ref["fileID"]))
            if not data or int(data["modId"]) != int(ref["projectID"]):
                raise UserError(f"CurseForge не вернул обязательный файл {ref['projectID']} / {ref['fileID']}.")
            records.append(self.cf_file(data))
        return records

    def resolve_mod(self, provider, project_id, version_id, profile):
        if profile["loader"] == "vanilla":
            raise UserError("Для модов нужна сборка Fabric, Forge, NeoForge или Quilt.")
        visited, by_project, records = set(), {}, []

        def visit(pid, vid=None, depth=0):
            if depth > 40 or len(visited) > 500:
                raise UserError("Слишком большое дерево зависимостей.")
            pid = str(pid)
            if not vid:
                choices = self.versions(provider, pid, profile["mc"], profile["loader"], "mod")
                if not choices:
                    raise UserError("Нет совместимой обязательной зависимости: " + pid)
                vid = choices[0]["id"]
            vid = str(vid)
            data = self.raw_version(provider, pid, vid)
            real_pid = str(data["project_id"] if provider == "modrinth" else data["modId"])
            if real_pid in by_project and by_project[real_pid] != vid:
                raise UserError("Две зависимости требуют разные версии проекта " + real_pid)
            if (real_pid, vid) in visited:
                return
            visited.add((real_pid, vid)); by_project[real_pid] = vid
            if provider == "modrinth":
                if profile["mc"] not in data.get("game_versions", []) or profile["loader"] not in data.get("loaders", []):
                    raise UserError("Версия мода не совместима с выбранной сборкой.")
                for dep in data.get("dependencies", []):
                    if dep["dependency_type"] == "required":
                        child = dep.get("project_id")
                        if not child and dep.get("version_id"):
                            child = json_request(MR + "/version/" + identifier(dep["version_id"]))["project_id"]
                        if not child:
                            raise UserError("Обязательная внешняя зависимость не может быть разрешена автоматически.")
                        visit(child, dep.get("version_id"), depth + 1)
                    if dep["dependency_type"] == "incompatible" and any(m.get("project_id") == dep.get("project_id") for m in profile.get("mods", [])):
                        raise UserError("Мод конфликтует с уже установленным проектом " + str(dep.get("project_id")))
                files = [f for f in data["files"] if f.get("file_type") not in ("sources-jar", "dev-jar", "javadoc-jar", "signature")]
                f = next((f for f in files if f.get("primary")), files[0])
                records.append({"path": "mods/" + f["filename"], "urls": [f["url"]], "hashes": f["hashes"], "size": f["size"], "project_id": real_pid, "version_id": vid, "source": provider, "name": f["filename"]})
            else:
                if profile["mc"] not in data.get("gameVersions", []) or profile["loader"].lower() not in [v.lower() for v in data.get("gameVersions", [])]:
                    raise UserError("Файл CurseForge не подходит под Minecraft и загрузчик сборки.")
                for dep in data.get("dependencies", []):
                    if dep.get("relationType") == 3:
                        visit(str(dep["modId"]), depth=depth + 1)
                records.append(self.cf_file(data))
        visit(project_id, version_id)
        return records
