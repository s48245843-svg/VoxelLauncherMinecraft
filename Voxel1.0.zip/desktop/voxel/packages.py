"""Install actual mod files / complete MRPACK and CurseForge archives, not profile stubs."""
from __future__ import annotations
import hashlib
import json
import os
import re
from urllib.parse import urlparse
import shutil
import stat
import threading
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from . import game
from .network import Cancelled, Job, UserError, download, safe_path, verify
from .state import atomic_json



def identify(record):
    if record.get("project_id"):
        return record
    for url in record.get("urls", []):
        parsed = urlparse(url)
        match = re.match(r"^/data/([A-Za-z0-9]+)/versions/([A-Za-z0-9]+)/", parsed.path)
        if parsed.hostname == "cdn.modrinth.com" and match:
            record.update(project_id=match[1], version_id=match[2], source="modrinth")
            break
    return record


def jar_ids(filename):
    try:
        with zipfile.ZipFile(filename) as bundle:
            if "fabric.mod.json" in bundle.namelist():
                info = bundle.getinfo("fabric.mod.json")
                if info.file_size > 1024 * 1024:
                    return set()
                value = json.loads(bundle.read(info)).get("id")
                return {value} if isinstance(value, str) else set()
            for name in ("META-INF/mods.toml", "META-INF/neoforge.mods.toml"):
                if name in bundle.namelist() and bundle.getinfo(name).file_size < 1024 * 1024:
                    return set(re.findall(r'(?m)^\s*modId\s*=\s*["\']([^"\']+)["\']', bundle.read(name).decode("utf-8")))
    except (OSError, ValueError, zipfile.BadZipFile, KeyError):
        pass
    return set()


def inspect_archive(filename, include_optional=True):
    with zipfile.ZipFile(filename) as bundle:
        entries = bundle.infolist()
        if len(entries) > 30000 or sum(e.file_size for e in entries) > 4 * 1024 ** 3:
            raise UserError("Слишком большой распакованный архив (лимит 4 ГБ / 30000 файлов).")
        for entry in entries:
            if stat.S_ISLNK(entry.external_attr >> 16):
                raise UserError("Символические ссылки в сборке запрещены.")
            safe_path(Path(filename).parent / "validation", entry.filename.rstrip("/"))
            if entry.file_size > 1024 ** 3 or (entry.file_size > 10 ** 7 and entry.file_size > max(1, entry.compress_size) * 1000):
                raise UserError("Небезопасный размер файла в архиве.")
        names = bundle.namelist()
        if "modrinth.index.json" in names:
            manifest = json.loads(bundle.read("modrinth.index.json"))
            if manifest.get("game") != "minecraft" or manifest.get("formatVersion") != 1:
                raise UserError("Этот формат MRPACK не поддерживается.")
            deps = manifest.get("dependencies", {})
            loaders = [(label, deps[key]) for key, label in [("fabric-loader", "fabric"), ("quilt-loader", "quilt"), ("forge", "forge"), ("neoforge", "neoforge")] if key in deps]
            if len(loaders) > 1 or set(deps) - {"minecraft", "fabric-loader", "quilt-loader", "forge", "neoforge"}:
                raise UserError("Сборка требует неподдерживаемое сочетание загрузчиков.")
            files = []
            for item in manifest.get("files", []):
                client = item.get("env", {}).get("client", "required")
                if client == "unsupported" or (client == "optional" and not include_optional):
                    continue
                safe_path(Path(filename).parent / "validation", item["path"])
                if not item.get("hashes", {}).get("sha1") or not item.get("hashes", {}).get("sha512"):
                    raise UserError("У файла MRPACK отсутствуют обязательные хеши.")
                files.append({"path": item["path"], "urls": item["downloads"], "hashes": item["hashes"], "size": item.get("fileSize"), "name": Path(item["path"]).name, "source": "modrinth"})
            files = [identify(record) for record in files]
            return {"name": manifest.get("name", "Modrinth pack"), "mc": deps["minecraft"], "loader": loaders[0][0] if loaders else "vanilla", "loader_version": loaders[0][1] if loaders else "", "files": files, "overrides": ["overrides", "client-overrides"], "format": "mrpack", "version": manifest.get("versionId", "")}
        if "manifest.json" in names:
            manifest = json.loads(bundle.read("manifest.json"))
            if manifest.get("manifestType", "minecraftModpack") != "minecraftModpack":
                raise UserError("Это не клиентская сборка CurseForge.")
            mc = manifest.get("minecraft", {})
            loaders = mc.get("modLoaders", [])
            chosen = next((l for l in loaders if l.get("primary")), loaders[0] if loaders else None)
            loader, loader_version = (chosen["id"].split("-", 1) if chosen else ("vanilla", ""))
            overrides = manifest.get("overrides", "overrides").strip("/")
            safe_path(Path(filename).parent / "validation", overrides)
            return {"name": manifest.get("name", "CurseForge pack"), "mc": mc["version"], "loader": loader, "loader_version": loader_version, "references": manifest.get("files", []), "overrides": [overrides], "format": "curseforge", "version": manifest.get("version", "")}
    raise UserError("В архиве нет modrinth.index.json или manifest.json. Выберите клиентский .mrpack / CurseForge ZIP.")


def apply_overrides(archive, directory, prefixes, job):
    records = []
    with zipfile.ZipFile(archive) as bundle:
        for prefix in prefixes:
            for entry in bundle.infolist():
                job.check()
                if entry.is_dir() or not entry.filename.startswith(prefix + "/"):
                    continue
                relative = entry.filename[len(prefix) + 1:]
                if relative.split("/")[0] in (".voxel", "versions", "libraries", "runtime"):
                    raise UserError("Overrides не могут заменять служебные файлы лаунчера.")
                target = safe_path(directory, relative)
                target.parent.mkdir(parents=True, exist_ok=True)
                with bundle.open(entry) as source, target.open("wb") as dest:
                    shutil.copyfileobj(source, dest, 262144)
                if relative.startswith("mods/") and relative.endswith(".jar"):
                    records.append({"path": relative, "hashes": {"sha256": hashlib.sha256(target.read_bytes()).hexdigest()}, "size": target.stat().st_size, "source": "overrides", "name": target.name})
    return records


class Installer:
    def __init__(self, store, catalog, game_install=game.install):
        self.store, self.catalog, self.game_install = store, catalog, game_install

    def plan_path(self, profile):
        return Path(profile["directory"]) / ".voxel" / "install-plan.json"

    def download_project_pack(self, source, project_id, version_id, job, optional=True):
        project = self.catalog.project(source, project_id)
        if project["type"] != "modpack":
            raise UserError("Выбранный проект не является сборкой.")
        data = self.catalog.raw_version(source, project["id"], version_id)
        if source == "modrinth":
            files = [f for f in data["files"] if f["filename"].endswith(".mrpack")]
            if not files:
                raise UserError("В версии проекта отсутствует клиентский MRPACK.")
            selected = next((f for f in files if f.get("primary")), files[0])
            url, hashes, size = selected["url"], selected["hashes"], selected["size"]
        else:
            record = self.catalog.cf_file(data)
            if not record["urls"]:
                raise UserError("Автор запретил автоматическую загрузку этого архива. Скачайте клиентский ZIP на CurseForge и выберите «Импорт сборки».")
            url, hashes, size = record["urls"][0], record["hashes"], record["size"]
        cached = self.store.root / "downloads" / (source + "-" + str(project["id"]) + "-" + str(version_id) + ".zip")
        download(url, cached, hashes, size, job)
        return self.import_pack(cached, job, optional, project)

    def import_pack(self, archive, job, optional=True, project=None):
        plan = inspect_archive(archive, optional)
        project = project or {}
        profile = self.store.add_profile(plan["name"], plan["mc"], plan["loader"], plan["loader_version"], ram=max(4096, self.store.settings()["ram"]), source=project.get("source", plan["format"]), project_id=project.get("id"), pack_version=plan["version"], description=project.get("description", "Импортированная сборка"), cover=self.choose_cover(plan["name"]), state="installing", icon_url=project.get("icon", ""))
        plan_path = self.plan_path(profile)
        plan_path.parent.mkdir(parents=True, exist_ok=True)
        copied = plan_path.parent / "source-pack.zip"
        shutil.copyfile(archive, copied)
        plan["archive"] = str(copied)
        atomic_json(plan_path, plan)
        return self.resume(profile["id"], job)

    def choose_cover(self, name):
        name = name.lower()
        return "create.png" if "create" in name else "fabric.png" if "optim" in name else "better-mc.png"

    def fetch_records(self, profile, records, job):
        directory = Path(profile["directory"])
        pending, errors = [], []
        completed = 0
        total = len(records)
        def one(record):
            job.check()
            target = safe_path(directory, record["path"])
            if verify(target, record.get("hashes"), record.get("size")):
                record["size"] = target.stat().st_size
                return None
            if not record.get("urls"):
                return record
            failure = None
            for url in record["urls"]:
                try:
                    download(url, target, record.get("hashes"), record.get("size"), job)
                    record["size"] = target.stat().st_size
                    return None
                except Cancelled:
                    raise
                except UserError as error:
                    failure = error
            raise failure or UserError("Нет источника файла: " + record["path"])
        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = {pool.submit(one, r): r for r in records}
            for future in as_completed(futures):
                job.check()
                record = futures[future]
                try:
                    missing = future.result()
                    if missing:
                        pending.append(missing)
                except Cancelled:
                    raise
                except Exception as error:
                    errors.append(record["path"] + ": " + str(error))
                completed += 1
                job.update(f"Файлы сборки · {completed} из {total}", completed, total, "files", force=True, file=record["path"], pending=len(pending), errors=len(errors))
        if errors:
            raise UserError("Не удалось скачать " + str(len(errors)) + " файлов. Повторите установку — проверенные файлы не скачаются заново.\n" + "\n".join(errors[:5]))
        return pending

    def resume(self, ident, job):
        profile = self.store.patch(ident, state="installing", installed=False, error="")
        try:
            if profile.get("pending_mods"):
                records = profile["pending_mods"]
                stage = dict(profile, directory=str(Path(profile["directory"]) / ".voxel" / "staging"))
                pending = self.fetch_records(stage, records, job)
                if pending:
                    return self.store.patch(ident, state="blocked", pending=pending)
                self.commit_records(profile, records, stage)
                self.store.patch(ident, pending=[], pending_mods=[])
                profile = self.store.profile(ident)
            plan_file = self.plan_path(profile)
            plan = json.loads(plan_file.read_text(encoding="utf-8")) if plan_file.exists() else None
            if plan:
                for record in plan.get("files", []):
                    identify(record)
                if plan["format"] == "curseforge" and "files" not in plan:
                    job.update("Разрешение файлов CurseForge по manifest.json", phase="resolve", force=True)
                    plan["files"] = self.catalog.bulk_cf(plan["references"])
                    atomic_json(plan_file, plan)
                if plan["format"] == "mrpack":
                    for record in plan["files"]:
                        if "declared_size" not in record and record.get("source") == "modrinth":
                            record["declared_size"] = record.get("size")
                            record["size"] = None
                pending = self.fetch_records(profile, plan["files"], job)
                atomic_json(plan_file, plan)
                if pending:
                    self.store.patch(ident, state="blocked", pending=pending, error=f"Нужно скачать вручную: {len(pending)} файлов.")
                    return self.store.profile(ident)
                # Always copy client overrides after common overrides, as specified by MRPACK.
                override_mods = apply_overrides(plan["archive"], profile["directory"], plan["overrides"], job)
                files = {r["path"]: r for r in plan["files"]}
                files.update({r["path"]: r for r in override_mods})
                self.store.patch(ident, mods=list(files.values()), pending=[], content_ready=True)
            else:
                pending = self.fetch_records(profile, profile.get("mods", []), job)
                if pending:
                    return self.store.patch(ident, state="blocked", pending=pending)
            profile = self.store.profile(ident)
            result = self.game_install(profile, self.store.settings(), job)
            job.check()
            self.store.patch(ident, **result, state="ready", installed=True, pending=[], error="")
            job.update("Сборка установлена. Все обязательные файлы проверены.", 1, 1, "completed", force=True, profile_id=ident)
            return self.store.profile(ident)
        except Cancelled as error:
            self.store.patch(ident, state="paused", error=str(error))
            raise
        except Exception as error:
            self.store.patch(ident, state="error", error=str(error))
            raise

    def install_mod(self, source, project_id, version_id, profile_id, job):
        profile = self.store.profile(profile_id)
        profile["mods"] = [identify(record) for record in profile.get("mods", [])]
        records = self.catalog.resolve_mod(source, project_id, version_id, profile)
        # Stage everything first. A failed download must not half-update a running instance.
        stage = dict(profile, directory=str(Path(profile["directory"]) / ".voxel" / "staging"))
        pending = self.fetch_records(stage, records, job)
        if pending:
            return self.store.patch(profile_id, state="blocked", installed=False, pending=pending, pending_mods=records, error="Нужны файлы от автора. Откройте меню сборки → Файлы и проверка.")
        self.commit_records(profile, records, stage)
        job.update(f"Установлено файлов с зависимостями: {len(records)}", len(records), len(records), "completed", force=True)
        return records

    def commit_records(self, profile, records, stage):
        merged = {r["path"]: r for r in profile.get("mods", [])}
        for record in records:
            new_ids = jar_ids(safe_path(stage["directory"], record["path"])) if record["path"].endswith(".jar") else set()
            for old in list(merged.values()):
                identify(old)
                same_project = bool(record.get("project_id")) and old.get("project_id") == record.get("project_id") and old.get("source") == record.get("source")
                old_path = safe_path(profile["directory"], old["path"])
                old_ids = jar_ids(old_path) if new_ids and old["path"].endswith(".jar") else set()
                if new_ids & old_ids and new_ids != old_ids:
                    raise UserError("Обновление конфликтует с много-модовым JAR: " + old["path"])
                if (same_project or (new_ids and new_ids == old_ids)) and old["path"] != record["path"]:
                    old_path.unlink(missing_ok=True)
                    merged.pop(old["path"], None)
            target = safe_path(profile["directory"], record["path"])
            target.parent.mkdir(parents=True, exist_ok=True)
            os.replace(safe_path(stage["directory"], record["path"]), target)
            merged[record["path"]] = record
        # Preserve explicitly added mods on pack repair.
        plan_file = self.plan_path(profile)
        if plan_file.exists():
            plan = json.loads(plan_file.read_text(encoding="utf-8"))
            plan["files"] = list(merged.values())
            atomic_json(plan_file, plan)
        self.store.patch(profile["id"], mods=list(merged.values()))

    def install_asset(self, source, project_id, version_id, profile_id, kind, job):
        if kind not in ("resourcepack", "shader"):
            raise UserError("Неизвестный тип контента.")
        profile = self.store.profile(profile_id)
        project = self.catalog.project(source, project_id)
        if project["type"] != kind:
            raise UserError("Тип проекта не совпадает с выбранной категорией.")
        data = self.catalog.raw_version(source, project["id"], version_id)
        if source == "modrinth":
            if profile["mc"] not in data["game_versions"]:
                raise UserError("Ресурспак или шейдер не поддерживает эту версию Minecraft.")
            f = next((f for f in data["files"] if f.get("primary")), data["files"][0])
            record = {"path": f["filename"], "urls": [f["url"]], "hashes": f["hashes"], "size": f["size"], "project_id": project["id"], "version_id": version_id, "source": source, "name": f["filename"]}
        else:
            if profile["mc"] not in data.get("gameVersions", []):
                raise UserError("Файл не поддерживает эту версию Minecraft.")
            record = self.catalog.cf_file(data)
        folder = "resourcepacks" if kind == "resourcepack" else "shaderpacks"
        record["path"] = folder + "/" + record["name"]
        pending = self.fetch_records(profile, [record], job)
        if pending:
            return self.store.patch(profile_id, state="blocked", installed=False, pending=pending, pending_mods=[record], error="Скачайте файл с официальной страницы и выберите его в меню «Файлы и проверка».")
        merged = {r["path"]: r for r in profile.get("mods", [])}
        merged[record["path"]] = record
        self.store.patch(profile_id, mods=list(merged.values()))
        plan_file = self.plan_path(profile)
        if plan_file.exists():
            plan = json.loads(plan_file.read_text(encoding="utf-8"))
            plan["files"] = list(merged.values())
            atomic_json(plan_file, plan)
        job.update("Файл установлен. Для шейдеров нужен совместимый Iris/Oculus.", 1, 1, "completed", force=True)
        return [record]

    def supply_manual(self, ident, index, local_file):
        profile = self.store.profile(ident)
        pending = profile.get("pending", [])
        if not 0 <= int(index) < len(pending):
            raise UserError("Файл уже установлен или больше не требуется.")
        record = pending[int(index)]
        if not record.get("hashes") or not verify(local_file, record["hashes"], record.get("size")):
            raise UserError("Это не требуемая версия файла: контрольная сумма не совпала.")
        root = Path(profile["directory"]) / ".voxel" / "staging" if profile.get("pending_mods") else Path(profile["directory"])
        target = safe_path(root, record["path"])
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(local_file, target)
        pending.pop(int(index))
        self.store.patch(ident, pending=pending)
