"""Native account dialogs call these methods; web catalog never receives tokens."""
from __future__ import annotations
import hashlib
import re
import time
import uuid
from .network import Job, UserError, download, json_request


def offline(name):
    if not re.fullmatch(r"[A-Za-z0-9_]{3,16}", name):
        raise UserError("Ник: 3–16 латинских букв, цифр или _. ")
    digest = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode()).digest())
    digest[6] = (digest[6] & 15) | 48
    digest[8] = (digest[8] & 63) | 128
    return {"id": uuid.uuid4().hex, "kind": "offline", "name": name, "uuid": uuid.UUID(bytes=bytes(digest)).hex}, {}


def ely(username, password, root, job):
    data = json_request("https://authserver.ely.by/auth/authenticate", method="POST", body={"username": username, "password": password, "clientToken": uuid.uuid4().hex, "requestUser": True})
    selected = data.get("selectedProfile")
    if not selected:
        raise UserError("Ely.by не вернул игровой профиль.")
    meta = json_request("https://authlib-injector.yushi.moe/artifact/latest.json")
    path = root / "runtime" / "authlib-injector.jar"
    download(meta["download_url"], path, {"sha256": meta["checksums"]["sha256"]}, job=job)
    return {"id": uuid.uuid4().hex, "kind": "ely", "name": selected["name"], "uuid": selected["id"]}, {"access_token": data["accessToken"], "client_token": data.get("clientToken"), "injector": str(path)}


def microsoft(client_id, job, show_code):
    if not client_id:
        raise UserError("Добавьте Microsoft Client ID в настройки. Использовать чужие Client ID нельзя.")
    import requests
    endpoint = "https://login.microsoftonline.com/consumers/oauth2/v2.0/"
    response = requests.post(endpoint + "devicecode", data={"client_id": client_id, "scope": "XboxLive.signin offline_access"}, timeout=30)
    device = response.json()
    if not response.ok:
        raise UserError(device.get("error_description", "Microsoft отклонил запрос."))
    show_code({"code": device["user_code"], "url": device["verification_uri"], "expires": device["expires_in"]})
    interval = int(device.get("interval", 5)); deadline = time.monotonic() + int(device["expires_in"])
    while time.monotonic() < deadline:
        if job.cancelled.wait(interval):
            job.check()
        response = requests.post(endpoint + "token", data={"client_id": client_id, "grant_type": "urn:ietf:params:oauth:grant-type:device_code", "device_code": device["device_code"]}, timeout=30)
        result = response.json()
        if result.get("error") == "authorization_pending":
            continue
        if result.get("error") == "slow_down":
            interval += 5; continue
        if not response.ok:
            raise UserError(result.get("error_description", "Вход Microsoft прерван."))
        account, credentials = xbox(result["access_token"])
        credentials["refresh_token"] = result.get("refresh_token")
        return account, credentials
    raise UserError("Код Microsoft истёк. Повторите вход.")


def xbox(access_token):
    xbl = json_request("https://user.auth.xboxlive.com/user/authenticate", method="POST", body={"Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": "d=" + access_token}, "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"})
    xsts = json_request("https://xsts.auth.xboxlive.com/xsts/authorize", method="POST", body={"Properties": {"SandboxId": "RETAIL", "UserTokens": [xbl["Token"]]}, "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"})
    claim = xsts["DisplayClaims"]["xui"][0]
    data = json_request("https://api.minecraftservices.com/authentication/login_with_xbox", method="POST", body={"identityToken": "XBL3.0 x=" + claim["uhs"] + ";" + xsts["Token"]})
    profile = json_request("https://api.minecraftservices.com/minecraft/profile", headers={"Authorization": "Bearer " + data["access_token"]})
    return {"id": uuid.uuid4().hex, "kind": "microsoft", "name": profile["name"], "uuid": profile["id"]}, {"access_token": data["access_token"], "expires": time.time() + data.get("expires_in", 86400), "xuid": claim.get("xid", "0")}


def credentials_for(account, secrets, settings):
    if account["kind"] == "offline":
        return {}
    data = secrets.get("account-" + account["id"])
    if not data:
        raise UserError("Сессия не найдена. Войдите в аккаунт заново.")
    if account["kind"] == "microsoft" and data.get("expires", 0) < time.time() + 120:
        if not data.get("refresh_token"):
            raise UserError("Сессия Microsoft истекла. Войдите заново.")
        result = json_request("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", method="POST", form={"client_id": settings["microsoft_client_id"], "grant_type": "refresh_token", "refresh_token": data["refresh_token"], "scope": "XboxLive.signin offline_access"})
        _, fresh = xbox(result["access_token"])
        fresh["refresh_token"] = result.get("refresh_token", data["refresh_token"])
        secrets.put("account-" + account["id"], fresh)
        return fresh
    return data
