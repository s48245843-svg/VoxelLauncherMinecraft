"""Local, atomic persistence. Credentials are never sent to the catalog."""
from __future__ import annotations
import copy
import json
import os
import re
import sys
import threading
import uuid
from pathlib import Path

RESOURCE_ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
DEFAULT_ROOT = (Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "Voxel" if sys.platform == "win32" else Path.home() / "Library/Application Support/Voxel" if sys.platform == "darwin" else Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "voxel")
DATA_ROOT = Path(os.environ.get("VOXEL_DATA_DIR", DEFAULT_ROOT)).expanduser().resolve()
DEFAULTS = {"ram": 4096, "width": 1280, "height": 720, "fullscreen": False, "java_path": "", "jvm_args": "", "animations": True, "game_root": str(DATA_ROOT / "instances"), "microsoft_client_id": ""}


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        temp.chmod(0o600)
    except OSError:
        pass
    os.replace(temp, path)


class Store:
    def __init__(self, root=DATA_ROOT):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "launcher.json"
        self.lock = threading.RLock()
        self.data = {"schema": 3, "profiles": [], "accounts": [], "settings": dict(DEFAULTS), "active_account": "", "active_profile": ""}
        if self.path.exists():
            # Never silently replace a corrupt file with an empty launcher.
            self.data.update(json.loads(self.path.read_text(encoding="utf-8")))
        self.data["settings"] = {**DEFAULTS, **self.data.get("settings", {})}

    def snapshot(self):
        with self.lock:
            return copy.deepcopy(self.data)

    def save(self):
        with self.lock:
            atomic_json(self.path, self.data)

    def settings(self):
        return self.snapshot()["settings"]

    def configure(self, values):
        with self.lock:
            self.data["settings"].update(values)
            self.save()

    def add_profile(self, name, mc, loader="vanilla", loader_version="", **extra):
        name = str(name).strip()[:100]
        if not name or not re.fullmatch(r"[A-Za-z0-9_.+\-]+", str(mc)):
            raise ValueError("Укажите название и корректную версию Minecraft.")
        if loader not in ("vanilla", "fabric", "quilt", "forge", "neoforge"):
            raise ValueError("Загрузчик не поддерживается: " + str(loader))
        ident = uuid.uuid4().hex
        profile = {"id": ident, "name": name, "mc": mc, "loader": loader, "loader_version": loader_version, "ram": self.settings()["ram"], "directory": str(Path(self.settings()["game_root"]) / ident), "cover": "better-mc.png", "description": "Твой мир. Твои правила.", "state": "new", "installed": False, "mods": [], "pending": [], **extra}
        with self.lock:
            self.data["profiles"].append(profile)
            self.data["active_profile"] = ident
            self.save()
        return copy.deepcopy(profile)

    def profile(self, ident):
        for item in self.snapshot()["profiles"]:
            if item["id"] == ident:
                return item
        raise ValueError("Сборка не найдена. Выберите сборку в каталоге.")

    def patch(self, ident, **values):
        with self.lock:
            for item in self.data["profiles"]:
                if item["id"] == ident:
                    item.update(values)
                    self.save()
                    return copy.deepcopy(item)
        raise ValueError("Сборка не найдена.")

    def select(self, field, ident):
        with self.lock:
            self.data[field] = ident
            self.save()

    def remove(self, field, ident):
        with self.lock:
            self.data[field] = [p for p in self.data[field] if p["id"] != ident]
            self.save()

    def public(self):
        data = self.snapshot()
        return {"profiles": [{k: p.get(k) for k in ("id", "name", "mc", "loader", "state", "installed", "mods", "pending")} for p in data["profiles"]], "activeProfile": data["active_profile"]}


class Secrets:
    """Prefer the OS keychain; on a headless system use a 0600 local file."""
    def __init__(self, root=DATA_ROOT):
        self.path = Path(root) / "private-sessions.json"
        self.lock = threading.RLock()

    def get(self, name):
        try:
            import keyring
            value = keyring.get_password("VoxelLauncher", name)
            if value:
                return json.loads(value)
        except Exception:
            pass
        with self.lock:
            data = json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
            return data.get(name)

    def put(self, name, value):
        try:
            import keyring
            keyring.set_password("VoxelLauncher", name, json.dumps(value))
            return
        except Exception:
            pass
        with self.lock:
            data = json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
            data[name] = value
            atomic_json(self.path, data)

    def delete(self, name):
        try:
            import keyring
            keyring.delete_password("VoxelLauncher", name)
        except Exception:
            pass
        with self.lock:
            if self.path.exists():
                data = json.loads(self.path.read_text(encoding="utf-8"))
                data.pop(name, None)
                atomic_json(self.path, data)
