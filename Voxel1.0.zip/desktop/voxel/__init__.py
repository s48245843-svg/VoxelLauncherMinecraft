"""Voxel native launcher. The only web view is the content catalog."""
VERSION = "3.0.0"
