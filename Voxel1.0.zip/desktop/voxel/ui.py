"""Native launcher shell. Only the content catalog uses QWebEngineView."""
from __future__ import annotations
import json
import sys
import threading
from pathlib import Path
from PySide6.QtCore import Qt, QObject, Signal, QTimer, QPropertyAnimation, QEasingCurve, QSize, QUrl, QCoreApplication
from PySide6.QtGui import QDesktopServices, QFont, QFontDatabase, QIcon, QPixmap
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QFrame, QLabel, QVBoxLayout, QHBoxLayout, QGridLayout,
    QStackedWidget, QScrollArea, QLineEdit, QComboBox, QSpinBox, QSlider, QCheckBox, QListWidget, QListWidgetItem,
    QPlainTextEdit, QProgressBar, QFileDialog, QMessageBox, QDialog, QDialogButtonBox, QMenu, QGraphicsOpacityEffect)
from . import VERSION, game, accounts
from .state import RESOURCE_ROOT, Store, Secrets
from .network import Job, UserError, Cancelled
from .providers import Catalog
from .packages import Installer
from .widgets import Button, Picture, text, icon, logo, panel, dispose


class Events(QObject):
    result = Signal(str, object)
    error = Signal(str, str)
    progress = Signal(dict)
    log = Signal(str)
    device = Signal(dict)
    game_exit = Signal(int)


RECOMMENDED = [
 {"name": "Better MC", "description": "Больше приключений. Больше возможностей.", "cover": "better-mc.png", "loader": "Fabric", "mc": "1.20.1", "source": "modrinth", "query": "Better MC Fabric BMC2"},
 {"name": "Create: Astral", "description": "Создавай, исследуй и автоматизируй.", "cover": "create.png", "loader": "Fabric", "mc": "1.18.2", "source": "curseforge", "query": "Create Astral"},
 {"name": "Fabulously Optimized", "description": "Больше FPS. Тот же любимый Minecraft.", "cover": "fabric.png", "loader": "Fabric", "mc": "1.21.1", "source": "modrinth", "query": "Fabulously Optimized"}
]


class Window(QMainWindow):
    def __init__(self, store=None, online=True):
        super().__init__()
        self.store = store or Store(); self.secrets = Secrets(self.store.root)
        self.catalog = Catalog(self.secrets); self.installer = Installer(self.store, self.catalog)
        self.events = Events(self)
        self.events.result.connect(self.receive); self.events.error.connect(self.failure)
        self.events.progress.connect(self.progress); self.events.log.connect(self.log); self.events.device.connect(self.show_device)
        self.events.game_exit.connect(self.game_exited)
        self.current_job = None; self.process = None; self.running_profile = ""; self.launch_logs = []; self.version_data = []; self.web = None
        self.current_view = "home"; self.hero_slide = 0; self.loader_request = None
        self.setWindowTitle("Voxel Launcher · " + VERSION); self.resize(1280, 920); self.setMinimumSize(1000, 720)
        self.setWindowIcon(icon("box", "#f28b45", 48))
        self.setStyleSheet((RESOURCE_ROOT / "voxel" / "theme.qss").read_text(encoding="utf-8"))
        root = QWidget(); self.setCentralWidget(root)
        outer = QHBoxLayout(root); outer.setSpacing(0); outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(self.build_sidebar())
        body = QVBoxLayout(); body.setSpacing(0); body.setContentsMargins(0, 0, 0, 0); outer.addLayout(body, 1)
        body.addWidget(self.build_header())
        self.stack = QStackedWidget(); body.addWidget(self.stack, 1)
        self.pages = {}
        self.add_page("home", self.build_home)
        self.add_page("profiles", self.build_profiles)
        self.add_page("versions", self.build_versions)
        self.add_page("accounts", self.build_accounts)
        self.add_page("settings", self.build_settings)
        self.add_page("import", self.build_import)
        self.logbox = QPlainTextEdit(); self.logbox.setReadOnly(True); self.logbox.setMaximumBlockCount(1500); self.logbox.setFixedHeight(175); self.logbox.hide(); body.addWidget(self.logbox)
        body.addWidget(self.build_jobbar())
        self.toast = text("", "toast"); self.toast.setParent(self); self.toast.setStyleSheet("QLabel {background:#30302b;border:1px solid #66513d;border-radius:8px;padding:12px 18px;color:#f4dfcc;}"); self.toast.hide()
        self.toast_timer = QTimer(self); self.toast_timer.setSingleShot(True); self.toast_timer.timeout.connect(self.toast.hide)
        self.slide_timer = QTimer(self); self.slide_timer.setInterval(12000); self.slide_timer.timeout.connect(self.next_hero)
        if self.store.settings()["animations"]:
            self.slide_timer.start()
        self.navigate("home", animate=False); self.refresh()
        self.log("Voxel " + VERSION + " · Нативное окно Qt. Данные: " + str(self.store.root))
        if online:
            self.work("versions", game.available_versions)

    def work(self, name, fn):
        def worker():
            try:
                self.events.result.emit(name, fn())
            except Exception as error:
                self.events.error.emit(name, str(error))
        threading.Thread(target=worker, daemon=True, name="voxel-" + name).start()

    def start_install(self, fn, launch_id=""):
        if self.current_job:
            self.notify("Дождитесь текущей установки или отмените её."); return
        if self.process and self.process.poll() is None:
            self.notify("Закройте Minecraft перед изменением сборок."); return
        job = Job(lambda event: self.events.progress.emit(event)); self.current_job = job
        self.launch_after = launch_id
        self.job_cancel.show(); self.job_progress.setRange(0, 0)
        self.job_label.setText("Подготовка установки…"); self.job_hint.setText("Файлы будут сохранены на этом компьютере")
        self.work("installation", lambda: fn(job))

    def build_sidebar(self):
        sidebar = QFrame(); sidebar.setObjectName("sidebar"); sidebar.setFixedWidth(218)
        layout = QVBoxLayout(sidebar); layout.setContentsMargins(13, 30, 13, 18); layout.setSpacing(4)
        brand = QHBoxLayout(); brand.setSpacing(12); brand.setContentsMargins(7, 0, 0, 28); brand.addWidget(logo(38))
        name = QVBoxLayout(); name.setSpacing(1)
        name.addWidget(text("voxel.", "brand")); name.addWidget(text("M I N E C R A F T\nL A U N C H E R", "small")); brand.addLayout(name); brand.addStretch(); layout.addLayout(brand)
        layout.addWidget(text("Т В О Ё  П Р И К Л Ю Ч Е Н И Е", "small")); layout.addSpacing(8)
        self.nav = {}
        for key, title, glyph in [("home", "Главная", "home"), ("profiles", "Мои сборки", "layers"), ("versions", "Версии игры", "box"), ("catalog", "Моды и сборки", "puzzle"), ("import", "Импорт сборки", "import")]:
            b = Button(title, "nav", glyph, lambda k=key: self.navigate(k)); b.setCheckable(True); b.setMinimumHeight(44); self.nav[key] = b; layout.addWidget(b)
        layout.addSpacing(30); layout.addWidget(text("П Р О С Т Р А Н С Т В О  И Г Р О К А", "small")); layout.addSpacing(8)
        for key, title, glyph in [("accounts", "Аккаунты", "user"), ("settings", "Настройки", "settings")]:
            b = Button(title, "nav", glyph, lambda k=key: self.navigate(k)); b.setCheckable(True); b.setMinimumHeight(44); self.nav[key] = b; layout.addWidget(b)
        layout.addStretch()
        promo = QFrame(); promo.setObjectName("promo"); pv = QVBoxLayout(promo); pv.setContentsMargins(16, 18, 16, 16); pv.setSpacing(12)
        star = QLabel(); star.setPixmap(icon("sparkles", "#f5a46b", 25).pixmap(25, 25)); pv.addWidget(star)
        pv.addWidget(text("Собери что-то своё", "cardTitle")); pv.addWidget(text("Modrinth и CurseForge.\nМоды и целые сборки.", "muted"))
        pv.addWidget(Button("Открыть каталог", "link", "arrow", lambda: self.navigate("catalog"))); layout.addWidget(promo)
        layout.addSpacing(16); layout.addWidget(text("Voxel " + VERSION + "   ·   Python / Qt", "small"))
        return sidebar

    def build_header(self):
        bar = QFrame(); bar.setObjectName("topbar"); bar.setFixedHeight(70)
        row = QHBoxLayout(bar); row.setContentsMargins(30, 0, 30, 0)
        self.crumb = text("Лаунчер    ›    Главная", "muted"); row.addWidget(self.crumb); row.addStretch()
        self.connection = text("●  Локальное приложение", "status"); row.addWidget(self.connection); row.addSpacing(16)
        row.addWidget(Button("", "icon", "bell", lambda: self.logbox.setVisible(not self.logbox.isVisible())))
        self.account_chip = Button("Аккаунт", "secondary", "user", lambda: self.navigate("accounts")); row.addWidget(self.account_chip)
        return bar

    def add_page(self, name, builder):
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.Shape.NoFrame)
        content = QWidget(); content.setObjectName("page")
        layout = QVBoxLayout(content); layout.setContentsMargins(30, 26, 30, 28); layout.setSpacing(22)
        builder(layout); layout.addStretch(); scroll.setWidget(content); self.stack.addWidget(scroll); self.pages[name] = scroll

    def heading(self, layout, title, subtitle, action=None):
        row = QHBoxLayout(); labels = QVBoxLayout(); labels.setSpacing(5)
        labels.addWidget(text(title, "title")); labels.addWidget(text(subtitle, "subtitle")); row.addLayout(labels); row.addStretch()
        if action: row.addWidget(action)
        layout.addLayout(row)

    def build_home(self, layout):
        self.heading(layout, "Главная", "Хороший день, чтобы начать новое приключение.", Button("Импорт сборки", "secondary", "import", self.import_archive))
        self.hero = Picture("minecraft-hero.png", height=280, radius=12, hero=True)
        hv = QHBoxLayout(self.hero); hv.setContentsMargins(28, 26, 23, 25)
        copy = QVBoxLayout(); copy.setSpacing(10)
        copy.addWidget(text("M I N E C R A F T  J A V A  E D I T I O N", "eyebrow"))
        self.hero_title = text("Твой мир.\nТвои правила.", "heroTitle"); copy.addWidget(self.hero_title)
        self.hero_text = text("Все версии Minecraft, любимые моды и сборки.\nСобери своё приключение — остальное за нами.", "heroText"); copy.addWidget(self.hero_text)
        copy.addStretch(); actions = QHBoxLayout(); actions.setSpacing(14)
        actions.addWidget(Button("Начать играть", "primary", "play", self.quick_play))
        actions.addWidget(text("Версия", "small")); self.hero_version = QComboBox(); self.hero_version.addItem("1.21.1"); self.hero_version.setFixedWidth(110); actions.addWidget(self.hero_version); actions.addStretch(); copy.addLayout(actions)
        hv.addLayout(copy, 1); controls = QVBoxLayout(); controls.addStretch()
        self.slide_number = text("01  /  03", "heroText"); controls.addWidget(self.slide_number)
        controls.addWidget(Button("", "secondary", "chevron", self.next_hero)); hv.addLayout(controls); layout.addWidget(self.hero)
        header = QHBoxLayout(); self.home_collection_title = text("Мои сборки", "section"); header.addWidget(self.home_collection_title); self.home_count = text("0", "count"); header.addWidget(self.home_count); header.addStretch()
        header.addWidget(Button("Все сборки", "link", "arrow", lambda: self.navigate("profiles"))); layout.addLayout(header)
        host = QWidget(); self.home_cards = QGridLayout(host); self.home_cards.setContentsMargins(0,0,0,0); self.home_cards.setSpacing(15)
        for col in range(3): self.home_cards.setColumnStretch(col, 1)
        layout.addWidget(host)
        lower = QHBoxLayout(); lower.setSpacing(16)
        discover = panel(); dv = discover.layout(); dv.addWidget(text("Маленькие моды. Большие возможности.", "section"))
        mods = QHBoxLayout()
        for name, glyph in [("Sodium", "sparkles"), ("Iris", "layers"), ("Fabric API", "puzzle")]:
            mods.addWidget(Button(name, "secondary", glyph, lambda n=name: self.open_catalog(n, "modrinth", "mod")))
        dv.addLayout(mods); dv.addWidget(text("Файлы и обязательные зависимости — прямо в твою сборку.", "small")); lower.addWidget(discover, 3)
        quick = panel(); qv = quick.layout(); memory = QHBoxLayout(); memory.addWidget(text("Всё под контролем", "section")); memory.addStretch(); memory.addWidget(Button("", "icon", "settings", lambda: self.navigate("settings"))); qv.addLayout(memory)
        self.quick_ram = text("Оперативная память                                  4 ГБ", "muted"); qv.addWidget(self.quick_ram)
        qv.addWidget(Button("Открыть папку игры", "link", "folder", self.open_active_folder)); lower.addWidget(quick, 2); layout.addLayout(lower)

    def build_profiles(self, layout):
        self.heading(layout, "Мои сборки", "Версии, миры и моды хранятся раздельно.", Button("Новая сборка", "primary", "plus", lambda: self.navigate("versions")))
        self.profile_filter = QLineEdit(); self.profile_filter.setPlaceholderText("Найти сборку…"); self.profile_filter.textChanged.connect(self.refresh_cards); layout.addWidget(self.profile_filter)
        host = QWidget(); self.profile_cards = QGridLayout(host); self.profile_cards.setContentsMargins(0,0,0,0); self.profile_cards.setSpacing(16)
        for col in range(3): self.profile_cards.setColumnStretch(col, 1)
        layout.addWidget(host)

    def profile_card(self, profile, recommended=False):
        frame = QFrame(); frame.setObjectName("profileCard"); frame.setMinimumWidth(230); frame.setMaximumHeight(285)
        v = QVBoxLayout(frame); v.setContentsMargins(0,0,0,0); v.setSpacing(0)
        cover = Picture(profile.get("cover", "better-mc.png"), height=126)
        overlay = QHBoxLayout(cover); overlay.setContentsMargins(12,12,10,12); overlay.setAlignment(Qt.AlignmentFlag.AlignTop)
        badge = text(profile.get("loader", "vanilla").capitalize(), "badge"); badge.setMaximumHeight(26); overlay.addWidget(badge); overlay.addStretch()
        if not recommended:
            menu = Button("", "icon", "more"); menu.setFixedSize(30,26); menu.clicked.connect(lambda: self.profile_menu(profile, menu)); overlay.addWidget(menu)
        v.addWidget(cover)
        body = QWidget(); bv = QVBoxLayout(body); bv.setContentsMargins(14,13,14,12); bv.setSpacing(8)
        title = text(profile["name"], "cardTitle"); title.setToolTip(profile["name"]); bv.addWidget(title)
        version = "Minecraft " + profile["mc"] + " · " + profile.get("loader", "vanilla").capitalize()
        bv.addWidget(text(version, "small")); description = text(profile.get("description", ""), "small"); description.setToolTip(profile.get("description", "")); bv.addWidget(description)
        line = QFrame(); line.setFrameShape(QFrame.Shape.HLine); line.setStyleSheet("color:#333b43;"); bv.addWidget(line)
        bottom = QHBoxLayout(); bottom.setSpacing(6)
        if recommended:
            bottom.addWidget(text("Каталог · " + profile["source"].capitalize(), "small")); bottom.addStretch()
            bottom.addWidget(Button("Выбрать", "outline", "download", lambda: self.open_catalog(profile["query"], profile["source"], "modpack")))
        else:
            status = {"ready":"Готово", "new":"Не установлено", "installing":"Установка…", "error":"Ошибка", "paused":"Пауза", "blocked":"Нужны файлы"}.get(profile.get("state"), "Не установлено")
            bottom.addWidget(text(f"{profile.get('ram', 4096)//1024} ГБ · {status}", "small")); bottom.addStretch()
            bottom.addWidget(Button("Играть" if profile.get("installed") else "Установить", "outline", "play" if profile.get("installed") else "download", lambda: self.play_profile(profile["id"])))
        bv.addLayout(bottom); v.addWidget(body)
        return frame

    def build_versions(self, layout):
        self.heading(layout, "Версии игры", "Каталог Mojang · Vanilla, Fabric, Forge, NeoForge и Quilt")
        row = QHBoxLayout(); left = QVBoxLayout(); controls = QHBoxLayout()
        self.version_query = QLineEdit(); self.version_query.setPlaceholderText("Поиск версии…"); self.version_query.textChanged.connect(self.filter_versions); controls.addWidget(self.version_query)
        self.snapshots = QCheckBox("Снапшоты / старые"); self.snapshots.toggled.connect(self.filter_versions); controls.addWidget(self.snapshots); left.addLayout(controls)
        self.version_list = QListWidget(); self.version_list.setMinimumHeight(460); self.version_list.currentItemChanged.connect(self.version_selected); left.addWidget(self.version_list)
        left.addWidget(Button("Обновить каталог", "secondary", "refresh", lambda: self.work("versions", game.available_versions)))
        right = panel(); right.setFixedWidth(315); rv = right.layout(); rv.addWidget(text("НОВАЯ СБОРКА", "eyebrow"))
        self.version_name = QLineEdit(); self.version_name.setPlaceholderText("Например, мой мир"); rv.addWidget(self.version_name)
        rv.addWidget(text("Загрузчик модов", "muted")); self.loader = QComboBox(); self.loader.addItems(["vanilla", "fabric", "forge", "neoforge", "quilt"]); self.loader.currentTextChanged.connect(self.load_loaders); rv.addWidget(self.loader)
        rv.addWidget(text("Версия загрузчика", "muted")); self.loader_version = QComboBox(); rv.addWidget(self.loader_version)
        rv.addWidget(text("Выделить памяти, МБ", "muted")); self.version_ram = QSpinBox(); self.version_ram.setRange(1024,65536); self.version_ram.setSingleStep(512); self.version_ram.setValue(self.store.settings()["ram"]); rv.addWidget(self.version_ram)
        self.version_status = text("Выберите Minecraft слева.", "small", True); rv.addWidget(self.version_status)
        self.create_button = Button("Создать сборку", "primary", "plus", self.create_profile); self.create_button.setEnabled(False); rv.addWidget(self.create_button); rv.addStretch()
        row.addLayout(left,1); row.addWidget(right); layout.addLayout(row)

    def build_accounts(self, layout):
        self.heading(layout, "Аккаунты", "Локальные сессии. Каталог модов не получает твои токены.")
        host = QWidget(); self.account_cards = QVBoxLayout(host); self.account_cards.setContentsMargins(0,0,0,0); self.account_cards.setSpacing(10); layout.addWidget(host)
        options = QHBoxLayout()
        offline = panel(); ov = offline.layout(); ov.addWidget(text("ОФЛАЙН", "eyebrow")); ov.addWidget(text("Одиночная игра", "section")); self.nick = QLineEdit(); self.nick.setPlaceholderText("Никнейм"); ov.addWidget(self.nick); ov.addWidget(Button("Добавить", "primary", "user", self.add_offline)); options.addWidget(offline)
        ely = panel(); ev = ely.layout(); ev.addWidget(text("ELY.BY", "eyebrow")); self.ely_user = QLineEdit(); self.ely_user.setPlaceholderText("Логин / e-mail"); ev.addWidget(self.ely_user); self.ely_password = QLineEdit(); self.ely_password.setEchoMode(QLineEdit.EchoMode.Password); self.ely_password.setPlaceholderText("Пароль (пароль:код при 2FA)"); ev.addWidget(self.ely_password); ev.addWidget(Button("Войти", "primary", "user", self.add_ely)); options.addWidget(ely)
        ms = panel(); mv = ms.layout(); mv.addWidget(text("MICROSOFT", "eyebrow")); mv.addWidget(text("Лицензионный аккаунт", "section")); mv.addWidget(text("Вход по коду. Client ID своего приложения — в настройках.", "muted", True)); mv.addWidget(Button("Войти по коду", "primary", "user", self.add_ms)); options.addWidget(ms)
        layout.addLayout(options)
        self.auth_status = text("Офлайн-профиль не даёт лицензию и не заменяет покупку Minecraft.", "muted", True); layout.addWidget(self.auth_status)
        self.device_panel = panel(); dv = self.device_panel.layout(); self.device_code = text("", "title"); self.device_code.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); dv.addWidget(self.device_code); self.device_url = text("", "muted"); dv.addWidget(self.device_url); dv.addWidget(Button("Открыть Microsoft", "primary", "external", self.open_device)); self.device_panel.hide(); layout.addWidget(self.device_panel)

    def build_settings(self, layout):
        self.heading(layout, "Настройки", "Память, папки, Java и доступ к каталогам.")
        frame = panel(); f = frame.layout(); settings = self.store.settings()
        self.ram_label = text("Память: " + str(settings["ram"]//1024) + " ГБ", "section"); f.addWidget(self.ram_label)
        self.settings_ram = QSlider(Qt.Orientation.Horizontal); self.settings_ram.setRange(2,64); self.settings_ram.setValue(settings["ram"]//512); self.settings_ram.valueChanged.connect(lambda value:self.ram_label.setText(f"Память: {value/2:g} ГБ")); f.addWidget(self.settings_ram)
        self.fields = {}
        for key, title, hint in [("game_root","Папка для новых сборок",""),("java_path","Путь к Java","Пусто — официальная Java автоматически"),("width","Ширина окна","1280"),("height","Высота окна","720"),("jvm_args","JVM-аргументы","-XX:+UseG1GC"),("microsoft_client_id","Microsoft Client ID","Public-client приложение с разрешением Minecraft Services")]:
            f.addWidget(text(title,"muted")); field = QLineEdit(str(settings.get(key,""))); field.setPlaceholderText(hint); self.fields[key] = field
            if key == "game_root":
                row=QHBoxLayout(); row.addWidget(field,1); row.addWidget(Button("Выбрать…","secondary","folder",self.choose_game_root)); f.addLayout(row)
            else: f.addWidget(field)
        f.addWidget(text("CurseForge API-ключ", "section")); self.cf_key = QLineEdit(); self.cf_key.setEchoMode(QLineEdit.EchoMode.Password); self.cf_key.setPlaceholderText("Ключ сохранён" if self.catalog.key() else "Из console.curseforge.com — не передаётся в WebUI"); f.addWidget(self.cf_key)
        f.addWidget(text("CurseForge требует ключ. Если автор запретил загрузку, лаунчер покажет конкретные недостающие файлы — не обходит запрет.","small",True))
        self.fullscreen = QCheckBox("Полноэкранный режим"); self.fullscreen.setChecked(settings["fullscreen"]); f.addWidget(self.fullscreen)
        self.animations = QCheckBox("Плавные переходы и смена баннера"); self.animations.setChecked(settings["animations"]); f.addWidget(self.animations)
        row=QHBoxLayout(); row.addWidget(Button("Сохранить", "primary", "check", self.save_settings)); row.addWidget(Button("Получить ключ CurseForge", "link", "external",lambda:QDesktopServices.openUrl(QUrl("https://console.curseforge.com/")))); row.addStretch(); f.addLayout(row)
        layout.addWidget(frame); layout.addWidget(text("Существующие сборки сохраняют свою папку. Изменение пути применяется только к новым сборкам.","small",True))

    def build_import(self, layout):
        self.heading(layout, "Импорт сборки", "Modrinth MRPACK и клиентские ZIP-архивы CurseForge")
        frame = panel(); f = frame.layout(); f.setContentsMargins(38,42,38,38)
        mark=QLabel(); mark.setPixmap(icon("import","#f2a26c",50).pixmap(50,50)); f.addWidget(mark)
        f.addWidget(text("Твоя сборка. В новом доме.","title")); f.addWidget(text("Перенеси .mrpack или .zip. Лаунчер прочитает манифест, скачает моды, скопирует overrides и установит нужные Minecraft и загрузчик.","muted",True))
        f.addWidget(Button("Выбрать архив", "primary", "folder", self.import_archive)); self.include_optional = QCheckBox("Устанавливать необязательные клиентские файлы MRPACK"); self.include_optional.setChecked(True); f.addWidget(self.include_optional)
        f.addWidget(text("CurseForge ZIP содержит ID файлов, а не сами моды: для их разрешения нужен API-ключ. Серверные архивы не подходят. Загрузчик берётся из манифеста, поэтому несовместимые версии не смешиваются.","small",True)); layout.addWidget(frame)
        layout.addWidget(Button("Найти Better MC в CurseForge", "secondary", "search", lambda:self.open_catalog("Better MC","curseforge","modpack")))

    def build_jobbar(self):
        bar = QFrame(); bar.setObjectName("job"); v=QVBoxLayout(bar); v.setContentsMargins(28,12,28,12); v.setSpacing(6)
        row=QHBoxLayout(); self.job_label=text("Готово к приключению", "muted"); row.addWidget(self.job_label,1)
        self.job_hint=text("Все файлы — на твоём компьютере", "small"); row.addWidget(self.job_hint)
        self.job_cancel=Button("Отменить","link","close",self.cancel_job); self.job_cancel.hide(); row.addWidget(self.job_cancel)
        self.game_stop=Button("Завершить игру","secondary","stop",self.stop_game); self.game_stop.hide(); row.addWidget(self.game_stop)
        row.addWidget(Button("Лог","icon","log",lambda:self.logbox.setVisible(not self.logbox.isVisible()))); v.addLayout(row)
        self.job_progress=QProgressBar(); self.job_progress.setTextVisible(False); self.job_progress.setFixedHeight(4); self.job_progress.setRange(0,100); self.job_progress.setValue(0); v.addWidget(self.job_progress)
        return bar

    def navigate(self, name, animate=True):
        old = self.stack.currentWidget()
        if name == "catalog" and self.web is None:
            from .catalog import CatalogView
            self.web = CatalogView(self.catalog, self.store, self)
            b=self.web.bridge; b.installRequested.connect(self.request_install); b.importRequested.connect(self.import_archive); b.settingsRequested.connect(lambda:self.navigate("settings")); b.cancelRequested.connect(self.cancel_job)
            self.pages[name]=self.web; self.stack.addWidget(self.web)
        if name not in self.pages:return
        target=self.pages[name]
        self.stack.setCurrentWidget(target)
        titles={"home":"Главная","profiles":"Мои сборки","versions":"Версии игры","catalog":"Моды и сборки","accounts":"Аккаунты","settings":"Настройки","import":"Импорт сборки"}
        self.crumb.setText("Лаунчер    ›    " + titles[name]); self.current_view=name
        for key,b in self.nav.items():
            b.setChecked(key==name)
        if animate and old != target and self.store.settings()["animations"] and name != "catalog":
            effect=QGraphicsOpacityEffect(target); target.setGraphicsEffect(effect)
            animation=QPropertyAnimation(effect,b"opacity",self); animation.setDuration(180); animation.setStartValue(.45); animation.setEndValue(1.0); animation.setEasingCurve(QEasingCurve.Type.OutCubic)
            animation.finished.connect(lambda w=target:w.setGraphicsEffect(None)); self.page_animation=animation; animation.start()
        if name=="catalog":self.web.sync()

    def next_hero(self):
        if self.current_view!="home":return
        self.hero_slide=(self.hero_slide+1)%3
        pictures=["minecraft-hero.png","better-mc.png","fabric.png"]
        titles=["Твой мир.\nТвои правила.","Больше мира.\nБольше историй.","Твоя игра.\nЕщё красивее."]
        self.hero.set_picture(pictures[self.hero_slide]); self.hero_title.setText(titles[self.hero_slide]); self.slide_number.setText(f"0{self.hero_slide+1}  /  03")

    def refresh(self):
        data=self.store.snapshot(); self.refresh_cards(); dispose(self.account_cards)
        for account in data["accounts"]:
            frame=panel(); row=QHBoxLayout(); frame.layout().addLayout(row)
            row.addWidget(text(account["name"],"section")); row.addWidget(text({"offline":"Офлайн","ely":"Ely.by","microsoft":"Microsoft"}[account["kind"]],"muted")); row.addStretch()
            if account["id"]==data["active_account"]:row.addWidget(text("Активный аккаунт","status"))
            else:row.addWidget(Button("Выбрать","secondary","check",lambda a=account:self.select_account(a["id"])))
            row.addWidget(Button("Удалить","icon","close",lambda a=account:self.delete_account(a["id"]))); self.account_cards.addWidget(frame)
        active=next((a for a in data["accounts"] if a["id"]==data["active_account"]),None)
        self.account_chip.setText(active["name"] if active else "Добавить аккаунт")
        self.quick_ram.setText(f"Оперативная память                         {self.store.settings()['ram']/1024:g} ГБ")
        if self.web:self.web.sync()

    def refresh_cards(self):
        data=self.store.snapshot(); profiles=data["profiles"]
        dispose(self.home_cards); dispose(self.profile_cards)
        self.home_count.setText(str(len(profiles) if profiles else len(RECOMMENDED)))
        self.home_collection_title.setText("Мои сборки" if profiles else "Открой новую сборку")
        if profiles:
            for i,p in enumerate(profiles[:3]):self.home_cards.addWidget(self.profile_card(p),0,i)
        else:
            for i,p in enumerate(RECOMMENDED):self.home_cards.addWidget(self.profile_card(p,True),0,i)
        query=self.profile_filter.text().casefold()
        for i,p in enumerate([p for p in profiles if query in p["name"].casefold()]):
            self.profile_cards.addWidget(self.profile_card(p),i//3,i%3)
        if not profiles:self.profile_cards.addWidget(text("Сборок пока нет. Установи готовую из каталога или создай свою версию.","muted",True),0,0,1,3)

    def profile_menu(self, profile, anchor):
        menu=QMenu(self)
        for title,glyph,fn in [("Настройки сборки","settings",lambda:self.edit_profile(profile["id"])),("Файлы и проверка","layers",lambda:self.files_dialog(profile["id"])),("Проверить / продолжить","refresh",lambda:self.install_profile(profile["id"])),("Открыть папку","folder",lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(profile["directory"]))),("Удалить из списка","close",lambda:self.remove_profile(profile["id"]))]:
            menu.addAction(icon(glyph),title,fn)
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))

    def edit_profile(self, ident):
        p=self.store.profile(ident); dialog=QDialog(self); dialog.setWindowTitle("Настройки сборки"); dialog.resize(420,250); layout=QVBoxLayout(dialog)
        name=QLineEdit(p["name"]); ram=QSpinBox(); ram.setRange(1024,65536); ram.setSingleStep(512); ram.setValue(p["ram"])
        layout.addWidget(text("Название","muted")); layout.addWidget(name); layout.addWidget(text("Оперативная память, МБ","muted")); layout.addWidget(ram)
        layout.addWidget(text(p["mc"]+" · "+p["loader"]+" · "+p.get("loader_version",""),"small"))
        controls=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel); controls.accepted.connect(dialog.accept); controls.rejected.connect(dialog.reject); layout.addWidget(controls)
        if dialog.exec() and name.text().strip():self.store.patch(ident,name=name.text().strip()[:100],ram=ram.value());self.refresh()

    def remove_profile(self, ident):
        if self.current_job or self.running_profile==ident:self.notify("Сначала завершите текущую операцию.");return
        if QMessageBox.question(self,"Удалить сборку?","Профиль будет удалён из списка. Миры и файлы останутся на диске.")==QMessageBox.StandardButton.Yes:
            self.store.remove("profiles",ident); self.refresh()

    def files_dialog(self, ident):
        p=self.store.profile(ident); dialog=QDialog(self); dialog.setWindowTitle("Файлы · "+p["name"]); dialog.resize(680,520); layout=QVBoxLayout(dialog)
        layout.addWidget(text(f"{len(p.get('mods',[]))} файлов в манифесте · {len(p.get('pending',[]))} требуют ручного скачивания","section",True))
        listing=QListWidget(); layout.addWidget(listing,1)
        if p.get("pending"):
            for rec in p["pending"]:listing.addItem(rec["path"])
            row=QHBoxLayout()
            def open_link():
                index=listing.currentRow()
                if index>=0:QDesktopServices.openUrl(QUrl(p["pending"][index]["manual_url"]))
            def supply():
                index=listing.currentRow()
                if index<0:return
                path,_=QFileDialog.getOpenFileName(dialog,"Выбрать скачанный файл")
                if not path:return
                try:self.installer.supply_manual(ident,index,path);dialog.accept();self.refresh();self.files_dialog(ident)
                except Exception as e:QMessageBox.warning(dialog,"Проверка файла",str(e))
            row.addWidget(Button("Страница файла","secondary","external",open_link)); row.addWidget(Button("Выбрать скачанный файл","primary","folder",supply)); layout.addLayout(row)
        else:
            for rec in p.get("mods",[]):listing.addItem(rec["path"]+" · "+next(iter(rec.get("hashes",{})),"без хеша").upper())
        if p.get("error"):layout.addWidget(text(p["error"],"muted",True))
        row=QHBoxLayout();row.addWidget(Button("Открыть папку","secondary","folder",lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(p["directory"]))));row.addWidget(Button("Проверить / продолжить","primary","refresh",lambda:(dialog.accept(),self.install_profile(ident))));layout.addLayout(row)
        dialog.exec()

    def filter_versions(self):
        current=self.selected_version(); self.version_list.blockSignals(True); self.version_list.clear()
        query=self.version_query.text().strip().lower()
        for item in self.version_data:
            if query not in item["id"].lower() or (item["type"]!="release" and not self.snapshots.isChecked()):continue
            row=QListWidgetItem(item["id"]+"     ·     "+item["type"]);row.setData(Qt.ItemDataRole.UserRole,item["id"]);self.version_list.addItem(row)
            if item["id"]==current:self.version_list.setCurrentItem(row)
        self.version_list.blockSignals(False)

    def selected_version(self):
        item=self.version_list.currentItem();return item.data(Qt.ItemDataRole.UserRole) if item else ""

    def version_selected(self, current, old=None):
        mc=self.selected_version()
        if not mc:return
        if not self.version_name.text():self.version_name.setText("Minecraft "+mc)
        self.load_loaders()

    def load_loaders(self):
        mc=self.selected_version(); loader=self.loader.currentText()
        self.loader_version.clear();self.create_button.setEnabled(False)
        if not mc:return
        if loader=="vanilla":self.loader_version.addItem("Без загрузчика","");self.create_button.setEnabled(True);self.version_status.setText("Minecraft "+mc);return
        self.version_status.setText("Получение совместимых загрузчиков…")
        pair=(mc,loader);self.loader_request=pair;self.work("loaders",lambda:(pair,game.loader_versions(mc,loader)))

    def create_profile(self):
        mc=self.selected_version();loader=self.loader.currentText();lv=self.loader_version.currentData()
        if not mc or not self.version_name.text().strip() or (loader!="vanilla" and not lv):self.notify("Выбери название, Minecraft и версию загрузчика.");return
        try:
            p=self.store.add_profile(self.version_name.text(),mc,loader,lv or "",ram=self.version_ram.value(),cover="fabric.png" if loader in ("fabric","quilt") else "better-mc.png")
            self.refresh();self.navigate("home");self.notify("Создана сборка "+p["name"])
        except Exception as e:self.notify(str(e))

    def quick_play(self):
        data=self.store.snapshot(); ident=data.get("active_profile")
        if ident and any(p["id"]==ident for p in data["profiles"]):self.play_profile(ident)
        else:self.navigate("versions")

    def install_profile(self, ident):
        self.start_install(lambda job:self.installer.resume(ident,job))

    def play_profile(self, ident):
        p=self.store.profile(ident);self.store.select("active_profile",ident)
        if p.get("pending"):self.files_dialog(ident);return
        if not p.get("installed"):
            self.start_install(lambda job:self.installer.resume(ident,job));return
        data=self.store.snapshot(); account=next((a for a in data["accounts"] if a["id"]==data["active_account"]),None)
        if not account:self.navigate("accounts");self.notify("Добавь аккаунт перед запуском игры.");return
        if self.current_job or (self.process and self.process.poll() is None):self.notify("Дождитесь текущей операции.");return
        settings=self.store.settings()
        def run():
            credentials=accounts.credentials_for(account,self.secrets,settings)
            process=game.launch(p,account,credentials,settings,lambda msg:self.events.log.emit(msg))
            return (ident,process,credentials.get("access_token",""))
        self.work("launch",run);self.job_label.setText("Проверка и запуск Minecraft…")

    def import_archive(self):
        if self.current_job:self.notify("Дождитесь текущей установки.");return
        path,_=QFileDialog.getOpenFileName(self,"Импорт клиентской сборки","","Сборки (*.mrpack *.zip)")
        if not path:return
        if QMessageBox.question(self,"Установить сборку?","Моды — исполняемый код. Устанавливайте архивы только из доверенных источников. Скачать все файлы и установить загрузчик?")!=QMessageBox.StandardButton.Yes:return
        optional=self.include_optional.isChecked()
        self.start_install(lambda job:self.installer.import_pack(path,job,optional))

    def request_install(self, payload):
        if self.current_job:self.notify("Дождитесь текущей загрузки.");return
        title=str(payload.get("title","проект"))[:150]
        if QMessageBox.question(self,"Подтверждение установки",f"Установить «{title}» и обязательные зависимости?\n\nМоды выполняют код на компьютере. Продолжайте только если доверяете автору.")!=QMessageBox.StandardButton.Yes:return
        source,pid,vid=payload["source"],payload["projectId"],payload["versionId"]
        if payload["kind"]=="modpack":self.start_install(lambda job:self.installer.download_project_pack(source,pid,vid,job))
        elif payload["kind"]=="mod":self.start_install(lambda job:self.installer.install_mod(source,pid,vid,payload["profileId"],job))
        else:self.start_install(lambda job:self.installer.install_asset(source,pid,vid,payload["profileId"],payload["kind"],job))

    def open_catalog(self, query="", source="modrinth", kind="modpack"):
        self.navigate("catalog");self.web.search(query,source,kind)

    def receive(self, name, result):
        if name=="versions":
            self.version_data=result;self.filter_versions();current=self.hero_version.currentText();self.hero_version.clear();self.hero_version.addItems([v["id"] for v in result if v["type"]=="release"])
            if current:self.hero_version.setCurrentText(current)
        elif name=="loaders":
            pair,items=result
            if pair!=self.loader_request or pair!=(self.selected_version(),self.loader.currentText()):return
            self.loader_version.clear()
            for item in items:self.loader_version.addItem(item,item)
            self.create_button.setEnabled(bool(items));self.version_status.setText(f"{len(items)} совместимых версий" if items else "Нет загрузчика для этой версии Minecraft.")
        elif name=="installation":
            self.current_job=None;self.job_cancel.hide();self.job_progress.setRange(0,100)
            blocked=isinstance(result,dict) and result.get("state")=="blocked"
            self.job_label.setText("Нужны файлы от автора — открой «Файлы сборки»" if blocked else "Операция завершена. Файлы проверены.")
            self.job_progress.setValue(0 if blocked else 100);self.refresh();self.notify(self.job_label.text())
            if self.web:self.web.bridge.progress.emit(json.dumps({"phase":"blocked" if blocked else "completed","message":self.job_label.text(),"done":0 if blocked else 1,"total":1}))
        elif name=="launch":
            ident,process,token=result;self.process=process;self.running_profile=ident;self.game_stop.show();self.job_label.setText(f"Minecraft · процесс {process.pid}")
            def reader():
                for line in process.stdout:
                    self.events.log.emit(line.rstrip().replace(token,"[скрыто]") if token else line.rstrip())
                self.events.game_exit.emit(process.wait())
            threading.Thread(target=reader,daemon=True).start()
        elif name=="account":
            account,credentials=result
            if credentials:self.secrets.put("account-"+account["id"],credentials)
            with self.store.lock:
                self.store.data["accounts"].append(account);self.store.data["active_account"]=account["id"];self.store.save()
            self.auth_status.setText("Вход выполнен: "+account["name"]);self.ely_password.clear();self.device_panel.hide();self.refresh()

    def failure(self, name, error):
        self.log("Ошибка · "+error);self.notify(error)
        if name=="installation":
            self.current_job=None;self.job_cancel.hide();self.job_progress.setRange(0,100);self.job_progress.setValue(0);self.job_label.setText("Установка не завершена — можно повторить");self.refresh()
            if self.web:self.web.bridge.progress.emit(json.dumps({"phase":"error","message":error}))
        if name=="account":self.auth_status.setText(error);self.device_panel.hide()
        if name=="loaders":self.version_status.setText(error)

    def progress(self, event):
        done,total=event.get("done",0),event.get("total",0);self.job_label.setText(str(event.get("message",""))[:100]);self.job_label.setToolTip(str(event.get("message","")))
        if total:self.job_progress.setRange(0,100);self.job_progress.setValue(min(100,int(done/total*100)))
        else:self.job_progress.setRange(0,0)
        if event.get("received"):self.job_hint.setText(f"{event['received']/1048576:.1f} МБ · {event.get('speed',0)/1048576:.1f} МБ/с")
        elif total:self.job_hint.setText(f"{done} / {total}")
        if event.get("phase") in ("completed","error") or (event.get("phase")=="files" and (done%20==0 or done==total)):self.log(event["message"])
        if self.web:self.web.bridge.progress.emit(json.dumps(event))

    def log(self, value):
        self.logbox.appendPlainText(str(value)[:3000])

    def notify(self, message):
        self.toast.setText(str(message)[:230]);self.toast.setWordWrap(True);self.toast.setMaximumWidth(500);self.toast.adjustSize()
        self.toast.move(max(20,self.width()-self.toast.width()-24),max(10,self.height()-self.toast.height()-84));self.toast.show();self.toast.raise_();self.toast_timer.start(6000)

    def cancel_job(self):
        if self.current_job:self.current_job.cancelled.set();self.job_label.setText("Отменяем после текущего файла…");self.job_cancel.setEnabled(False);QTimer.singleShot(1000,lambda:self.job_cancel.setEnabled(True))

    def stop_game(self):
        if self.process and self.process.poll() is None and QMessageBox.question(self,"Завершить Minecraft?","Несохранённый прогресс мира может потеряться. Лучше выйти через меню игры.")==QMessageBox.StandardButton.Yes:self.process.terminate()

    def game_exited(self, code):
        self.running_profile="";self.game_stop.hide();self.job_label.setText("Minecraft завершён" if code==0 else f"Minecraft завершился с ошибкой {code} — открой лог")
        if code!=0:self.logbox.show()

    def add_offline(self):
        try:self.receive("account",accounts.offline(self.nick.text().strip()))
        except Exception as e:self.notify(str(e))

    def add_ely(self):
        user,password=self.ely_user.text().strip(),self.ely_password.text()
        self.auth_status.setText("Вход в Ely.by…");self.work("account",lambda:accounts.ely(user,password,self.store.root,Job()))

    def add_ms(self):
        settings=self.store.settings();self.auth_status.setText("Запрашиваем код Microsoft…")
        self.auth_job=Job();self.work("account",lambda:accounts.microsoft(settings["microsoft_client_id"],self.auth_job,lambda code:self.events.device.emit(code)))

    def show_device(self, data):
        self.device_data=data;self.device_code.setText(data["code"]);self.device_url.setText(data["url"]);self.device_panel.show();self.auth_status.setText("Откройте Microsoft и введите код. Пароль лаунчеру не передаётся.")

    def open_device(self):
        if getattr(self,"device_data",None):QDesktopServices.openUrl(QUrl(self.device_data["url"]))

    def select_account(self, ident):self.store.select("active_account",ident);self.refresh()
    def delete_account(self, ident):
        if QMessageBox.question(self,"Удалить аккаунт?","Сессия будет удалена с этого компьютера.")==QMessageBox.StandardButton.Yes:
            self.secrets.delete("account-"+ident);self.store.remove("accounts",ident);self.refresh()

    def choose_game_root(self):
        path=QFileDialog.getExistingDirectory(self,"Папка новых сборок",self.fields["game_root"].text())
        if path:self.fields["game_root"].setText(path)

    def save_settings(self):
        try:
            data={k:field.text().strip() for k,field in self.fields.items()}
            for key in ("width","height"):
                data[key]=int(data[key])
                if not 320<=data[key]<=16384:raise ValueError("Разрешение должно быть от 320 до 16384.")
            data["game_root"]=str(Path(data["game_root"]).expanduser().resolve());data.update(ram=self.settings_ram.value()*512,fullscreen=self.fullscreen.isChecked(),animations=self.animations.isChecked())
            if self.cf_key.text().strip():self.secrets.put("curseforge-api-key",self.cf_key.text().strip());self.cf_key.clear();self.cf_key.setPlaceholderText("Ключ сохранён")
            self.store.configure(data);self.slide_timer.start() if data["animations"] else self.slide_timer.stop();self.refresh();self.notify("Настройки сохранены")
        except Exception as e:self.notify(str(e))

    def open_active_folder(self):
        ident=self.store.snapshot().get("active_profile")
        path=self.store.profile(ident)["directory"] if ident else self.store.settings()["game_root"]
        Path(path).mkdir(parents=True,exist_ok=True);QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def closeEvent(self, event):
        if self.current_job:
            if QMessageBox.question(self,"Идёт установка","Прервать загрузку и закрыть лаунчер? Проверенные файлы сохранятся.")!=QMessageBox.StandardButton.Yes:event.ignore();return
            self.current_job.cancelled.set()
        if getattr(self,"auth_job",None):self.auth_job.cancelled.set()
        if self.web:self.web.shutdown()
        event.accept()


def main():
    QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app=QApplication.instance() or QApplication(sys.argv);app.setStyle("Fusion")
    QFontDatabase.addApplicationFont(str(RESOURCE_ROOT / "assets" / "Inter.ttf"))
    font=QFont("Inter");font.setPixelSize(12);font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias);app.setFont(font)
    window=Window();window.show();return app.exec()
