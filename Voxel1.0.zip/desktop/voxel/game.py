"""Minecraft installation and subprocess launch, delegated to the tested metadata engine."""
from __future__ import annotations
import json
import re
import shlex
import subprocess
from pathlib import Path
import minecraft_launcher_lib as mc
from .network import Job, UserError, verify


def available_versions():
    return [{"id": v["id"], "type": v["type"]} for v in mc.utils.get_version_list()]


def loader_versions(version, loader):
    if loader == "vanilla":
        return [""]
    return mc.mod_loader.get_mod_loader(loader).get_loader_versions(version, False)


def callbacks(job):
    stage = {"message": "Подготовка Minecraft", "maximum": 0}
    def status(value):
        job.check()
        stage["message"] = str(value)
        job.update("Minecraft · " + str(value), phase="game", force=True)
    def maximum(value):
        stage["maximum"] = int(value)
    def progress(value):
        job.update("Minecraft · " + stage["message"], int(value), stage["maximum"], "game")
    return {"setStatus": status, "setMax": maximum, "setProgress": progress}


def ensure_java(version, directory, settings, job):
    info = mc.runtime.get_version_runtime_information(version, directory) or {"name": "jre-legacy", "javaMajorVersion": 8}
    if settings.get("java_path"):
        path = str(Path(settings["java_path"]).expanduser())
        try:
            output = subprocess.run([path, "-version"], capture_output=True, text=True, timeout=15)
            match = re.search(r'(?:version\s+"|openjdk\s+)(?:1\.)?(\d+)', output.stderr + output.stdout)
            actual = int(match[1]) if match else 0
            wanted = int(info["javaMajorVersion"])
            if output.returncode or (actual != 8 if wanted == 8 else actual < wanted):
                raise UserError(f"Выбранная Java не подходит: требуется Java {wanted}. Очистите путь для автоустановки.")
            return path
        except OSError as error:
            raise UserError("Указанный исполняемый файл Java не найден.") from error
    path = mc.runtime.get_executable_path(info["name"], directory)
    if not path:
        job.update("Установка официальной Java " + str(info["javaMajorVersion"]), phase="java", force=True)
        mc.runtime.install_jvm_runtime(info["name"], directory, callback=callbacks(job), max_workers=6)
        path = mc.runtime.get_executable_path(info["name"], directory)
    if not path:
        raise UserError("Для вашей системы нет автоматической Java. Укажите путь к Java " + str(info["javaMajorVersion"]) + " в настройках.")
    return path


def install(profile, settings, job):
    directory = Path(profile["directory"])
    directory.mkdir(parents=True, exist_ok=True)
    cb = callbacks(job)
    job.update("Проверка клиента, ресурсов и библиотек Mojang", phase="game", force=True)
    mc.install.install_minecraft_version(profile["mc"], directory, callback=cb)
    java = ensure_java(profile["mc"], directory, settings, job)
    version = profile["mc"]
    loader_version = profile.get("loader_version", "")
    if profile["loader"] != "vanilla":
        loader = mc.mod_loader.get_mod_loader(profile["loader"])
        if not loader_version:
            loader_version = loader.get_latest_loader_version(profile["mc"])
        job.update("Установка " + profile["loader"] + " " + loader_version, phase="loader", force=True)
        version = loader.install(profile["mc"], directory, loader_version=loader_version, callback=cb, java=java)
    metadata = directory / "versions" / version / (version + ".json")
    if not metadata.is_file():
        raise UserError("Установщик не создал метаданные запуска.")
    job.check()
    return {"launch_version": version, "java": java, "loader_version": loader_version}


def launch(profile, account, credentials, settings, log):
    if profile.get("state") != "ready" or not profile.get("installed") or profile.get("pending"):
        raise UserError("Сборка ещё не готова. Установите или восстановите её файлы.")
    directory = Path(profile["directory"])
    for entry in profile.get("mods", []):
        if entry.get("hashes") and not verify(directory / entry["path"], entry["hashes"], entry.get("size")):
            raise UserError("Файл отсутствует или повреждён: " + entry["path"] + ". Нажмите «Проверить / продолжить».")
    options = {"username": account["name"], "uuid": account["uuid"].replace("-", ""), "token": credentials.get("access_token", "0"), "gameDirectory": str(directory), "executablePath": settings.get("java_path") or profile["java"], "jvmArguments": ["-Xms512M", "-Xmx" + str(int(profile.get("ram") or settings["ram"])) + "M"], "launcherName": "Voxel", "launcherVersion": "3.0", "customResolution": not settings.get("fullscreen"), "resolutionWidth": str(settings["width"]), "resolutionHeight": str(settings["height"]), "enableLoggingConfig": True}
    options["jvmArguments"] += shlex.split(settings.get("jvm_args", ""))
    if account["kind"] == "ely":
        options["jvmArguments"].append("-javaagent:" + credentials["injector"] + "=https://authserver.ely.by")
    command = mc.command.get_minecraft_command(profile["launch_version"], directory, options)
    if settings.get("fullscreen"):
        command.append("--fullscreen")
    # No shell, no token-containing command line in the UI/log file.
    log("Запуск процесса Minecraft " + profile["mc"] + " · " + profile["loader"])
    process = subprocess.Popen(command, cwd=directory, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return process
