@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --name VoxelLauncher --collect-all minecraft_launcher_lib --collect-submodules keyring.backends --add-data "assets;assets" --add-data "catalog;catalog" --add-data "voxel\theme.qss;voxel" main.py
if errorlevel 1 goto failed
echo Built: dist\VoxelLauncher\VoxelLauncher.exe
echo Keep the entire dist\VoxelLauncher directory, including _internal.
explorer dist\VoxelLauncher
pause
exit /b 0
:failed
echo Build failed. See errors above. No executable was produced.
pause
exit /b 1
