@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if not exist main.py goto incomplete
if exist .venv\Scripts\python.exe goto deps
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -m venv .venv
) else (
  python -m venv .venv
)
if not exist .venv\Scripts\python.exe (
  echo Install Python 3.10+ with Add to PATH: https://www.python.org/downloads/
  pause
  exit /b 1
)
:deps
.venv\Scripts\python.exe -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed. Check your connection and Python version.
  pause
  exit /b 1
)
.venv\Scripts\python.exe main.py
if errorlevel 1 pause
exit /b
:incomplete
echo Extract the WHOLE ZIP before running START.bat.
pause
exit /b 1
